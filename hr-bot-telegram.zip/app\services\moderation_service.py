"""
Moderation helpers for resumes and vacancy publications.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone

from loguru import logger

from app.config import settings
from app.nocodb.client import noco


@dataclass(slots=True)
class ModerationDecision:
    decision: str
    score: int
    reason: str

    @property
    def needs_manual(self) -> bool:
        return self.decision == "manual"

    @property
    def is_approved(self) -> bool:
        return self.decision == "approved"

    @property
    def is_rejected(self) -> bool:
        return self.decision == "rejected"


def _truncate(text: str, limit: int = 1500) -> str:
    text = (text or "").strip()
    return text[:limit]


def _json_dumps(value) -> str:
    return json.dumps(value, ensure_ascii=False)


def _json_loads(raw: str | None, default):
    if not raw:
        return default
    try:
        return json.loads(raw)
    except Exception:
        return default


async def _moderate_with_ai(kind: str, payload: str) -> ModerationDecision:
    if not settings.openai_api_key:
        return ModerationDecision(
            decision="manual",
            score=0,
            reason="OpenAI key not configured, sent to manual moderation.",
        )

    if kind == "resume":
        system_prompt = (
            "You moderate candidate resumes for a recruiting bot. "
            "Allow normal resumes, reject clear spam/fraud/illegal content, "
            "send to manual review if content is incomplete or suspicious. "
            'Return strict JSON: {"decision":"approved|manual|rejected","score":0-100,"reason":"..."}'
        )
    else:
        system_prompt = (
            "You moderate job vacancy publications for a recruiting bot. "
            "Allow legitimate job postings, reject clear scam/illegal/empty content, "
            "send to manual review when the post is questionable or incomplete. "
            'Return strict JSON: {"decision":"approved|manual|rejected","score":0-100,"reason":"..."}'
        )

    try:
        from app.services.openai_service import get_client

        response = await get_client().chat.completions.create(
            model=settings.openai_model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": _truncate(payload, 5000)},
            ],
            temperature=0.1,
            max_tokens=250,
            response_format={"type": "json_object"},
        )
        raw = response.choices[0].message.content.strip()
        data = json.loads(raw)
        decision = str(data.get("decision", "manual")).lower()
        if decision not in {"approved", "manual", "rejected"}:
            decision = "manual"
        score = int(max(0, min(100, int(data.get("score", 0) or 0))))
        reason = str(data.get("reason", "")).strip() or "No moderation reason provided."
        return ModerationDecision(decision=decision, score=score, reason=reason)
    except Exception as exc:
        logger.warning(f"[Moderation] AI moderation failed for {kind}: {exc}")
        return ModerationDecision(
            decision="manual",
            score=0,
            reason="AI moderation unavailable, manual review required.",
        )


async def create_moderation_request(
    *,
    item_type: str,
    entity_id: int,
    requested_by: int,
    preview_text: str,
    ai_result: ModerationDecision,
    target_ids: list[int] | None = None,
) -> dict | None:
    if not settings.noco_table_moderation_queue:
        logger.warning("[Moderation] moderation table is not configured")
        return None

    payload = {
        "item_type": item_type,
        "entity_id": entity_id,
        "status": "pending" if ai_result.needs_manual else ai_result.decision,
        "requested_by": requested_by,
        "target_ids_json": _json_dumps(target_ids or []),
        "preview_text": _truncate(preview_text, 4000),
        "ai_decision": ai_result.decision,
        "ai_score": ai_result.score,
        "ai_reason": _truncate(ai_result.reason, 1000),
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    return await noco.create_record(settings.noco_table_moderation_queue, payload)


async def moderate_resume_payload(
    *,
    candidate_id: int,
    requested_by: int,
    candidate_name: str,
    vacancy_title: str,
    resume_text: str,
) -> tuple[ModerationDecision, dict | None]:
    preview = (
        f"Candidate: {candidate_name or 'Unknown'}\n"
        f"Vacancy: {vacancy_title or 'Not specified'}\n\n"
        f"{_truncate(resume_text, 3500)}"
    )
    result = await _moderate_with_ai("resume", preview)
    queue = await create_moderation_request(
        item_type="resume",
        entity_id=candidate_id,
        requested_by=requested_by,
        preview_text=preview,
        ai_result=result,
    )
    return result, queue


async def moderate_vacancy_publication(
    *,
    vacancy: dict,
    requested_by: int,
    channel_ids: list[int],
) -> tuple[ModerationDecision, dict | None]:
    preview = (
        f"Title: {vacancy.get('title', '')}\n"
        f"City: {vacancy.get('city') or vacancy.get('location') or ''}\n"
        f"Requirements: {_truncate(vacancy.get('requirements', ''), 800)}\n\n"
        f"Description:\n{_truncate(vacancy.get('description', ''), 2500)}"
    )
    result = await _moderate_with_ai("vacancy", preview)
    queue = await create_moderation_request(
        item_type="vacancy_publication",
        entity_id=int(vacancy.get("Id", 0) or 0),
        requested_by=requested_by,
        preview_text=preview,
        ai_result=result,
        target_ids=channel_ids,
    )
    return result, queue


def parse_target_ids(record: dict | None) -> list[int]:
    return [int(x) for x in _json_loads((record or {}).get("target_ids_json"), []) if str(x).isdigit()]


async def finalize_moderation_record(
    queue_id: int,
    *,
    status: str,
    reviewer_telegram_id: int,
    reviewer_comment: str = "",
) -> dict | None:
    if not settings.noco_table_moderation_queue:
        return None
    return await noco.update_record(
        settings.noco_table_moderation_queue,
        queue_id,
        {
            "status": status,
            "reviewer_telegram_id": reviewer_telegram_id,
            "reviewer_comment": _truncate(reviewer_comment, 1000),
            "reviewed_at": datetime.now(timezone.utc).isoformat(),
        },
    )
