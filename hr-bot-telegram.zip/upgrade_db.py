"""
DB upgrade helper.
Re-runs init_db + seed safely on an existing database.
Safe to run multiple times — will not delete existing data.

Usage:
    python upgrade_db.py
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from app.logger import setup_logger
from app.database.base import init_db, async_session_factory
from app.database.seed import seed_database


async def main() -> None:
    setup_logger()
    print("🔄 Running database upgrade (add new tables / seed data)...")
    await init_db()                                  # creates any missing tables
    async with async_session_factory() as session:
        await seed_database(session)                 # inserts missing seed rows
    print("✅ Upgrade complete.")


if __name__ == "__main__":
    asyncio.run(main())
