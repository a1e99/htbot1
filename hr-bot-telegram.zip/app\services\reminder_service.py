"""
Candidate reminder worker.

Runs as a lightweight async loop inside the bot process.
"""
from __future__ import annotations

import asyncio
from contextlib import suppress
from datetime import datetime, timedelta, timezone

from aiogram import Bot
from loguru import logger

from app.config import settings
from app.nocodb.client import noco

ACTIVE_STATUSES = {"new", "in_review", "clarification_needed"}

STATUS_LABELS = {
    "new": "анкета получена и ожидает обработки",
    "in_review": "анкета находится на рассмотрении",
    "clarification_needed": "менеджер запросил уточнение",
}


def _parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def _build_reminder_text(candidate: dict) -> str:
    vacancy = candidate.get("vacancy_title") or "ваша вакансия"
    status = STATUS_LABELS.get(candidate.get("status", "new"), "анкета активна")
    return (
        "🔔 <b>Напоминание по вашей анкете</b>\n\n"
        f"Вакансия: <b>{vacancy}</b>\n"
        f"Статус: <b>{status}</b>\n\n"
        "Если ваши планы изменились, дождитесь сообщения менеджера или подайте новую анкету только по новой ссылке на вакансию."
    )


async def process_due_candidate_reminders(bot: Bot) -> int:
    notified = 0
    offset = 0
    batch_size = 200
    now = datetime.now(timezone.utc)

    while True:
        candidates = await noco.list_candidates(limit=batch_size, offset=offset)
        if not candidates:
            break

        for candidate in candidates:
            days = int(candidate.get("reminder_frequency_days") or 0)
            if days <= 0:
                continue
            if candidate.get("status") not in ACTIVE_STATUSES:
                continue
            if candidate.get("is_blocked"):
                continue
            if not candidate.get("registration_completed_at"):
                continue

            due_at = _parse_dt(candidate.get("reminder_next_at"))
            if due_at is None or due_at > now:
                continue

            tg_id = candidate.get("telegram_id")
            if not tg_id:
                continue

            try:
                await bot.send_message(tg_id, _build_reminder_text(candidate), parse_mode="HTML")
                await noco.update_candidate(
                    candidate["Id"],
                    {
                        "last_reminder_at": now.isoformat(),
                        "reminder_next_at": (now + timedelta(days=days)).isoformat(),
                    },
                )
                notified += 1
            except Exception as exc:
                logger.warning(f"[Reminder] failed for candidate {candidate.get('Id')}: {exc}")

        if len(candidates) < batch_size:
            break
        offset += batch_size

    return notified


async def run_candidate_reminder_worker(bot: Bot) -> None:
    interval_seconds = max(300, settings.candidate_reminder_check_minutes * 60)
    logger.info(f"[Reminder] worker started, interval={interval_seconds}s")

    while True:
        try:
            notified = await process_due_candidate_reminders(bot)
            if notified:
                logger.info(f"[Reminder] sent {notified} candidate reminders")
        except Exception as exc:
            logger.error(f"[Reminder] worker cycle failed: {exc}")

        await asyncio.sleep(interval_seconds)


async def stop_background_task(task: asyncio.Task | None) -> None:
    if task is None:
        return

    task.cancel()
    with suppress(asyncio.CancelledError):
        await task
