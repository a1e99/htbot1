"""
OpenAI service.
- evaluate_quiz_answer: scores a single quiz answer (0-10)
- generate_candidate_summary: full AI analysis of a candidate
"""
from __future__ import annotations

import json
from typing import Any

from openai import AsyncOpenAI
from loguru import logger

from app.config import settings

_client: AsyncOpenAI | None = None


def get_client() -> AsyncOpenAI:
    global _client
    if _client is None:
        _client = AsyncOpenAI(api_key=settings.openai_api_key)
    return _client


# ─────────────────────────────────────────────
# QUIZ ANSWER EVALUATION
# ─────────────────────────────────────────────

async def evaluate_quiz_answer(
    question: str,
    answer: str,
    profession: str,
) -> tuple[float | None, str | None]:
    """
    Evaluate a quiz answer using OpenAI.
    Returns (score 0-10, short comment).
    """
    prompt = (
        f"Ты — эксперт по подбору персонала специальности «{profession}».\n\n"
        f"Вопрос: {question}\n"
        f"Ответ кандидата: {answer}\n\n"
        "Оцени ответ по шкале от 0 до 10, где:\n"
        "0–3 = слабый ответ, нет знаний\n"
        "4–6 = средний, базовые знания\n"
        "7–9 = хороший ответ\n"
        "10 = отличный, профессиональный ответ\n\n"
        "Отвечай ТОЛЬКО в JSON формате без markdown:\n"
        '{"score": 7.5, "comment": "Краткий комментарий (1-2 предложения)"}'
    )

    try:
        response = await get_client().chat.completions.create(
            model=settings.openai_model,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=200,
            temperature=0.3,
        )
        raw = response.choices[0].message.content.strip()
        data = json.loads(raw)
        score = float(data.get("score", 0))
        score = max(0.0, min(10.0, score))
        comment = data.get("comment", "")
        logger.debug(f"[OpenAI] Quiz eval: score={score}, comment={comment[:50]}")
        return score, comment
    except Exception as e:
        logger.error(f"[OpenAI] evaluate_quiz_answer error: {e}")
        return None, None


# ─────────────────────────────────────────────
# CANDIDATE SUMMARY GENERATION
# ─────────────────────────────────────────────

async def generate_candidate_summary(
    candidate,
    quiz_results: list,
) -> dict[str, Any]:
    """
    Generate a full AI analysis of a candidate.
    Returns dict with: summary, weak_points, risks, strengths, recommendation.
    """
    # Build quiz section
    quiz_text = ""
    for i, result in enumerate(quiz_results, 1):
        q_text = result.question.question_text if result.question else f"Вопрос {i}"
        score = f"{result.ai_score:.1f}/10" if result.ai_score else "нет оценки"
        quiz_text += f"\nВопрос {i}: {q_text}\nОтвет: {result.answer}\nОценка: {score}\n"

    profession = candidate.profession.name_ru if candidate.profession else "не указана"

    prompt = (
        f"Ты — опытный HR-менеджер. Проанализируй кандидата и составь подробное резюме.\n\n"
        f"=== ДАННЫЕ КАНДИДАТА ===\n"
        f"Имя: {candidate.full_name or 'не указано'}\n"
        f"Возраст: {candidate.age or 'не указан'}\n"
        f"Гражданство: {candidate.nationality or 'не указано'}\n"
        f"Специальность: {profession}\n"
        f"Опыт: {candidate.experience_years or 0} лет\n"
        f"Описание опыта: {candidate.experience_details or 'не указано'}\n\n"
        f"=== РЕЗУЛЬТАТЫ ТЕСТА ===\n{quiz_text or 'Тест не пройден'}\n\n"
        "Составь анализ в JSON формате без markdown:\n"
        "{\n"
        '  "summary": "Краткое профессиональное резюме кандидата (3-5 предложений)",\n'
        '  "strengths": "Сильные стороны кандидата",\n'
        '  "weak_points": "Слабые стороны и зоны роста",\n'
        '  "risks": "Потенциальные риски при найме",\n'
        '  "recommendation": "hire / maybe / reject",\n'
        '  "recommendation_reason": "Обоснование рекомендации"\n'
        "}"
    )

    try:
        response = await get_client().chat.completions.create(
            model=settings.openai_model,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=1000,
            temperature=0.4,
        )
        raw = response.choices[0].message.content.strip()
        # Strip markdown code blocks if present
        raw = raw.replace("```json", "").replace("```", "").strip()
        data = json.loads(raw)
        logger.info(f"[OpenAI] Summary generated for candidate {candidate.id}")
        return data
    except Exception as e:
        logger.error(f"[OpenAI] generate_candidate_summary error: {e}")
        return {
            "summary": f"Кандидат {candidate.full_name or ''}, специальность: {profession}.",
            "strengths": "Анализ недоступен",
            "weak_points": "Анализ недоступен",
            "risks": "Анализ недоступен",
            "recommendation": "maybe",
            "recommendation_reason": "Ошибка AI анализа",
        }
