"""
Notification service - NocoDB version.
Manager alerts, vacancy publishing, candidate broadcast to partners.
"""
from __future__ import annotations
from datetime import datetime, timezone
from typing import Optional
from loguru import logger
from aiogram import Bot
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from app.config import settings
from app.nocodb.client import noco
from app.services.summary_service import format_summary_for_telegram


async def notify_managers_new_candidate(candidate_id, candidate, answers, summary_text, score):
    from app.bot.main import bot
    text = format_summary_for_telegram(candidate, answers, summary_text, score)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ Одобрить",  callback_data=f"mgr_approve:{candidate_id}"),
            InlineKeyboardButton(text="❌ Отклонить", callback_data=f"mgr_reject:{candidate_id}"),
        ],
        [
            InlineKeyboardButton(text="❓ Уточнить",  callback_data=f"mgr_clarify:{candidate_id}"),
            InlineKeyboardButton(text="📤 Переслать", callback_data=f"mgr_forward:{candidate_id}"),
        ],
    ])
    photo_path = candidate.get("photo_path", "")
    for manager_id in settings.manager_chat_ids:
        try:
            if photo_path:
                try:
                    with open(photo_path, "rb") as f:
                        await bot.send_photo(manager_id, photo=f, caption=text, parse_mode="HTML", reply_markup=kb)
                    continue
                except Exception:
                    pass
            await bot.send_message(manager_id, text, parse_mode="HTML", reply_markup=kb)
        except Exception as e:
            logger.error(f"Notify manager {manager_id} failed: {e}")


def build_vacancy_deep_link(bot_username: str, vacancy_id: int) -> str:
    """Generate deep-link URL for a specific vacancy."""
    return f"https://t.me/{bot_username}?start=vacancy_{vacancy_id}"


async def publish_vacancy_to_channel(bot: Bot, vacancy: dict, channel_tg_id: int, posted_by: int) -> Optional[int]:
    title = vacancy.get("title", "Вакансия")
    desc = vacancy.get("description", "")
    req = vacancy.get("requirements", "")
    sf, st = vacancy.get("salary_from"), vacancy.get("salary_to")
    salary = ""
    if sf and st:
        salary = f"💰 <b>Зарплата:</b> {sf:,}–{st:,} ₽\n"
    elif sf:
        salary = f"💰 <b>Зарплата:</b> от {sf:,} ₽\n"
    elif st:
        salary = f"💰 <b>Зарплата:</b> до {st:,} ₽\n"
    location = f"📍 {vacancy.get('location')}\n" if vacancy.get("location") else ""

    # Deep-link button for direct vacancy apply
    apply_kb = None
    try:
        bot_info = await bot.get_me()
        vacancy_id = vacancy.get("Id", 0)
        deep_link = build_vacancy_deep_link(bot_info.username, vacancy_id)
        apply_kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="📩 Откликнуться", url=deep_link)
        ]])
    except Exception:
        pass

    text = (
        f"🔥 <b>{title}</b>\n{location}{salary}"
        + (f"\n{desc}" if desc else "")
        + (f"\n\n<b>Требования:</b>\n{req}" if req else "")
    )
    try:
        msg = await bot.send_message(
            channel_tg_id, text,
            parse_mode="HTML",
            reply_markup=apply_kb,
        )
        channel_rec = await noco.find_one(settings.noco_table_channels, f"(telegram_chat_id,eq,{channel_tg_id})")
        if channel_rec:
            await noco.update_record(settings.noco_table_channels, channel_rec["Id"],
                                     {"last_post_at": datetime.now(timezone.utc).isoformat()})
        return msg.message_id
    except Exception as e:
        logger.error(f"Publish to channel {channel_tg_id} failed: {e}")
        return None


async def notify_candidate_matching_vacancy(
    bot: Bot,
    candidate: dict,
    vacancy: dict,
    score: int,
    reasons: str,
) -> bool:
    """Send a notification to a candidate about a matching vacancy."""
    tg_id = candidate.get("telegram_id")
    if not tg_id:
        return False

    bot_info = None
    try:
        bot_info = await bot.get_me()
    except Exception:
        pass

    deep_link = ""
    if bot_info:
        from app.services.notification_service import build_vacancy_deep_link
        deep_link = build_vacancy_deep_link(bot_info.username, vacancy.get("Id", 0))

    title = vacancy.get("title", "Вакансия")
    salary_from = vacancy.get("salary_from")
    salary_to = vacancy.get("salary_to")
    salary_str = ""
    if salary_from and salary_to:
        salary_str = f"💰 {salary_from:,}–{salary_to:,} ₽\n"
    elif salary_from:
        salary_str = f"💰 от {salary_from:,} ₽\n"

    text = (
        f"💡 <b>Для вас есть подходящая вакансия!</b>\n\n"
        f"💼 <b>{title}</b>\n"
        f"{salary_str}"
        f"📊 Совпадение: <b>{score}%</b>\n"
        f"ℹ️ {reasons}\n"
    )

    kb = None
    if deep_link:
        kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="📩 Откликнуться", url=deep_link)
        ]])

    try:
        await bot.send_message(tg_id, text, parse_mode="HTML", reply_markup=kb)
        return True
    except Exception as e:
        logger.error(f"[Notify] candidate {tg_id} failed: {e}")
        return False


async def notify_candidates_about_new_vacancy(bot: Bot, vacancy: dict) -> int:
    """
    Run matching for a new/updated vacancy and notify all suitable candidates.
    Returns count of notified candidates.
    """
    try:
        from app.services.matching_service import find_best_candidates_for_vacancy, save_match
        matches = await find_best_candidates_for_vacancy(vacancy, top_n=50, min_score=55)
        notified = 0
        for m in matches:
            cand = m["candidate"]
            score = m["score"]
            reasons = m["reasons"]
            await save_match(cand.get("Id", 0), vacancy.get("Id", 0), score, reasons)
            ok = await notify_candidate_matching_vacancy(bot, cand, vacancy, score, reasons)
            if ok:
                notified += 1
        logger.info(f"[Notify] Vacancy {vacancy.get('Id')} → notified {notified} candidates")
        return notified
    except Exception as e:
        logger.error(f"[Notify] notify_candidates_about_new_vacancy failed: {e}")
        return 0


async def broadcast_candidate_to_partner(
    bot: Bot, candidate: dict, answers: list, partner: dict,
    summary_text: str, score: int, sent_by: int, custom_message: str = ""
) -> bool:
    tg_id = partner.get("telegram_chat_id")
    if not tg_id:
        return False
    text = format_summary_for_telegram(candidate, answers, summary_text, score)
    if custom_message:
        text = f"💼 <b>Предложение кандидата</b>\n\n{custom_message}\n\n{text}"
    photo_path = candidate.get("photo_path", "")
    ok = False
    try:
        if photo_path:
            try:
                with open(photo_path, "rb") as f:
                    await bot.send_photo(tg_id, photo=f, caption=text[:1024], parse_mode="HTML")
                ok = True
            except Exception:
                pass
        if not ok:
            await bot.send_message(tg_id, text, parse_mode="HTML")
        await noco.create_record(settings.noco_table_broadcasts, {
            "candidate_id": candidate.get("Id"),
            "partner_id": partner.get("Id"),
            "sent_by": sent_by,
            "message_text": (custom_message or text)[:500],
            "status": "sent",
            "sent_at": datetime.now(timezone.utc).isoformat(),
        })
        return True
    except Exception as e:
        logger.error(f"Broadcast failed: {e}")
        return False
