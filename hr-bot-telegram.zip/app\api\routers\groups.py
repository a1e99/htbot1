"""Groups API router."""
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.database.base import get_session
from app.database.models import BotGroup, BotGroupMember, Manager, GroupStatus

router = APIRouter(prefix="/groups", tags=["groups"])


@router.get("")
async def list_groups(session: AsyncSession = Depends(get_session)):
    result = await session.execute(
        select(BotGroup).order_by(BotGroup.created_at.desc())
    )
    groups = list(result.scalars().all())

    out = []
    for g in groups:
        # Count members
        cnt = await session.execute(
            select(func.count()).select_from(BotGroupMember)
            .where(BotGroupMember.group_id == g.id)
            .where(BotGroupMember.left_at.is_(None))
        )
        member_count = cnt.scalar() or 0

        creator_name = None
        if g.created_by:
            mgr = await session.get(Manager, g.created_by)
            if mgr:
                creator_name = mgr.full_name

        out.append({
            "id": g.id,
            "title": g.title,
            "telegram_chat_id": g.telegram_chat_id,
            "invite_link": g.invite_link,
            "purpose": g.purpose,
            "status": g.status.value if hasattr(g.status, "value") else g.status,
            "created_by": g.created_by,
            "creator_name": creator_name,
            "member_count": member_count,
            "created_at": g.created_at.isoformat() if g.created_at else None,
        })
    return out


@router.get("/{group_id}")
async def get_group(group_id: int, session: AsyncSession = Depends(get_session)):
    from fastapi import HTTPException
    result = await session.execute(select(BotGroup).where(BotGroup.id == group_id))
    group = result.scalar_one_or_none()
    if not group:
        raise HTTPException(404, "Group not found")

    members_result = await session.execute(
        select(BotGroupMember)
        .where(BotGroupMember.group_id == group_id)
        .where(BotGroupMember.left_at.is_(None))
    )
    members = [
        {
            "telegram_id": m.telegram_id,
            "telegram_username": m.telegram_username,
            "full_name": m.full_name,
            "role": m.role.value if hasattr(m.role, "value") else m.role,
        }
        for m in members_result.scalars().all()
    ]

    return {
        "id": group.id,
        "title": group.title,
        "telegram_chat_id": group.telegram_chat_id,
        "invite_link": group.invite_link,
        "purpose": group.purpose,
        "status": group.status.value if hasattr(group.status, "value") else group.status,
        "members": members,
        "created_at": group.created_at.isoformat() if group.created_at else None,
    }
