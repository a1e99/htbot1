@echo off
chcp 65001 >nul
title HR Bot - Stop
cd /d "%~dp0"
color 0C

echo.
echo  =============================================
echo   HR BOT - Ostanovka
echo  =============================================
echo.

echo  Ostanovka processov...
taskkill /FI "WINDOWTITLE eq HR Bot*" /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq HR Web*" /F >nul 2>&1
taskkill /FI "IMAGENAME eq pythonw.exe" /F >nul 2>&1

echo  Osvobozhdeniye porta 8000...
for /f "tokens=5" %%p in ('netstat -ano 2^>nul ^| findstr ":8000 "') do (
    taskkill /PID %%p /F >nul 2>&1
)
echo  [OK] Processy ostanovleny.

echo.
set /p SD=Ostanovit NocoDB (Docker)? (y/n): 
if /i "%SD%"=="y" (
    docker compose stop >nul 2>&1
    echo  [OK] NocoDB ostanovlen.
)

echo.
echo  Dlya zapuska: start.bat
echo.
pause
