"""Vacancies router."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.api.schemas.schemas import VacancyCreate, VacancyOut, OkResponse
from app.database.base import get_session
from app.database import crud
from app.database.models import Vacancy

router = APIRouter(prefix="/vacancies", tags=["vacancies"])


@router.get("", response_model=list[VacancyOut])
async def list_vacancies(session: AsyncSession = Depends(get_session)):
    vacancies = await crud.get_all_vacancies(session)
    return list(vacancies)


@router.post("", response_model=VacancyOut)
async def create_vacancy(data: VacancyCreate, session: AsyncSession = Depends(get_session)):
    vacancy = Vacancy(**data.model_dump())
    session.add(vacancy)
    await session.flush()
    return vacancy


@router.patch("/{vacancy_id}/toggle", response_model=OkResponse)
async def toggle_vacancy(vacancy_id: int, session: AsyncSession = Depends(get_session)):
    from sqlalchemy import select, update
    result = await session.execute(select(Vacancy).where(Vacancy.id == vacancy_id))
    v = result.scalar_one_or_none()
    if not v:
        raise HTTPException(404, "Vacancy not found")
    await session.execute(
        update(Vacancy).where(Vacancy.id == vacancy_id).values(is_active=not v.is_active)
    )
    return OkResponse(message=f"Vacancy {'activated' if not v.is_active else 'deactivated'}")
