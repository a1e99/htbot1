"""
Settings API router - NocoDB version.
Reads/writes .env, manages vacancies, quiz questions, partners, channels.
"""
from __future__ import annotations
import re
from pathlib import Path
from typing import Any
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter(prefix="/settings", tags=["settings"])

ENV_PATH = Path(__file__).resolve().parents[4] / ".env"


# ── .env helpers ──────────────────────────────────────────────────────

def _read_env() -> dict[str, str]:
    if not ENV_PATH.exists():
        return {}
    result = {}
    for line in ENV_PATH.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, _, v = line.partition("=")
            result[k.strip()] = v.strip()
    return result

def _write_env(data: dict[str, str]) -> None:
    ENV_PATH.parent.mkdir(parents=True, exist_ok=True)
    lines = []
    existing = _read_env()
    # Preserve comments and structure, update existing keys
    if ENV_PATH.exists():
        raw = ENV_PATH.read_text(encoding="utf-8").splitlines()
        updated_keys = set()
        for line in raw:
            stripped = line.strip()
            if stripped and not stripped.startswith("#") and "=" in stripped:
                k = stripped.split("=", 1)[0].strip()
                if k in data:
                    lines.append(f"{k}={data[k]}")
                    updated_keys.add(k)
                    continue
            lines.append(line)
        # Append new keys not in file
        for k, v in data.items():
            if k not in updated_keys:
                lines.append(f"{k}={v}")
    else:
        for k, v in data.items():
            lines.append(f"{k}={v}")
    ENV_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")


# ── Config models ────────────────────────────────────────────────────

class BotConfig(BaseModel):
    bot_token: str = ""
    manager_chat_ids: str = ""
    openai_api_key: str = ""
    openai_model: str = "gpt-4o"
    web_host: str = "127.0.0.1"
    web_port: int = 8000
    nocodb_url: str = "http://localhost:8080"
    nocodb_email: str = ""
    nocodb_password: str = ""
    nocodb_project_id: str = ""
    rate_limit_messages: int = 5
    rate_limit_window: int = 60
    min_message_length: int = 3

class NocoCreds(BaseModel):
    nocodb_url: str
    nocodb_email: str
    nocodb_password: str

class TableIds(BaseModel):
    nocodb_project_id: str = ""
    noco_table_candidates: str = ""
    noco_table_vacancies: str = ""
    noco_table_quizquestions: str = ""
    noco_table_quizanswers: str = ""
    noco_table_knowledgedocs: str = ""
    noco_table_companypartners: str = ""
    noco_table_publishchannels: str = ""
    noco_table_managers: str = ""
    noco_table_candidatebroadcasts: str = ""
    noco_table_matches: str = ""
    noco_table_moderation_queue: str = ""


# ── Config endpoints ─────────────────────────────────────────────────

@router.get("/config")
async def get_config() -> dict:
    env = _read_env()
    return {
        "bot_token":          env.get("BOT_TOKEN", ""),
        "manager_chat_ids":   env.get("MANAGER_CHAT_IDS", ""),
        "openai_api_key":     env.get("OPENAI_API_KEY", ""),
        "openai_model":       env.get("OPENAI_MODEL", "gpt-4o"),
        "web_host":           env.get("WEB_HOST", "127.0.0.1"),
        "web_port":           env.get("WEB_PORT", "8000"),
        "nocodb_url":         env.get("NOCODB_URL", "http://localhost:8080"),
        "nocodb_email":       env.get("NOCODB_EMAIL", ""),
        "nocodb_password":    env.get("NOCODB_PASSWORD", ""),
        "nocodb_project_id":  env.get("NOCODB_PROJECT_ID", ""),
        "rate_limit_messages":env.get("RATE_LIMIT_MESSAGES", "5"),
        "rate_limit_window":  env.get("RATE_LIMIT_WINDOW", "60"),
        "min_message_length": env.get("MIN_MESSAGE_LENGTH", "3"),
    }

@router.post("/config")
async def save_config(data: BotConfig) -> dict:
    mapping = {
        "BOT_TOKEN":           data.bot_token,
        "MANAGER_CHAT_IDS":    data.manager_chat_ids,
        "OPENAI_API_KEY":      data.openai_api_key,
        "OPENAI_MODEL":        data.openai_model,
        "WEB_HOST":            data.web_host,
        "WEB_PORT":            str(data.web_port),
        "NOCODB_URL":          data.nocodb_url,
        "NOCODB_EMAIL":        data.nocodb_email,
        "NOCODB_PASSWORD":     data.nocodb_password,
        "NOCODB_PROJECT_ID":   data.nocodb_project_id,
        "RATE_LIMIT_MESSAGES": str(data.rate_limit_messages),
        "RATE_LIMIT_WINDOW":   str(data.rate_limit_window),
        "MIN_MESSAGE_LENGTH":  str(data.min_message_length),
    }
    _write_env(mapping)
    return {"ok": True, "message": "Настройки сохранены. Перезапустите бота."}

@router.get("/table-ids")
async def get_table_ids() -> dict:
    env = _read_env()
    return {
        "nocodb_project_id":          env.get("NOCODB_PROJECT_ID", ""),
        "noco_table_candidates":      env.get("NOCO_TABLE_CANDIDATES", ""),
        "noco_table_vacancies":       env.get("NOCO_TABLE_VACANCIES", ""),
        "noco_table_quizquestions":   env.get("NOCO_TABLE_QUIZQUESTIONS", ""),
        "noco_table_quizanswers":     env.get("NOCO_TABLE_QUIZANSWERS", ""),
        "noco_table_knowledgedocs":   env.get("NOCO_TABLE_KNOWLEDGEDOCS", ""),
        "noco_table_companypartners": env.get("NOCO_TABLE_COMPANYPARTNERS", ""),
        "noco_table_publishchannels": env.get("NOCO_TABLE_PUBLISHCHANNELS", ""),
        "noco_table_managers":        env.get("NOCO_TABLE_MANAGERS", ""),
        "noco_table_candidatebroadcasts": env.get("NOCO_TABLE_CANDIDATEBROADCASTS", ""),
        "noco_table_matches":         env.get("NOCO_TABLE_MATCHES", ""),
        "noco_table_moderation_queue": env.get("NOCO_TABLE_MODERATION_QUEUE", ""),
    }

@router.post("/table-ids")
async def save_table_ids(data: TableIds) -> dict:
    mapping = {
        "NOCODB_PROJECT_ID":           data.nocodb_project_id,
        "NOCO_TABLE_CANDIDATES":       data.noco_table_candidates,
        "NOCO_TABLE_VACANCIES":        data.noco_table_vacancies,
        "NOCO_TABLE_QUIZQUESTIONS":    data.noco_table_quizquestions,
        "NOCO_TABLE_QUIZANSWERS":      data.noco_table_quizanswers,
        "NOCO_TABLE_KNOWLEDGEDOCS":    data.noco_table_knowledgedocs,
        "NOCO_TABLE_COMPANYPARTNERS":  data.noco_table_companypartners,
        "NOCO_TABLE_PUBLISHCHANNELS":  data.noco_table_publishchannels,
        "NOCO_TABLE_MANAGERS":         data.noco_table_managers,
        "NOCO_TABLE_CANDIDATEBROADCASTS": data.noco_table_candidatebroadcasts,
        "NOCO_TABLE_MATCHES":          data.noco_table_matches,
        "NOCO_TABLE_MODERATION_QUEUE": data.noco_table_moderation_queue,
    }
    _write_env(mapping)
    return {"ok": True, "message": "ID таблиц сохранены."}


# ── NocoDB status ─────────────────────────────────────────────────────

@router.get("/nocodb-status")
async def nocodb_status() -> dict:
    try:
        from app.nocodb.client import noco
        ok = await noco.ping()
        return {"ok": ok, "url": _read_env().get("NOCODB_URL", "")}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def _run_nocodb_setup_sync() -> dict:
    try:
        import subprocess, sys
        result = subprocess.run(
            [sys.executable, "setup_nocodb.py"],
            capture_output=True, text=True, timeout=60,
            cwd=str(ENV_PATH.parent)
        )
        output = result.stdout + result.stderr
        ok = result.returncode == 0
        # Parse table IDs from output and auto-save
        ids = {}
        for line in output.splitlines():
            if "=" in line and "NOCO" in line:
                k, _, v = line.partition("=")
                ids[k.strip()] = v.strip()
        if ids:
            _write_env(ids)
        return {"ok": ok, "output": output[-2000:], "ids_saved": len(ids)}
    except Exception as e:
        return {"ok": False, "error": str(e)}


@router.post("/nocodb-setup")
async def run_nocodb_setup() -> dict:
    """Trigger table creation in NocoDB."""
    return _run_nocodb_setup_sync()


@router.post("/nocodb-sync")
async def run_nocodb_sync() -> dict:
    """Force synchronization of required NocoDB tables and IDs."""
    result = _run_nocodb_setup_sync()
    result["action"] = "sync"
    return result


# ── Vacancies ─────────────────────────────────────────────────────────

class VacancyCreate(BaseModel):
    title: str
    description: str = ""
    requirements: str = ""
    salary_from: int | None = None
    salary_to: int | None = None
    location: str = ""
    is_active: bool = True

@router.get("/vacancies")
async def list_vacancies() -> list:
    from app.nocodb.client import noco
    return await noco.list_vacancies(active_only=False)

@router.post("/vacancies")
async def create_vacancy(data: VacancyCreate) -> dict:
    from app.nocodb.client import noco
    from datetime import datetime, timezone
    row = data.model_dump()
    row["created_at"] = datetime.now(timezone.utc).isoformat()
    return await noco.create_vacancy(row)

@router.patch("/vacancies/{vid}")
async def update_vacancy(vid: int, data: dict) -> dict:
    from app.nocodb.client import noco
    return await noco.update_record(
        __import__("app.config", fromlist=["settings"]).settings.noco_table_vacancies, vid, data)

@router.delete("/vacancies/{vid}")
async def delete_vacancy(vid: int) -> dict:
    from app.nocodb.client import noco
    from app.config import settings
    await noco.delete_record(settings.noco_table_vacancies, vid)
    return {"ok": True}


# ── Quiz Questions ────────────────────────────────────────────────────

class QuestionCreate(BaseModel):
    question_text: str
    vacancy_id: int | None = None
    question_type: str = "open"
    choices: str = ""
    min_answer_length: int = 10
    order_num: int = 1
    is_active: bool = True

@router.get("/questions")
async def list_questions(vacancy_id: int | None = None) -> list:
    from app.nocodb.client import noco
    return await noco.list_questions(vacancy_id)

@router.post("/questions")
async def create_question(data: QuestionCreate) -> dict:
    from app.nocodb.client import noco
    return await noco.create_question(data.model_dump())

@router.delete("/questions/{qid}")
async def delete_question(qid: int) -> dict:
    from app.nocodb.client import noco
    from app.config import settings
    await noco.delete_record(settings.noco_table_questions, qid)
    return {"ok": True}


# ── Partners ──────────────────────────────────────────────────────────

class PartnerCreate(BaseModel):
    name: str
    contact_name: str = ""
    telegram_chat_id: int | None = None
    telegram_username: str = ""
    email: str = ""
    specializations: str = ""
    is_active: bool = True

@router.get("/partners")
async def list_partners() -> list:
    from app.nocodb.client import noco
    return await noco.list_partners(active_only=False)

@router.post("/partners")
async def create_partner(data: PartnerCreate) -> dict:
    from app.nocodb.client import noco
    from datetime import datetime, timezone
    row = data.model_dump()
    row["created_at"] = datetime.now(timezone.utc).isoformat()
    return await noco.create_partner(row)

@router.delete("/partners/{pid}")
async def delete_partner(pid: int) -> dict:
    from app.nocodb.client import noco
    from app.config import settings
    await noco.delete_record(settings.noco_table_partners, pid)
    return {"ok": True}


# ── Publish Channels ──────────────────────────────────────────────────

class ChannelCreate(BaseModel):
    title: str
    telegram_chat_id: int
    username: str = ""
    description: str = ""
    is_active: bool = True

@router.get("/channels")
async def list_channels() -> list:
    from app.nocodb.client import noco
    return await noco.list_channels()

@router.post("/channels")
async def create_channel(data: ChannelCreate) -> dict:
    from app.nocodb.client import noco
    from datetime import datetime, timezone
    row = data.model_dump()
    row["created_at"] = datetime.now(timezone.utc).isoformat()
    return await noco.create_channel(row)

@router.delete("/channels/{cid}")
async def delete_channel(cid: int) -> dict:
    from app.nocodb.client import noco
    from app.config import settings
    await noco.delete_record(settings.noco_table_channels, cid)
    return {"ok": True}
