"""
Anti-spam middleware for aiogram.
Checks: rate limit, min message length, forbidden words, repeat registration.
"""
from __future__ import annotations

import time
from collections import defaultdict, deque
from typing import Any, Callable, Awaitable

from aiogram import BaseMiddleware
from aiogram.types import Message, TelegramObject
from loguru import logger

from app.config import settings
from app.database.base import async_session_factory
from app.database import crud
from app.database.models import SpamEventType


class AntiSpamMiddleware(BaseMiddleware):
    """
    Protects the bot from spam and flood.
    Uses in-memory rate limiter + DB checks.
    """

    def __init__(self) -> None:
        # {telegram_id: deque of timestamps}
        self._user_timestamps: dict[int, deque] = defaultdict(
            lambda: deque(maxlen=settings.rate_limit_messages * 3)
        )
        # Cached forbidden words (refreshed periodically)
        self._forbidden_words: list[str] = []
        self._forbidden_words_loaded_at: float = 0
        self._cache_ttl: float = 300  # refresh every 5 minutes

    async def _get_forbidden_words(self) -> list[str]:
        now = time.monotonic()
        if now - self._forbidden_words_loaded_at > self._cache_ttl:
            async with async_session_factory() as session:
                self._forbidden_words = await crud.get_all_forbidden_words(session)
            self._forbidden_words_loaded_at = now
        return self._forbidden_words

    def _is_rate_limited(self, telegram_id: int) -> bool:
        """Return True if user exceeded rate limit."""
        now = time.monotonic()
        timestamps = self._user_timestamps[telegram_id]
        cutoff = now - settings.rate_limit_window
        while timestamps and timestamps[0] < cutoff:
            timestamps.popleft()
        if len(timestamps) >= settings.rate_limit_messages:
            return True
        timestamps.append(now)
        return False

    def _contains_forbidden_word(self, text: str, forbidden: list[str]) -> str | None:
        """Return the found forbidden word or None."""
        text_lower = text.lower()
        for word in forbidden:
            if word in text_lower:
                return word
        return None

    def _is_too_short(self, text: str) -> bool:
        return len(text.strip()) < settings.min_message_length

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        # Only process Message events with text or caption
        if not isinstance(event, Message):
            return await handler(event, data)

        telegram_id = event.from_user.id if event.from_user else None
        if not telegram_id:
            return await handler(event, data)

        text = event.text or event.caption or ""

        # ── 1. Rate limit (flood) check ──
        if self._is_rate_limited(telegram_id):
            logger.warning(f"[AntiSpam] Flood from {telegram_id}")
            async with async_session_factory() as session:
                await crud.log_spam_event(
                    session, telegram_id, SpamEventType.FLOOD,
                    f"Exceeded {settings.rate_limit_messages} msgs/{settings.rate_limit_window}s"
                )
                await session.commit()
            await event.answer(
                "⚠️ Вы отправляете сообщения слишком быстро.\n"
                "Пожалуйста, подождите немного."
            )
            return  # block handler

        # ── 2. Skip non-text commands (/start etc pass through) ──
        if text.startswith("/"):
            return await handler(event, data)

        # ── 3. Minimum message length ──
        if text and self._is_too_short(text):
            logger.debug(f"[AntiSpam] Too short message from {telegram_id}: '{text}'")
            async with async_session_factory() as session:
                await crud.log_spam_event(
                    session, telegram_id, SpamEventType.SHORT_MESSAGE, text
                )
                await session.commit()
            await event.answer(
                f"⚠️ Ответ слишком короткий (минимум {settings.min_message_length} символа).\n"
                "Пожалуйста, дайте более развёрнутый ответ."
            )
            return

        # ── 4. Forbidden words ──
        if text:
            forbidden = await self._get_forbidden_words()
            found = self._contains_forbidden_word(text, forbidden)
            if found:
                logger.warning(f"[AntiSpam] Forbidden word '{found}' from {telegram_id}")
                async with async_session_factory() as session:
                    await crud.log_spam_event(
                        session, telegram_id, SpamEventType.FORBIDDEN_WORD,
                        f"Word: '{found}'"
                    )
                    await session.commit()
                await event.answer(
                    "⛔ Ваш ответ содержит недопустимое слово.\n"
                    "Пожалуйста, перефразируйте ответ без использования запрещённых слов."
                )
                return

        # ── All checks passed ──
        return await handler(event, data)


class DbSessionMiddleware(BaseMiddleware):
    """Injects async DB session into handler data."""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        async with async_session_factory() as session:
            data["session"] = session
            try:
                result = await handler(event, data)
                await session.commit()
                return result
            except Exception:
                await session.rollback()
                raise
