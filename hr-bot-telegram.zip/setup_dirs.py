"""
Creates required runtime directories.
Safe to run multiple times.
"""
from pathlib import Path

BASE_DIR = Path(__file__).parent

dirs = [
    BASE_DIR / "data",
    BASE_DIR / "data" / "photos",
    BASE_DIR / "data" / "logs",
    BASE_DIR / "app" / "web" / "static" / "css",
    BASE_DIR / "app" / "web" / "static" / "js",
]

for d in dirs:
    d.mkdir(parents=True, exist_ok=True)
    print(f"  ✅ {d}")

print("\nAll directories created.")
