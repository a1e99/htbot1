"""
Groups handler.
Allows managers to create Telegram groups with bot + custom members.

Commands (for managers only):
  /newgroup <title>        — create a new group
  /addtogroup <group_id>   — get invite link
  /mygroups                — list all groups
  /groupinfo <group_id>    — group details
  /archivegroup <group_id> — archive a group
"""
from __future__ import annotations

from aiogram import Router, Bot, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    Message,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    CallbackQuery,
    ChatPermissions,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from loguru import logger

from app.database import crud
from app.database.models import (
    BotGroup,
    BotGroupMember,
    GroupStatus,
    GroupMemberRole,
    Manager,
)
from app.bot.keyboards.keyboards import remove_keyboard

router = Router(name="groups")

# ─────────────────────────────────────────────
# FSM STATES
# ─────────────────────────────────────────────

class GroupCreationStates(StatesGroup):
    TITLE       = State()
    PURPOSE     = State()
    ADD_MEMBERS = State()
    CONFIRM     = State()


# ─────────────────────────────────────────────
# GUARDS
# ─────────────────────────────────────────────

async def _require_manager(message: Message, session: AsyncSession) -> Manager | None:
    """Return Manager or send error and return None."""
    manager = await crud.get_manager_by_telegram_id(session, message.from_user.id)
    if not manager:
        await message.answer("⛔ Эта команда доступна только менеджерам.")
        return None
    return manager


# ─────────────────────────────────────────────
# /newgroup  — start group creation FSM
# ─────────────────────────────────────────────

@router.message(Command("newgroup"))
async def cmd_new_group(message: Message, state: FSMContext, session: AsyncSession) -> None:
    manager = await _require_manager(message, session)
    if not manager:
        return

    # Check if command has inline title: /newgroup My Interview
    parts = message.text.split(maxsplit=1)
    if len(parts) > 1:
        title = parts[1].strip()
        await state.update_data(title=title, manager_id=manager.id)
        await state.set_state(GroupCreationStates.PURPOSE)
        await message.answer(
            f"📝 Название: <b>{title}</b>\n\n"
            "Укажите цель группы (необязательно) или нажмите /skip:",
            parse_mode="HTML",
        )
    else:
        await state.update_data(manager_id=manager.id)
        await state.set_state(GroupCreationStates.TITLE)
        await message.answer(
            "👥 <b>Создание новой группы</b>\n\n"
            "Введите название группы:",
            parse_mode="HTML",
        )


@router.message(GroupCreationStates.TITLE, F.text)
async def group_title(message: Message, state: FSMContext) -> None:
    title = message.text.strip()
    if len(title) < 3:
        await message.answer("⚠️ Название слишком короткое (минимум 3 символа).")
        return
    await state.update_data(title=title)
    await state.set_state(GroupCreationStates.PURPOSE)
    await message.answer(
        "📋 Укажите цель группы (например: «Собеседование — Иван Петров»)\n"
        "Или /skip чтобы пропустить:",
    )


@router.message(GroupCreationStates.PURPOSE, Command("skip"))
@router.message(GroupCreationStates.PURPOSE, F.text == "/skip")
async def group_purpose_skip(message: Message, state: FSMContext) -> None:
    await state.update_data(purpose=None)
    await _ask_members(message, state)


@router.message(GroupCreationStates.PURPOSE, F.text)
async def group_purpose(message: Message, state: FSMContext) -> None:
    await state.update_data(purpose=message.text.strip())
    await _ask_members(message, state)


async def _ask_members(message: Message, state: FSMContext) -> None:
    await state.update_data(extra_members=[])
    await state.set_state(GroupCreationStates.ADD_MEMBERS)
    await message.answer(
        "👤 <b>Добавление участников</b>\n\n"
        "Перешлите сообщения от людей которых хотите добавить,\n"
        "или введите их Telegram ID (по одному).\n\n"
        "Когда закончите — напишите <b>/done</b>",
        parse_mode="HTML",
    )


@router.message(GroupCreationStates.ADD_MEMBERS, Command("done"))
async def group_members_done(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    members = data.get("extra_members", [])
    title = data.get("title", "—")
    purpose = data.get("purpose", "не указана")

    members_text = "\n".join(
        f"  • {m.get('full_name') or m['telegram_id']}" for m in members
    ) if members else "  (только вы и бот)"

    await state.set_state(GroupCreationStates.CONFIRM)
    await message.answer(
        f"✅ <b>Подтверждение создания группы</b>\n\n"
        f"📌 Название: <b>{title}</b>\n"
        f"📋 Цель: {purpose}\n"
        f"👥 Дополнительные участники:\n{members_text}\n\n"
        "Создать группу?",
        parse_mode="HTML",
        reply_markup=_kb_confirm_group(),
    )


@router.message(GroupCreationStates.ADD_MEMBERS, F.forward_from)
async def group_add_forwarded(message: Message, state: FSMContext) -> None:
    """Add member by forwarded message."""
    user = message.forward_from
    data = await state.get_data()
    members = data.get("extra_members", [])

    if any(m["telegram_id"] == user.id for m in members):
        await message.answer(f"⚠️ {user.full_name} уже в списке.")
        return

    members.append({
        "telegram_id": user.id,
        "telegram_username": user.username,
        "full_name": user.full_name,
    })
    await state.update_data(extra_members=members)
    await message.answer(
        f"✅ Добавлен: <b>{user.full_name}</b>\n"
        f"Итого: {len(members)} участник(ов). Продолжайте или /done",
        parse_mode="HTML",
    )


@router.message(GroupCreationStates.ADD_MEMBERS, F.text)
async def group_add_by_id(message: Message, state: FSMContext) -> None:
    """Add member by Telegram ID."""
    text = message.text.strip()
    if text.startswith("/"):
        return

    if not text.lstrip("-").isdigit():
        await message.answer(
            "⚠️ Введите числовой Telegram ID или перешлите сообщение от пользователя.\n"
            "Или /done чтобы завершить."
        )
        return

    tg_id = int(text)
    data = await state.get_data()
    members = data.get("extra_members", [])

    if any(m["telegram_id"] == tg_id for m in members):
        await message.answer("⚠️ Этот ID уже в списке.")
        return

    members.append({"telegram_id": tg_id, "telegram_username": None, "full_name": f"ID:{tg_id}"})
    await state.update_data(extra_members=members)
    await message.answer(
        f"✅ Добавлен ID: <code>{tg_id}</code>\n"
        f"Итого: {len(members)} участник(ов). Продолжайте или /done",
        parse_mode="HTML",
    )


# ─────────────────────────────────────────────
# CONFIRM GROUP CREATION
# ─────────────────────────────────────────────

def _kb_confirm_group() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="✅ Создать группу", callback_data="group:confirm")
    b.button(text="❌ Отмена",         callback_data="group:cancel")
    b.adjust(1)
    return b.as_markup()


@router.callback_query(F.data == "group:confirm")
async def group_confirm(
    callback: CallbackQuery,
    state: FSMContext,
    session: AsyncSession,
    bot: Bot,
) -> None:
    data = await state.get_data()
    await state.clear()

    manager_id = data.get("manager_id")
    title      = data.get("title", "HR Group")
    purpose    = data.get("purpose")
    members    = data.get("extra_members", [])

    await callback.message.edit_text("⏳ Создаю группу...")

    try:
        # 1. Create Telegram supergroup via bot
        # NOTE: Bot must have permission to create groups.
        # We create a chat by adding the bot as admin in an existing group,
        # or use the forward_messages approach.
        # For actual group creation the bot must be admin in a channel/group
        # and use create_chat (available only for bots via Telegram Business or specific setups).
        # Standard workaround: create via bot API forwardMessages to a new chat.
        # 
        # REAL approach that works: ask manager to create group manually and
        # then add the bot, OR use /link command to link existing group.
        # Here we prepare the group record and give the manager instructions.

        # 2. Save to DB (telegram_chat_id = 0 until linked)
        group = BotGroup(
            telegram_chat_id=0,  # Will be updated when manager links the group
            title=title,
            purpose=purpose,
            status=GroupStatus.ACTIVE,
            created_by=manager_id,
        )
        session.add(group)
        await session.flush()

        # Save members
        manager_obj = await session.get(Manager, manager_id)
        if manager_obj:
            session.add(BotGroupMember(
                group_id=group.id,
                telegram_id=manager_obj.telegram_id,
                telegram_username=manager_obj.telegram_username,
                full_name=manager_obj.full_name,
                role=GroupMemberRole.OWNER,
            ))

        for m in members:
            session.add(BotGroupMember(
                group_id=group.id,
                telegram_id=m["telegram_id"],
                telegram_username=m.get("telegram_username"),
                full_name=m.get("full_name"),
                role=GroupMemberRole.MEMBER,
            ))

        await session.commit()

        # 3. Build invite instructions
        member_ids_text = "\n".join(
            f"• {m.get('full_name') or m['telegram_id']}" for m in members
        ) if members else "—"

        await callback.message.edit_text(
            f"✅ <b>Группа «{title}» создана в системе!</b>\n\n"
            f"🆔 ID группы в системе: <code>{group.id}</code>\n\n"
            f"<b>Следующий шаг:</b>\n"
            f"1. Создайте группу в Telegram вручную\n"
            f"2. Добавьте бота в группу как администратора\n"
            f"3. Отправьте в группе команду:\n"
            f"   <code>/linkgroup {group.id}</code>\n\n"
            f"👥 Участники для добавления:\n{member_ids_text}",
            parse_mode="HTML",
        )
        logger.info(f"Group '{title}' created in DB with id={group.id}")

    except Exception as e:
        await session.rollback()
        logger.error(f"Group creation failed: {e}")
        await callback.message.edit_text(f"❌ Ошибка создания группы: {e}")

    await callback.answer()


@router.callback_query(F.data == "group:cancel")
async def group_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.message.edit_text("❌ Создание группы отменено.")
    await callback.answer()


# ─────────────────────────────────────────────
# /linkgroup <group_id>  — link Telegram group to DB record
# (send this from inside the Telegram group after adding bot as admin)
# ─────────────────────────────────────────────

@router.message(Command("linkgroup"))
async def cmd_link_group(message: Message, session: AsyncSession, bot: Bot) -> None:
    """Called from inside a Telegram group by the manager after creating the group."""
    if message.chat.type not in ("group", "supergroup"):
        await message.answer("⚠️ Эту команду нужно отправить из группы.")
        return

    parts = message.text.split()
    if len(parts) < 2 or not parts[1].isdigit():
        await message.answer("Использование: <code>/linkgroup &lt;ID&gt;</code>", parse_mode="HTML")
        return

    group_id = int(parts[1])
    result = await session.execute(select(BotGroup).where(BotGroup.id == group_id))
    group = result.scalar_one_or_none()

    if not group:
        await message.answer(f"❌ Группа с ID {group_id} не найдена в системе.")
        return

    # Link Telegram chat_id
    group.telegram_chat_id = message.chat.id
    group.title = message.chat.title or group.title

    # Try to create invite link
    try:
        invite = await bot.create_chat_invite_link(message.chat.id, creates_join_request=False)
        group.invite_link = invite.invite_link
    except Exception:
        group.invite_link = None

    await session.commit()

    # Notify members
    members_result = await session.execute(
        select(BotGroupMember).where(BotGroupMember.group_id == group_id)
    )
    members = list(members_result.scalars().all())

    await message.answer(
        f"✅ <b>Группа успешно привязана!</b>\n\n"
        f"📌 Название: {group.title}\n"
        f"🔗 Ссылка: {group.invite_link or '—'}\n\n"
        f"Теперь вы можете добавлять участников через ссылку.",
        parse_mode="HTML",
    )

    # Send invite link to registered members who aren't in group yet
    if group.invite_link:
        owner_id = None
        if group.created_by:
            mgr = await session.get(Manager, group.created_by)
            if mgr:
                owner_id = mgr.telegram_id

        for m in members:
            if m.telegram_id == owner_id:
                continue
            try:
                await bot.send_message(
                    m.telegram_id,
                    f"👥 Вас приглашают в группу <b>{group.title}</b>\n\n"
                    f"🔗 Ссылка: {group.invite_link}",
                    parse_mode="HTML",
                )
            except Exception as e:
                logger.warning(f"Could not invite member {m.telegram_id}: {e}")

    logger.info(f"Group {group_id} linked to Telegram chat {message.chat.id}")


# ─────────────────────────────────────────────
# /mygroups  — list manager's groups
# ─────────────────────────────────────────────

@router.message(Command("mygroups"))
async def cmd_my_groups(message: Message, session: AsyncSession) -> None:
    manager = await _require_manager(message, session)
    if not manager:
        return

    result = await session.execute(
        select(BotGroup)
        .where(BotGroup.created_by == manager.id)
        .where(BotGroup.status == GroupStatus.ACTIVE)
        .order_by(BotGroup.created_at.desc())
    )
    groups = list(result.scalars().all())

    if not groups:
        await message.answer("У вас нет активных групп.\n\nСоздать: /newgroup")
        return

    lines = ["📋 <b>Ваши группы:</b>\n"]
    for g in groups:
        status_icon = "🟢" if g.telegram_chat_id else "🔴"
        linked = f"(не привязана — /linkgroup {g.id})" if not g.telegram_chat_id else "✅"
        lines.append(
            f"{status_icon} <b>{g.title}</b> {linked}\n"
            f"   ID: <code>{g.id}</code> | /groupinfo_{g.id}"
        )

    await message.answer("\n".join(lines), parse_mode="HTML")


# ─────────────────────────────────────────────
# /groupinfo_<id>
# ─────────────────────────────────────────────

@router.message(F.text.regexp(r"^/groupinfo_(\d+)$"))
async def cmd_group_info(message: Message, session: AsyncSession) -> None:
    manager = await _require_manager(message, session)
    if not manager:
        return

    group_id = int(message.text.split("_")[1])
    result = await session.execute(select(BotGroup).where(BotGroup.id == group_id))
    group = result.scalar_one_or_none()

    if not group:
        await message.answer("Группа не найдена.")
        return

    members_result = await session.execute(
        select(BotGroupMember)
        .where(BotGroupMember.group_id == group_id)
        .where(BotGroupMember.left_at.is_(None))
    )
    members = list(members_result.scalars().all())

    members_text = "\n".join(
        f"  {'👑' if m.role == GroupMemberRole.OWNER else '👤'} "
        f"{m.full_name or m.telegram_id}"
        for m in members
    ) or "  —"

    await message.answer(
        f"👥 <b>Группа: {group.title}</b>\n\n"
        f"🆔 ID: <code>{group.id}</code>\n"
        f"📋 Цель: {group.purpose or '—'}\n"
        f"🔗 Ссылка: {group.invite_link or 'не привязана'}\n"
        f"📊 Статус: {'🟢 Активна' if group.status == GroupStatus.ACTIVE else '🔴 Архив'}\n\n"
        f"👥 Участники ({len(members)}):\n{members_text}",
        parse_mode="HTML",
    )


# ─────────────────────────────────────────────
# /archivegroup <id>
# ─────────────────────────────────────────────

@router.message(Command("archivegroup"))
async def cmd_archive_group(message: Message, session: AsyncSession) -> None:
    manager = await _require_manager(message, session)
    if not manager:
        return

    parts = message.text.split()
    if len(parts) < 2 or not parts[1].isdigit():
        await message.answer("Использование: <code>/archivegroup &lt;ID&gt;</code>", parse_mode="HTML")
        return

    group_id = int(parts[1])
    result = await session.execute(select(BotGroup).where(BotGroup.id == group_id))
    group = result.scalar_one_or_none()

    if not group or group.created_by != manager.id:
        await message.answer("❌ Группа не найдена или у вас нет прав.")
        return

    from datetime import datetime
    group.status = GroupStatus.ARCHIVED
    group.archived_at = datetime.utcnow()
    await session.commit()

    await message.answer(f"📦 Группа «{group.title}» перемещена в архив.")
