"""
SQLAlchemy ORM models for HR Bot System.
"""
from __future__ import annotations

import enum
from datetime import datetime
from typing import Optional

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    JSON,
    Numeric,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base


# ─────────────────────────────────────────────
# ENUMS
# ─────────────────────────────────────────────

class CandidateStatus(str, enum.Enum):
    NEW = "new"
    IN_REVIEW = "in_review"
    APPROVED = "approved"
    REJECTED = "rejected"
    CLARIFICATION_NEEDED = "clarification_needed"
    BLOCKED = "blocked"


class MessageDirection(str, enum.Enum):
    IN = "in"
    OUT = "out"


class QuestionType(str, enum.Enum):
    OPEN = "open"
    CHOICE = "choice"
    YES_NO = "yes_no"


class ManagerDecisionType(str, enum.Enum):
    APPROVED = "approved"
    REJECTED = "rejected"
    CLARIFICATION = "clarification"
    TRANSFERRED = "transferred"


class SpamEventType(str, enum.Enum):
    FLOOD = "flood"
    FORBIDDEN_WORD = "forbidden_word"
    REPEAT_REGISTRATION = "repeat_registration"
    SHORT_MESSAGE = "short_message"
    BLOCKED = "blocked"


class ForbiddenWordCategory(str, enum.Enum):
    SPAM = "spam"
    OFFENSIVE = "offensive"
    IRRELEVANT = "irrelevant"


# ─────────────────────────────────────────────
# AGENCY
# ─────────────────────────────────────────────

class Agency(Base):
    __tablename__ = "agencies"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    slug: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    bot_token: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=func.now(), nullable=False
    )

    # Relationships
    companies: Mapped[list["Company"]] = relationship(back_populates="agency")
    managers: Mapped[list["Manager"]] = relationship(back_populates="agency")
    vacancies: Mapped[list["Vacancy"]] = relationship(back_populates="agency")
    candidates: Mapped[list["Candidate"]] = relationship(back_populates="agency")

    def __repr__(self) -> str:
        return f"<Agency {self.name}>"


# ─────────────────────────────────────────────
# COMPANY
# ─────────────────────────────────────────────

class Company(Base):
    __tablename__ = "companies"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    agency_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("agencies.id"), nullable=True
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    country: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())

    # Relationships
    agency: Mapped[Optional["Agency"]] = relationship(back_populates="companies")
    vacancies: Mapped[list["Vacancy"]] = relationship(back_populates="company")

    def __repr__(self) -> str:
        return f"<Company {self.name}>"


# ─────────────────────────────────────────────
# MANAGER
# ─────────────────────────────────────────────

class Manager(Base):
    __tablename__ = "managers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    agency_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("agencies.id"), nullable=True
    )
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, nullable=False)
    telegram_username: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    full_name: Mapped[str] = mapped_column(String(255), nullable=False)
    email: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    phone: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())

    # Relationships
    agency: Mapped[Optional["Agency"]] = relationship(back_populates="managers")
    assigned_candidates: Mapped[list["Candidate"]] = relationship(
        back_populates="assigned_manager"
    )
    decisions: Mapped[list["ManagerDecision"]] = relationship(back_populates="manager")

    def __repr__(self) -> str:
        return f"<Manager {self.full_name}>"


# ─────────────────────────────────────────────
# PROFESSION
# ─────────────────────────────────────────────

class ProfessionCategory(Base):
    __tablename__ = "profession_categories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    name_ru: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    icon: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)

    # Relationships
    professions: Mapped[list["Profession"]] = relationship(back_populates="category")

    def __repr__(self) -> str:
        return f"<ProfessionCategory {self.name}>"


class Profession(Base):
    __tablename__ = "professions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    category_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("profession_categories.id"), nullable=True
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    name_ru: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    skills: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    responsibilities: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    requirements: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    risks: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    # Relationships
    category: Mapped[Optional["ProfessionCategory"]] = relationship(
        back_populates="professions"
    )
    vacancies: Mapped[list["Vacancy"]] = relationship(back_populates="profession")
    quiz_questions: Mapped[list["QuizQuestion"]] = relationship(
        back_populates="profession"
    )
    candidates: Mapped[list["Candidate"]] = relationship(back_populates="profession")

    def __repr__(self) -> str:
        return f"<Profession {self.name_ru or self.name}>"


# ─────────────────────────────────────────────
# VACANCY
# ─────────────────────────────────────────────

class Vacancy(Base):
    __tablename__ = "vacancies"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    agency_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("agencies.id"), nullable=True
    )
    company_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("companies.id"), nullable=True
    )
    profession_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("professions.id"), nullable=True
    )
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    requirements: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    salary_from: Mapped[Optional[float]] = mapped_column(Numeric(10, 2), nullable=True)
    salary_to: Mapped[Optional[float]] = mapped_column(Numeric(10, 2), nullable=True)
    currency: Mapped[str] = mapped_column(String(10), default="USD")
    country: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    city: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    employment_type: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())

    # Relationships
    agency: Mapped[Optional["Agency"]] = relationship(back_populates="vacancies")
    company: Mapped[Optional["Company"]] = relationship(back_populates="vacancies")
    profession: Mapped[Optional["Profession"]] = relationship(
        back_populates="vacancies"
    )
    candidates: Mapped[list["Candidate"]] = relationship(back_populates="vacancy")

    def __repr__(self) -> str:
        return f"<Vacancy {self.title}>"


# ─────────────────────────────────────────────
# CANDIDATE
# ─────────────────────────────────────────────

class Candidate(Base):
    __tablename__ = "candidates"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    sequential_number: Mapped[int] = mapped_column(Integer, unique=True, nullable=False)

    # Foreign Keys
    agency_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("agencies.id"), nullable=True
    )
    vacancy_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("vacancies.id"), nullable=True
    )
    assigned_manager_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("managers.id"), nullable=True
    )
    profession_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("professions.id"), nullable=True
    )

    # Telegram
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, nullable=False)
    telegram_username: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)

    # Personal data
    full_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    phone: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    email: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    age: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    gender: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    nationality: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    current_country: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    current_city: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)

    # Professional
    experience_years: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    experience_details: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Photo
    photo_path: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    photo_telegram_id: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)

    # AI results
    summary: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    ai_analysis: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    weak_points: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    risks: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    quiz_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)

    # Status
    status: Mapped[CandidateStatus] = mapped_column(
        Enum(CandidateStatus), default=CandidateStatus.NEW
    )
    is_blocked: Mapped[bool] = mapped_column(Boolean, default=False)
    block_reason: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)

    # Registration state tracking
    registration_step: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    registration_started_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime, nullable=True
    )
    registration_completed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime, nullable=True
    )

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=func.now(), onupdate=func.now()
    )

    # Relationships
    agency: Mapped[Optional["Agency"]] = relationship(back_populates="candidates")
    vacancy: Mapped[Optional["Vacancy"]] = relationship(back_populates="candidates")
    assigned_manager: Mapped[Optional["Manager"]] = relationship(
        back_populates="assigned_candidates"
    )
    profession: Mapped[Optional["Profession"]] = relationship(
        back_populates="candidates"
    )
    messages: Mapped[list["CandidateMessage"]] = relationship(
        back_populates="candidate", order_by="CandidateMessage.created_at"
    )
    quiz_results: Mapped[list["QuizResult"]] = relationship(
        back_populates="candidate"
    )
    decisions: Mapped[list["ManagerDecision"]] = relationship(
        back_populates="candidate"
    )

    def __repr__(self) -> str:
        return f"<Candidate #{self.sequential_number} tg:{self.telegram_id}>"


# ─────────────────────────────────────────────
# MESSAGES
# ─────────────────────────────────────────────

class CandidateMessage(Base):
    __tablename__ = "candidate_messages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    candidate_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("candidates.id"), nullable=False
    )
    direction: Mapped[MessageDirection] = mapped_column(
        Enum(MessageDirection), nullable=False
    )
    message_type: Mapped[str] = mapped_column(String(50), default="text")
    content: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    telegram_msg_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())

    # Relationships
    candidate: Mapped["Candidate"] = relationship(back_populates="messages")


# ─────────────────────────────────────────────
# QUIZ
# ─────────────────────────────────────────────

class QuizQuestion(Base):
    __tablename__ = "quiz_questions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    profession_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("professions.id"), nullable=False
    )
    question_text: Mapped[str] = mapped_column(Text, nullable=False)
    question_type: Mapped[QuestionType] = mapped_column(
        Enum(QuestionType), default=QuestionType.OPEN
    )
    choices: Mapped[Optional[list]] = mapped_column(JSON, nullable=True)
    is_required: Mapped[bool] = mapped_column(Boolean, default=True)
    min_answer_length: Mapped[int] = mapped_column(Integer, default=10)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    ai_evaluate: Mapped[bool] = mapped_column(Boolean, default=True)

    # Relationships
    profession: Mapped["Profession"] = relationship(back_populates="quiz_questions")
    results: Mapped[list["QuizResult"]] = relationship(back_populates="question")


class QuizResult(Base):
    __tablename__ = "quiz_results"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    candidate_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("candidates.id"), nullable=False
    )
    question_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("quiz_questions.id"), nullable=False
    )
    answer: Mapped[str] = mapped_column(Text, nullable=False)
    ai_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    ai_comment: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    is_passed: Mapped[bool] = mapped_column(Boolean, default=True)
    answered_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())

    # Relationships
    candidate: Mapped["Candidate"] = relationship(back_populates="quiz_results")
    question: Mapped["QuizQuestion"] = relationship(back_populates="results")


# ─────────────────────────────────────────────
# MANAGER DECISIONS
# ─────────────────────────────────────────────

class ManagerDecision(Base):
    __tablename__ = "manager_decisions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    candidate_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("candidates.id"), nullable=False
    )
    manager_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("managers.id"), nullable=False
    )
    decision: Mapped[ManagerDecisionType] = mapped_column(
        Enum(ManagerDecisionType), nullable=False
    )
    comment: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())

    # Relationships
    candidate: Mapped["Candidate"] = relationship(back_populates="decisions")
    manager: Mapped["Manager"] = relationship(back_populates="decisions")


# ─────────────────────────────────────────────
# FORBIDDEN WORDS
# ─────────────────────────────────────────────

class ForbiddenWord(Base):
    __tablename__ = "forbidden_words"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    word: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    category: Mapped[ForbiddenWordCategory] = mapped_column(
        Enum(ForbiddenWordCategory), default=ForbiddenWordCategory.SPAM
    )
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    added_by: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("managers.id"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())


# ─────────────────────────────────────────────
# SPAM LOG
# ─────────────────────────────────────────────

class SpamLog(Base):
    __tablename__ = "spam_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    event_type: Mapped[SpamEventType] = mapped_column(
        Enum(SpamEventType), nullable=False
    )
    details: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())


# ─────────────────────────────────────────────
# GROUPS (Telegram group management)
# ─────────────────────────────────────────────

class GroupStatus(str, enum.Enum):
    ACTIVE = "active"
    ARCHIVED = "archived"
    DELETED = "deleted"


class GroupMemberRole(str, enum.Enum):
    OWNER = "owner"
    ADMIN = "admin"
    MEMBER = "member"
    CANDIDATE = "candidate"


class BotGroup(Base):
    """Telegram group/supergroup created and managed by the bot."""
    __tablename__ = "bot_groups"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    # Telegram chat_id (negative for groups)
    telegram_chat_id: Mapped[int] = mapped_column(
        BigInteger, unique=True, nullable=False
    )
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    invite_link: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    purpose: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    status: Mapped[GroupStatus] = mapped_column(
        Enum(GroupStatus), default=GroupStatus.ACTIVE
    )
    # Creator (manager)
    created_by: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("managers.id"), nullable=True
    )
    # Linked candidate (if group created for candidate interview)
    candidate_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("candidates.id"), nullable=True
    )
    agency_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("agencies.id"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())
    archived_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    # Relationships
    members: Mapped[list["BotGroupMember"]] = relationship(back_populates="group")
    creator: Mapped[Optional["Manager"]] = relationship(foreign_keys=[created_by])
    candidate: Mapped[Optional["Candidate"]] = relationship()

    def __repr__(self) -> str:
        return f"<BotGroup {self.title} ({self.telegram_chat_id})>"


class BotGroupMember(Base):
    """Members of a bot-managed group."""
    __tablename__ = "bot_group_members"
    __table_args__ = (
        UniqueConstraint("group_id", "telegram_id", name="uq_group_member"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    group_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("bot_groups.id"), nullable=False
    )
    telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    telegram_username: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    full_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    role: Mapped[GroupMemberRole] = mapped_column(
        Enum(GroupMemberRole), default=GroupMemberRole.MEMBER
    )
    added_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())
    left_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    # Relationships
    group: Mapped["BotGroup"] = relationship(back_populates="members")


# ─────────────────────────────────────────────
# KNOWLEDGE BASE (RAG documents)
# ─────────────────────────────────────────────

class KnowledgeDocType(str, enum.Enum):
    PDF  = "pdf"
    DOCX = "docx"
    TEXT = "text"
    URL  = "url"


class KnowledgeDoc(Base):
    """Document uploaded to the knowledge base for RAG."""
    __tablename__ = "knowledge_docs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    title: Mapped[str] = mapped_column(String(512), nullable=False)
    doc_type: Mapped[KnowledgeDocType] = mapped_column(
        Enum(KnowledgeDocType), nullable=False
    )
    source_path: Mapped[Optional[str]] = mapped_column(String(1024), nullable=True)
    source_url:  Mapped[Optional[str]] = mapped_column(String(2048), nullable=True)
    content_text: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    # Profession scope (null = applies to all)
    profession_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("professions.id"), nullable=True
    )
    chunk_count: Mapped[int] = mapped_column(Integer, default=0)
    is_indexed: Mapped[bool] = mapped_column(Boolean, default=False)
    uploaded_by: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("managers.id"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())
    indexed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    profession: Mapped[Optional["Profession"]] = relationship()
    uploader:   Mapped[Optional["Manager"]]    = relationship()

    def __repr__(self) -> str:
        return f"<KnowledgeDoc {self.title[:40]}>"


# ─────────────────────────────────────────────
# PUBLISH CHANNELS (Telegram channels for vacancy posting)
# ─────────────────────────────────────────────

class PublishChannel(Base):
    """Telegram channel/group where vacancies can be posted."""
    __tablename__ = "publish_channels"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    telegram_chat_id: Mapped[int] = mapped_column(BigInteger, unique=True, nullable=False)
    username: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    description: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    added_by: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("managers.id"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())
    last_post_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    def __repr__(self) -> str:
        return f"<PublishChannel {self.title}>"


class VacancyPublication(Base):
    """Log of vacancy posts to channels."""
    __tablename__ = "vacancy_publications"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    vacancy_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("vacancies.id"), nullable=False
    )
    channel_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("publish_channels.id"), nullable=False
    )
    telegram_message_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    posted_by: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("managers.id"), nullable=True
    )
    published_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())

    vacancy: Mapped["Vacancy"] = relationship()
    channel: Mapped["PublishChannel"] = relationship()


# ─────────────────────────────────────────────
# COMPANY PARTNERS (for candidate broadcast)
# ─────────────────────────────────────────────

class CompanyPartner(Base):
    """Partner companies that can receive candidate cards via bot."""
    __tablename__ = "company_partners"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    contact_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    telegram_chat_id: Mapped[Optional[int]] = mapped_column(BigInteger, nullable=True)
    telegram_username: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    email: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    specializations: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    added_by: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("managers.id"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())

    def __repr__(self) -> str:
        return f"<CompanyPartner {self.name}>"


class CandidateBroadcast(Base):
    """Log of candidate cards sent to partner companies."""
    __tablename__ = "candidate_broadcasts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    candidate_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("candidates.id"), nullable=False
    )
    partner_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("company_partners.id"), nullable=False
    )
    sent_by: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("managers.id"), nullable=True
    )
    message_text: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    sent_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())
    status: Mapped[str] = mapped_column(String(50), default="sent")

    candidate: Mapped["Candidate"]      = relationship()
    partner:   Mapped["CompanyPartner"] = relationship()
