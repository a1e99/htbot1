@echo off
chcp 65001 >nul
title HR Bot v6 - Install
cd /d "%~dp0"
color 0A

echo.
echo  ==============================================
echo   HR BOT SYSTEM v6 --- Ustanovka
echo  ==============================================
echo.

echo [1/6] Proverka Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python ne najden!
    echo.
    echo  Ustanovite Python 3.11+ s sajta:
    echo  https://www.python.org/downloads/
    echo.
    echo  VAZHNO: otmetjte "Add Python to PATH"
    echo.
    start https://www.python.org/downloads/
    pause & exit /b 1
)
for /f "tokens=*" %%i in ('python --version 2^>^&1') do set PYVER=%%i
echo [OK] %PYVER% najden.

echo [2/6] Proverka Docker...
docker --version >nul 2>&1
if errorlevel 1 (
    echo [WARN] Docker ne najden. NocoDB ne budet rabotat bez Docker.
    echo        Skachat: https://www.docker.com/products/docker-desktop/
    echo.
    set /p SKIP_D=Prodolzhat bez Docker? (y/n): 
    if /i not "%SKIP_D%"=="y" (
        start https://www.docker.com/products/docker-desktop/
        pause & exit /b 1
    )
) else (
    echo [OK] Docker najden.
)

echo [3/6] Virtualnoye okruzheniye...
if exist "venv\Scripts\python.exe" (
    echo [OK] venv uzhe est.
) else (
    python -m venv venv
    if errorlevel 1 ( echo [ERROR] ne udalos sozdat venv. & pause & exit /b 1 )
    echo [OK] venv sozdan.
)
call venv\Scripts\activate.bat

echo [4/6] Zavisimosti (3-5 minut)...
pip install -r requirements.txt --quiet --no-warn-script-location
if errorlevel 1 ( echo [ERROR] Oshibka. & pause & exit /b 1 )
echo [OK] Zavisimosti ustanovleny.

echo [5/6] Konfiguracziya .env...
if not exist ".env" (
    copy ".env.example" ".env" >nul
    echo.
    echo  +--------------------------------------------+
    echo  ^|  VAZHNO: zapolnite .env                    ^|
    echo  ^|  BOT_TOKEN=   (u @BotFather)               ^|
    echo  ^|  MANAGER_CHAT_IDS=  (vash Telegram ID)     ^|
    echo  ^|  Otkryvayu .env v Bloknote...              ^|
    echo  +--------------------------------------------+
    echo.
    notepad .env
    echo  Nazhmite Enter posle sohraneniya...
    pause >nul
) else (
    echo [OK] .env najden.
)

echo [6/6] Papki...
if not exist "data\photos" mkdir "data\photos"
if not exist "data\logs"   mkdir "data\logs"
if not exist "data\chroma" mkdir "data\chroma"
echo [OK] Papki sozdany.

echo.
echo  ==============================================
echo   Ustanovka zavershena!
echo  ==============================================
echo.
echo  Dalshajshie shagi:
echo.
echo  1. start.bat ^> [5] Zapustit NocoDB (Docker)
echo  2. Otkryt http://localhost:8080, sozdat account
echo  3. start.bat ^> [6] Nastroit tablicy NocoDB
echo     (ili veb-panel http://localhost:8000/settings)
echo  4. start.bat ^> [1] Zapustit vse
echo.
pause
