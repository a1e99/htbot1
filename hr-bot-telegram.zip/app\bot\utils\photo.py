"""
Utility to download and convert candidate photos to WEBP format.
"""
from __future__ import annotations

import io
from pathlib import Path

from aiogram import Bot
from aiogram.types import PhotoSize
from PIL import Image
from loguru import logger

from app.config import settings


async def download_and_convert_photo(
    bot: Bot,
    photo: PhotoSize,
    candidate_id: int,
) -> str | None:
    """
    Download photo from Telegram, convert to WEBP, save to disk.
    Returns the relative file path or None on error.
    """
    try:
        # Ensure photos dir exists
        photos_dir = settings.photos_dir
        photos_dir.mkdir(parents=True, exist_ok=True)

        # Download file from Telegram
        file = await bot.get_file(photo.file_id)
        file_bytes = await bot.download_file(file.file_path)

        # Convert to WEBP via Pillow
        image = Image.open(io.BytesIO(file_bytes.read()))

        # Resize to max 800x800 keeping aspect ratio
        image.thumbnail((800, 800), Image.LANCZOS)

        # Convert to RGB (required for WEBP)
        if image.mode in ("RGBA", "P"):
            image = image.convert("RGB")

        # Save
        filename = f"candidate_{candidate_id}.webp"
        filepath = photos_dir / filename
        image.save(filepath, format="WEBP", quality=85, optimize=True)

        logger.info(f"Photo saved: {filepath}")
        return str(filepath)

    except Exception as e:
        logger.error(f"Failed to process photo for candidate {candidate_id}: {e}")
        return None
