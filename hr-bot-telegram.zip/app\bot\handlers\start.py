"""
/start handler and candidate inline menu.
"""
from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from loguru import logger

from app.bot.states.registration import RegistrationStates, SubscriptionStates
from app.config import settings
from app.nocodb.client import noco

router = Router(name="start")

WARNING_TEXT = """
⚠️ <b>ВАЖНО! Прочитайте перед началом</b>

Данная анкета заполняется <b>только один раз</b>.

📋 Убедитесь в следующем:
• Информация должна быть <b>корректной и актуальной</b>
• После отправки <b>изменить данные нельзя</b>
• Повторная подача <b>невозможна</b>

✅ Выберите вакансию ниже и начните заполнение.
"""

STATUS_MAP = {
    "new": "🆕 Анкета получена, ожидает обработки.",
    "in_review": "🔍 Ваша анкета рассматривается менеджером.",
    "approved": "✅ Поздравляем! Ваша кандидатура одобрена.",
    "rejected": "❌ К сожалению, ваша кандидатура не прошла отбор.",
    "clarification_needed": "❓ Менеджер запросил уточнение. Ожидайте сообщения.",
    "blocked": "🚫 Ваш аккаунт заблокирован.",
}

STATE_LABELS = {
    RegistrationStates.WARNING.state: "выбор вакансии",
    RegistrationStates.FULL_NAME.state: "ФИО",
    RegistrationStates.PHONE.state: "телефон",
    RegistrationStates.EMAIL.state: "email",
    RegistrationStates.CITY.state: "город",
    RegistrationStates.RELOCATION.state: "готовность к переезду",
    RegistrationStates.RELOCATION_DETAILS.state: "детали переезда",
    RegistrationStates.SALARY_AMOUNT.state: "желаемая ставка",
    RegistrationStates.SALARY_CURRENCY.state: "валюта ставки",
    RegistrationStates.SALARY_PERIOD.state: "период ставки",
    RegistrationStates.SALARY_CONFIRM.state: "подтверждение ставки",
    RegistrationStates.AGE.state: "возраст",
    RegistrationStates.PHOTO.state: "фото",
    RegistrationStates.RESUME.state: "резюме",
    RegistrationStates.RESUME_SPECIALTY.state: "мини-резюме: специальность",
    RegistrationStates.RESUME_EXPERIENCE_YEARS.state: "мини-резюме: опыт",
    RegistrationStates.RESUME_EXPERIENCE_DETAILS.state: "мини-резюме: детали опыта",
    RegistrationStates.RESUME_SKILLS.state: "мини-резюме: навыки",
    RegistrationStates.RESUME_EDUCATION.state: "мини-резюме: образование",
    RegistrationStates.RESUME_LANGUAGES.state: "мини-резюме: языки",
    RegistrationStates.REMINDER_FREQUENCY.state: "частота напоминаний",
}


def _channel_url(channel_id: str) -> str | None:
    s = str(channel_id).strip()
    if s.startswith("@"):
        return f"https://t.me/{s.lstrip('@')}"
    return None


def _candidate_menu_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="💼 Вакансии", callback_data="candidate_menu:vacancies"),
                InlineKeyboardButton(text="📊 Мой статус", callback_data="candidate_menu:status"),
            ]
        ]
    )


def _in_progress_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="▶️ Продолжить", callback_data="candidate_menu:resume_form")],
            [InlineKeyboardButton(text="🔄 Начать заново", callback_data="candidate_menu:restart")],
            [InlineKeyboardButton(text="📊 Мой статус", callback_data="candidate_menu:status")],
        ]
    )


def _draft_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📄 Продолжить с резюме", callback_data="candidate_menu:resume_draft")],
            [InlineKeyboardButton(text="🔄 Начать заново", callback_data="candidate_menu:restart")],
        ]
    )


def _moderation_wait_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📊 Мой статус", callback_data="candidate_menu:status")],
            [InlineKeyboardButton(text="💼 Вакансии", callback_data="candidate_menu:vacancies")],
        ]
    )


def _resume_skip_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="⏭ Пропустить", callback_data="skip_resume")]]
    )


async def _is_subscribed(bot, user_id: int) -> bool:
    channels = settings.required_channel_ids
    if not channels:
        return True
    for channel in channels:
        try:
            member = await bot.get_chat_member(channel, user_id)
            if member.status in ("left", "kicked", "banned"):
                return False
        except Exception as exc:
            logger.warning(f"[Sub] check failed for {user_id} in {channel}: {exc}")
    return True


async def _send_subscription_gate(message: Message, state: FSMContext) -> None:
    await state.set_state(SubscriptionStates.WAITING)

    channels = settings.required_channel_ids
    titles = settings.required_channel_titles
    buttons: list[list[InlineKeyboardButton]] = []
    for i, channel_id in enumerate(channels):
        title = titles[i] if i < len(titles) else channel_id
        url = _channel_url(channel_id)
        if url:
            buttons.append([InlineKeyboardButton(text=f"📢 {title}", url=url)])
    buttons.append([InlineKeyboardButton(text="✅ Я подписался на все каналы", callback_data="check_sub")])

    channel_list = "\n".join(
        f"• <b>{titles[i] if i < len(titles) else ch}</b>" for i, ch in enumerate(channels)
    )
    await message.answer(
        f"👋 Привет, <b>{message.from_user.full_name}</b>!\n\n"
        f"Для использования бота необходимо подписаться на наши каналы:\n\n{channel_list}\n\n"
        "После подписки нажмите кнопку ниже 👇",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
    )


def _parse_deep_link(text: str) -> int | None:
    parts = (text or "").strip().split(maxsplit=1)
    if len(parts) < 2:
        return None
    payload = parts[1]
    for prefix in ("vacancy_", "v"):
        if payload.startswith(prefix):
            rest = payload[len(prefix):]
            if rest.isdigit():
                return int(rest)
    return None


async def _vacancy_keyboard() -> InlineKeyboardMarkup:
    vacancies = await noco.list_vacancies(active_only=True)
    buttons = [
        [InlineKeyboardButton(text=f"💼 {vac['title']}", callback_data=f"vacancy:{vac['Id']}")]
        for vac in vacancies
    ]
    if not buttons:
        buttons = [[InlineKeyboardButton(text="📋 Общая анкета", callback_data="vacancy:0")]]
    buttons.append([InlineKeyboardButton(text="📊 Мой статус", callback_data="candidate_menu:status")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def _status_text(candidate: dict | None) -> str:
    if not candidate:
        return "У вас пока нет завершённой анкеты."
    if candidate.get("resume_moderation_status") == "pending":
        return (
            "🛡️ Резюме на ручной модерации.\n\n"
            "После одобрения бот пришлёт кнопку для продолжения анкеты."
        )
    if candidate.get("photo_path") and not candidate.get("registration_completed_at"):
        return "📝 Анкета сохранена как черновик. Можно продолжить с шага резюме."
    if not candidate.get("registration_completed_at"):
        return "📝 Анкета ещё не завершена. Продолжите заполнение с текущего шага."
    status = candidate.get("status", "new")
    num = int(candidate.get("Id", 0) or 0)
    return (
        f"📊 <b>Статус #{num:06d}:</b>\n\n"
        f"{STATUS_MAP.get(status, 'Статус неизвестен.')}"
    )


async def _send_status_message(target: Message | CallbackQuery, user_id: int) -> None:
    candidate = await noco.get_candidate_by_telegram_id(user_id)
    text = _status_text(candidate)
    message = target.message if isinstance(target, CallbackQuery) else target
    await message.answer(text, parse_mode="HTML", reply_markup=_candidate_menu_keyboard())


async def _send_current_step_help(message: Message, state: FSMContext) -> None:
    current_state = await state.get_state()
    step_label = STATE_LABELS.get(current_state, "текущий шаг анкеты")
    await message.answer(
        f"📝 Анкета уже заполняется.\n\n"
        f"Текущий шаг: <b>{step_label}</b>\n"
        "Можно продолжить с текущего места или начать заполнение заново.",
        parse_mode="HTML",
        reply_markup=_in_progress_keyboard(),
    )


async def _restore_resume_step(message: Message, state: FSMContext, user_id: int) -> None:
    candidate = await noco.get_candidate_by_telegram_id(user_id)
    if not candidate:
        await message.answer("Черновик анкеты не найден. Начните заполнение заново.", reply_markup=_candidate_menu_keyboard())
        return

    await state.update_data(
        candidate_id=candidate.get("Id"),
        vacancy_id=int(candidate.get("vacancy_id", 0) or 0),
        vacancy_title=candidate.get("vacancy_title", ""),
    )
    await state.set_state(RegistrationStates.RESUME)
    await message.answer(
        "📄 Мы нашли незавершённую анкету.\n\n"
        "Продолжаем с шага резюме. Прикрепите файл PDF, DOC, DOCX или TXT, "
        "либо нажмите «Пропустить».",
        reply_markup=_resume_skip_keyboard(),
    )


async def _run_start(message: Message, state: FSMContext, user, deep_vacancy_id: int | None = None) -> None:
    telegram_id = user.id
    candidate = await noco.get_candidate_by_telegram_id(telegram_id)

    if candidate:
        if candidate.get("is_blocked"):
            await message.answer(
                "🚫 <b>Доступ ограничен.</b>\nВаш аккаунт заблокирован.",
                parse_mode="HTML",
            )
            return

        if candidate.get("registration_completed_at"):
            await message.answer(
                "📋 <b>Ваша анкета уже была отправлена.</b>\n\n" + _status_text(candidate),
                parse_mode="HTML",
                reply_markup=_candidate_menu_keyboard(),
            )
            return

        if candidate.get("resume_moderation_status") == "pending":
            await message.answer(
                "🛡️ Ваше резюме уже отправлено на модерацию.\n\n"
                "Как только его подтвердят, бот пришлёт кнопку для продолжения анкеты.",
                reply_markup=_moderation_wait_keyboard(),
            )
            return

        if candidate.get("photo_path"):
            await message.answer(
                "📝 Мы нашли незавершённую анкету после шага с фото.\n\n"
                "Можно продолжить с резюме или начать заполнение заново.",
                reply_markup=_draft_keyboard(),
            )
            return

    if deep_vacancy_id:
        vacancy = await noco.get_vacancy(deep_vacancy_id)
        if vacancy and vacancy.get("is_active"):
            vacancy_title = vacancy.get("title", "Вакансия")
            await message.answer(
                f"👋 Здравствуйте, <b>{user.full_name}</b>!\n\n"
                f"Вы перешли по ссылке на вакансию <b>«{vacancy_title}»</b>.\n\n"
                "Заполните анкету - это займёт 10-15 минут.",
                parse_mode="HTML",
            )
            await message.answer(WARNING_TEXT, parse_mode="HTML")
            await _start_registration(message, state, deep_vacancy_id, vacancy_title, user)
            return
        await message.answer("⚠️ Вакансия не найдена или уже закрыта. Выберите из актуальных:")

    await message.answer(
        f"👋 Здравствуйте, <b>{user.full_name}</b>!\n\n"
        "Добро пожаловать в систему подбора персонала.\n\n"
        "Процесс:\n"
        "1️⃣ Выбор вакансии\n"
        "2️⃣ Заполнение анкеты\n"
        "3️⃣ Профессиональный тест\n\n"
        "Примерное время: <b>10-15 минут</b>.",
        parse_mode="HTML",
        reply_markup=_candidate_menu_keyboard(),
    )
    await message.answer(WARNING_TEXT, parse_mode="HTML", reply_markup=await _vacancy_keyboard())
    await state.set_state(RegistrationStates.WARNING)


async def _start_registration(
    message: Message,
    state: FSMContext,
    vacancy_id: int | None,
    vacancy_title: str,
    user,
) -> None:
    await state.update_data(
        vacancy_id=vacancy_id or 0,
        vacancy_title=vacancy_title,
        telegram_id=user.id,
        full_name=user.full_name,
        username=user.username or "",
    )
    await state.set_state(RegistrationStates.FULL_NAME)
    await message.answer(
        f"✅ Выбрана вакансия: <b>{vacancy_title}</b>\n\n"
        "📝 Как вас зовут? Введите <b>ФИО полностью</b>:",
        parse_mode="HTML",
    )


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext) -> None:
    user = message.from_user
    logger.info(f"[/start] user={user.id} text={message.text!r}")

    current_state = await state.get_state()
    if current_state and current_state != SubscriptionStates.WAITING.state:
        await _send_current_step_help(message, state)
        return

    deep_vacancy_id = _parse_deep_link(message.text or "")
    if settings.required_channel_ids:
        subscribed = await _is_subscribed(message.bot, user.id)
        if not subscribed:
            await state.update_data(pending_vacancy_id=deep_vacancy_id)
            await _send_subscription_gate(message, state)
            return

    await _run_start(message, state, user, deep_vacancy_id)


@router.callback_query(F.data == "check_sub", SubscriptionStates.WAITING)
async def check_subscription_callback(callback: CallbackQuery, state: FSMContext) -> None:
    subscribed = await _is_subscribed(callback.bot, callback.from_user.id)
    if not subscribed:
        await callback.answer(
            "❌ Вы ещё не подписались на все каналы. Подпишитесь и попробуйте снова.",
            show_alert=True,
        )
        return

    await callback.message.edit_reply_markup()
    await callback.answer("✅ Подписка подтверждена!")
    data = await state.get_data()
    pending_vacancy_id = data.get("pending_vacancy_id")
    await state.clear()
    await _run_start(callback.message, state, callback.from_user, pending_vacancy_id)


@router.callback_query(F.data.startswith("candidate_menu:"))
async def candidate_menu_callback(callback: CallbackQuery, state: FSMContext) -> None:
    action = callback.data.split(":", 1)[1]

    if action == "status":
        await callback.answer()
        await _send_status_message(callback, callback.from_user.id)
        return

    if action == "vacancies":
        await callback.answer()
        candidate = await noco.get_candidate_by_telegram_id(callback.from_user.id)
        if candidate and candidate.get("registration_completed_at"):
            await callback.message.answer(
                "Вы уже подали анкету. Повторная подача не требуется.",
                reply_markup=_candidate_menu_keyboard(),
            )
            return
        await callback.message.answer(WARNING_TEXT, parse_mode="HTML", reply_markup=await _vacancy_keyboard())
        await state.set_state(RegistrationStates.WARNING)
        return

    if action == "resume_form":
        await callback.answer()
        current_state = await state.get_state()
        step_label = STATE_LABELS.get(current_state, "текущий шаг анкеты")
        await callback.message.answer(
            f"▶️ Продолжаем заполнение.\n\nТекущий шаг: <b>{step_label}</b>.",
            parse_mode="HTML",
        )
        return

    if action == "restart":
        await callback.answer("Начинаем заново")
        await state.clear()
        await _run_start(callback.message, state, callback.from_user)
        return

    if action == "resume_draft":
        await callback.answer()
        await _restore_resume_step(callback.message, state, callback.from_user.id)
        return

    await callback.answer()


@router.callback_query(F.data.startswith("vacancy:"))
async def select_vacancy(callback: CallbackQuery, state: FSMContext) -> None:
    vacancy_id = int(callback.data.split(":")[1])
    vacancy_title = "Общая анкета"
    if vacancy_id:
        vacancy = await noco.get_vacancy(vacancy_id)
        if vacancy:
            vacancy_title = vacancy.get("title", "Вакансия")

    await callback.message.edit_reply_markup()
    await _start_registration(callback.message, state, vacancy_id, vacancy_title, callback.from_user)
    await callback.answer()


@router.message(F.text == "📊 Статус моей заявки")
async def check_status(message: Message) -> None:
    await _send_status_message(message, message.from_user.id)
