"""
Resume upload, text extraction and AI parsing service.

Supported formats: PDF, DOCX, TXT.
Flow:
  1. Candidate sends document in Telegram
  2. Bot downloads the file
  3. Text is extracted from the file
  4. OpenAI extracts structured skills/experience profile
  5. Result is saved to NocoDB candidate record
"""
from __future__ import annotations

import io
import os
import tempfile
from pathlib import Path
from typing import Optional

from loguru import logger

from app.config import settings


# ─────────────────────────────────────────────
# TEXT EXTRACTION
# ─────────────────────────────────────────────

async def extract_text_from_bytes(data: bytes, filename: str) -> str:
    """Extract plain text from PDF, DOCX or TXT bytes."""
    ext = Path(filename).suffix.lower()
    try:
        if ext == ".pdf":
            return _extract_pdf(data)
        elif ext in (".docx", ".doc"):
            return _extract_docx(data)
        else:
            return data.decode("utf-8", errors="replace")
    except Exception as e:
        logger.error(f"[Resume] text extraction failed ({filename}): {e}")
        return ""


def _extract_pdf(data: bytes) -> str:
    try:
        from pypdf import PdfReader
        reader = PdfReader(io.BytesIO(data))
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    except ImportError:
        logger.warning("[Resume] pypdf not installed, trying pdfminer")
    try:
        from pdfminer.high_level import extract_text_to_fp
        from pdfminer.layout import LAParams
        out = io.StringIO()
        extract_text_to_fp(io.BytesIO(data), out, laparams=LAParams())
        return out.getvalue()
    except ImportError:
        logger.warning("[Resume] pdfminer not installed, falling back to raw bytes")
        return data.decode("utf-8", errors="replace")


def _extract_docx(data: bytes) -> str:
    try:
        import docx
        doc = docx.Document(io.BytesIO(data))
        return "\n".join(p.text for p in doc.paragraphs)
    except ImportError:
        logger.warning("[Resume] python-docx not installed")
        return data.decode("utf-8", errors="replace")


# ─────────────────────────────────────────────
# AI PARSING
# ─────────────────────────────────────────────

async def parse_resume_with_ai(text: str) -> dict:
    """
    Send resume text to OpenAI and get structured profile.
    Returns dict with keys: name, skills, experience_years,
    experience_details, education, languages, summary.
    """
    if not text.strip():
        return {}

    # Truncate to ~6000 chars to stay within token limits
    truncated = text[:6000]

    prompt = (
        "Ты — HR-эксперт. Проанализируй текст резюме и извлеки структурированные данные.\n\n"
        f"=== ТЕКСТ РЕЗЮМЕ ===\n{truncated}\n\n"
        "Верни JSON без markdown:\n"
        "{\n"
        '  "name": "ФИО кандидата или null",\n'
        '  "skills": ["навык1", "навык2", ...],\n'
        '  "experience_years": 3,\n'
        '  "experience_details": "Краткое описание опыта работы",\n'
        '  "education": "Образование",\n'
        '  "languages": ["Русский", "English"],\n'
        '  "summary": "Краткое профессиональное резюме (2-3 предложения)"\n'
        "}"
    )

    import json
    from app.services.openai_service import get_client
    from app.config import settings as cfg

    try:
        response = await get_client().chat.completions.create(
            model=cfg.openai_model,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=600,
            temperature=0.2,
        )
        raw = response.choices[0].message.content.strip()
        raw = raw.replace("```json", "").replace("```", "").strip()
        return json.loads(raw)
    except Exception as e:
        logger.error(f"[Resume] AI parse failed: {e}")
        return {}


# ─────────────────────────────────────────────
# SAVE RESUME FILE
# ─────────────────────────────────────────────

async def save_resume_file(data: bytes, filename: str, candidate_id: int) -> str:
    """Save resume bytes to disk. Returns saved file path."""
    resumes_dir = Path(settings.photos_dir).parent / "resumes"
    resumes_dir.mkdir(parents=True, exist_ok=True)
    ext = Path(filename).suffix.lower() or ".pdf"
    path = resumes_dir / f"candidate_{candidate_id}{ext}"
    path.write_bytes(data)
    logger.info(f"[Resume] saved to {path}")
    return str(path)


# ─────────────────────────────────────────────
# DOWNLOAD FROM TELEGRAM
# ─────────────────────────────────────────────

async def download_document(bot, file_id: str) -> bytes:
    """Download file from Telegram by file_id."""
    tg_file = await bot.get_file(file_id)
    buf = io.BytesIO()
    await bot.download_file(tg_file.file_path, buf)
    return buf.getvalue()
