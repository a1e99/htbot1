"""
Standalone web panel runner.
Usage: python run_web.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

import uvicorn
from app.config import settings
from app.logger import setup_logger

if __name__ == "__main__":
    setup_logger()
    uvicorn.run(
        "app.api.main:app",
        host=settings.web_host,
        port=settings.web_port,
        reload=False,
        log_level="info",
    )
