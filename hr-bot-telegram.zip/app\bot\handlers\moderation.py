"""
Moderation router for manager decisions and vacancy publication flow.
"""
from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from loguru import logger

from app.bot.handlers import registration as registration_handler
from app.config import settings
from app.nocodb.client import noco
from app.services.moderation_service import (
    finalize_moderation_record,
    moderate_vacancy_publication,
    parse_target_ids,
)

router = Router(name="moderation")


def _is_manager(tg_id: int) -> bool:
    return tg_id in settings.manager_chat_ids


class PublishModerationStates(StatesGroup):
    CHOOSING_VACANCY = State()
    CHOOSING_CHANNELS = State()


def _vacancy_moderation_keyboard(queue_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ Опубликовать", callback_data=f"mod_vacancy_approve:{queue_id}"),
                InlineKeyboardButton(text="❌ Отклонить", callback_data=f"mod_vacancy_reject:{queue_id}"),
            ]
        ]
    )


async def _execute_publication(bot, vacancy: dict, channels: list[dict], posted_by: int) -> tuple[int, int]:
    from app.services.notification_service import notify_candidates_about_new_vacancy, publish_vacancy_to_channel

    sent = 0
    for channel in channels:
        if not channel:
            continue
        ok = await publish_vacancy_to_channel(bot, vacancy, channel["telegram_chat_id"], posted_by)
        if ok:
            sent += 1

    notified = 0
    if sent:
        try:
            notified = await notify_candidates_about_new_vacancy(bot, vacancy)
        except Exception as exc:
            logger.warning(f"[Moderation] candidate notifications failed: {exc}")

    return sent, notified


async def _notify_managers_vacancy_moderation(
    *,
    queue_id: int,
    vacancy: dict,
    channels: list[dict],
    reason: str,
    bot,
) -> None:
    channel_names = ", ".join(ch.get("title", str(ch.get("telegram_chat_id"))) for ch in channels if ch) or "не выбраны"
    text = (
        "🛡️ <b>Вакансия ожидает ручной модерации</b>\n\n"
        f"Вакансия: <b>{vacancy.get('title', 'Без названия')}</b>\n"
        f"Каналы: {channel_names}\n\n"
        f"Причина AI: {reason}\n\n"
        f"{(vacancy.get('description', '') or '')[:1200]}"
    )
    kb = _vacancy_moderation_keyboard(queue_id)
    for manager_id in settings.manager_chat_ids:
        try:
            await bot.send_message(manager_id, text, parse_mode="HTML", reply_markup=kb)
        except Exception as exc:
            logger.warning(f"[Moderation] notify manager {manager_id} failed: {exc}")


@router.message(Command("publish_vacancy"))
async def cmd_publish_moderated(message: Message, state: FSMContext):
    if not _is_manager(message.from_user.id):
        return
    vacs = await noco.list_vacancies(active_only=True)
    if not vacs:
        await message.answer("Нет активных вакансий.")
        return
    btns = [[InlineKeyboardButton(text=f"💼 {v['title']}", callback_data=f"pv_mod:{v['Id']}")] for v in vacs]
    await message.answer("Выберите вакансию:", reply_markup=InlineKeyboardMarkup(inline_keyboard=btns))
    await state.set_state(PublishModerationStates.CHOOSING_VACANCY)


@router.callback_query(F.data.startswith("pv_mod:"), PublishModerationStates.CHOOSING_VACANCY)
async def pub_choose_channel_moderated(cb: CallbackQuery, state: FSMContext):
    vid = int(cb.data.split(":")[1])
    channels = await noco.list_channels()
    if not channels:
        await cb.message.answer("Нет каналов. Добавьте через /add_channel")
        await state.clear()
        await cb.answer()
        return
    await state.update_data(pub_vid=vid)
    btns = [[InlineKeyboardButton(text=f"📢 {c['title']}", callback_data=f"pc_mod:{c['Id']}")] for c in channels]
    btns.append([InlineKeyboardButton(text="📢 Все каналы", callback_data="pc_mod:all")])
    await cb.message.edit_reply_markup()
    await cb.message.answer("Выберите канал:", reply_markup=InlineKeyboardMarkup(inline_keyboard=btns))
    await state.set_state(PublishModerationStates.CHOOSING_CHANNELS)
    await cb.answer()


@router.callback_query(F.data.startswith("pc_mod:"), PublishModerationStates.CHOOSING_CHANNELS)
async def pub_execute_moderated(cb: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    vid = data["pub_vid"]
    selected = cb.data.split(":")[1]
    vacancy = await noco.get_vacancy(vid)
    if not vacancy:
        await cb.answer("Вакансия не найдена.", show_alert=True)
        await state.clear()
        return

    channels = await noco.list_channels() if selected == "all" else [await noco.get_record(settings.noco_table_channels, int(selected))]
    channels = [channel for channel in channels if channel]
    if not channels:
        await cb.answer("Каналы не найдены.", show_alert=True)
        await state.clear()
        return

    decision, queue = await moderate_vacancy_publication(
        vacancy=vacancy,
        requested_by=cb.from_user.id,
        channel_ids=[int(ch["Id"]) for ch in channels if ch.get("Id")],
    )
    await state.clear()
    await cb.message.edit_reply_markup()

    if decision.is_rejected:
        await cb.message.answer(
            "🚫 Публикация отклонена AI-модерацией.\n\n"
            f"Причина: {decision.reason}"
        )
        await cb.answer()
        return

    if decision.is_approved:
        sent, notified = await _execute_publication(cb.bot, vacancy, channels, cb.from_user.id)
        queue_id = int(queue["Id"]) if queue and queue.get("Id") else 0
        if queue_id:
            await finalize_moderation_record(queue_id, status="approved", reviewer_telegram_id=cb.from_user.id, reviewer_comment="Auto-approved by AI")
        await cb.message.answer(
            f"📢 «{vacancy['title']}» опубликована в {sent}/{len(channels)} каналов.\n"
            + (f"🔔 Уведомлено {notified} подходящих кандидатов." if notified else "")
        )
        await cb.answer()
        return

    if queue and queue.get("Id"):
        await _notify_managers_vacancy_moderation(
            queue_id=int(queue["Id"]),
            vacancy=vacancy,
            channels=channels,
            reason=decision.reason,
            bot=cb.bot,
        )
    await cb.message.answer(
        "🛡️ Публикация отправлена на ручную модерацию менеджеру.\n"
        "После подтверждения вакансия будет опубликована."
    )
    await cb.answer()


@router.callback_query(F.data.startswith("mod_resume_approve:"))
async def mod_resume_approve(cb: CallbackQuery):
    if not _is_manager(cb.from_user.id):
        await cb.answer("Нет доступа.", show_alert=True)
        return
    queue_id = int(cb.data.split(":")[1])
    queue = await noco.get_record(settings.noco_table_moderation_queue, queue_id)
    if not queue or queue.get("item_type") != "resume":
        await cb.answer("Запись модерации не найдена.", show_alert=True)
        return

    candidate_id = int(queue.get("entity_id", 0) or 0)
    await finalize_moderation_record(queue_id, status="approved", reviewer_telegram_id=cb.from_user.id)
    await noco.update_candidate(
        candidate_id,
        {
            "resume_moderation_status": "approved",
            "resume_moderation_note": "Approved by manager",
            "resume_moderation_reviewed_at": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(),
        },
    )
    candidate = await noco.get_record(settings.noco_table_candidates, candidate_id)
    if candidate and candidate.get("telegram_id"):
        try:
            await cb.bot.send_message(
                candidate["telegram_id"],
                "✅ Резюме прошло ручную модерацию.\nНажмите кнопку ниже, чтобы продолжить анкету.",
                reply_markup=registration_handler._resume_continue_keyboard(candidate_id),
            )
        except Exception as exc:
            logger.warning(f"[Moderation] notify candidate failed: {exc}")

    await cb.message.edit_reply_markup()
    await cb.message.reply(f"✅ Резюме кандидата #{candidate_id:06d} одобрено.")
    await cb.answer("Одобрено")


@router.callback_query(F.data.startswith("mod_resume_reject:"))
async def mod_resume_reject(cb: CallbackQuery):
    if not _is_manager(cb.from_user.id):
        await cb.answer("Нет доступа.", show_alert=True)
        return
    queue_id = int(cb.data.split(":")[1])
    queue = await noco.get_record(settings.noco_table_moderation_queue, queue_id)
    if not queue or queue.get("item_type") != "resume":
        await cb.answer("Запись модерации не найдена.", show_alert=True)
        return

    candidate_id = int(queue.get("entity_id", 0) or 0)
    await finalize_moderation_record(queue_id, status="rejected", reviewer_telegram_id=cb.from_user.id)
    await noco.update_candidate(
        candidate_id,
        {
            "resume_moderation_status": "rejected",
            "resume_moderation_note": "Rejected by manager",
            "status": "clarification_needed",
            "resume_moderation_reviewed_at": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(),
        },
    )
    candidate = await noco.get_record(settings.noco_table_candidates, candidate_id)
    if candidate and candidate.get("telegram_id"):
        try:
            await cb.bot.send_message(
                candidate["telegram_id"],
                "❌ Резюме не прошло модерацию. Менеджер свяжется с вами, если понадобится уточнение.",
            )
        except Exception as exc:
            logger.warning(f"[Moderation] notify candidate failed: {exc}")

    await cb.message.edit_reply_markup()
    await cb.message.reply(f"❌ Резюме кандидата #{candidate_id:06d} отклонено.")
    await cb.answer("Отклонено")


@router.callback_query(F.data.startswith("mod_vacancy_approve:"))
async def mod_vacancy_approve(cb: CallbackQuery):
    if not _is_manager(cb.from_user.id):
        await cb.answer("Нет доступа.", show_alert=True)
        return
    queue_id = int(cb.data.split(":")[1])
    queue = await noco.get_record(settings.noco_table_moderation_queue, queue_id)
    if not queue or queue.get("item_type") != "vacancy_publication":
        await cb.answer("Запись модерации не найдена.", show_alert=True)
        return

    vacancy_id = int(queue.get("entity_id", 0) or 0)
    vacancy = await noco.get_vacancy(vacancy_id)
    channel_ids = parse_target_ids(queue)
    channels = [await noco.get_record(settings.noco_table_channels, cid) for cid in channel_ids]
    channels = [ch for ch in channels if ch]
    sent, notified = await _execute_publication(cb.bot, vacancy, channels, cb.from_user.id)
    await finalize_moderation_record(queue_id, status="approved", reviewer_telegram_id=cb.from_user.id)
    await cb.message.edit_reply_markup()
    await cb.message.reply(
        f"📢 Вакансия опубликована в {sent}/{len(channels)} каналов."
        + (f"\n🔔 Уведомлено {notified} подходящих кандидатов." if notified else "")
    )
    await cb.answer("Опубликовано")


@router.callback_query(F.data.startswith("mod_vacancy_reject:"))
async def mod_vacancy_reject(cb: CallbackQuery):
    if not _is_manager(cb.from_user.id):
        await cb.answer("Нет доступа.", show_alert=True)
        return
    queue_id = int(cb.data.split(":")[1])
    queue = await noco.get_record(settings.noco_table_moderation_queue, queue_id)
    if not queue or queue.get("item_type") != "vacancy_publication":
        await cb.answer("Запись модерации не найдена.", show_alert=True)
        return

    await finalize_moderation_record(queue_id, status="rejected", reviewer_telegram_id=cb.from_user.id)
    await cb.message.edit_reply_markup()
    await cb.message.reply("❌ Публикация вакансии отклонена модератором.")
    await cb.answer("Отклонено")
