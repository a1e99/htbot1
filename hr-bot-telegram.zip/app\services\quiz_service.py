"""
Quiz service — manages quiz session state and scoring.
Keeps quiz logic separate from the FSM handler.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import crud
from app.database.models import QuizQuestion, QuizResult


@dataclass
class QuizSession:
    """In-memory state of a single candidate's quiz session."""
    candidate_id: int
    profession_id: int
    questions: list[QuizQuestion]
    current_index: int = 0
    answers: list[dict] = field(default_factory=list)

    @property
    def current_question(self) -> Optional[QuizQuestion]:
        if self.current_index < len(self.questions):
            return self.questions[self.current_index]
        return None

    @property
    def is_finished(self) -> bool:
        return self.current_index >= len(self.questions)

    @property
    def total(self) -> int:
        return len(self.questions)

    @property
    def progress_text(self) -> str:
        return f"Вопрос {self.current_index + 1} из {self.total}"


class QuizService:
    """Handles quiz flow for a candidate."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def start_quiz(
        self, candidate_id: int, profession_id: int
    ) -> QuizSession:
        """Load questions and return a new QuizSession."""
        questions = list(
            await crud.get_quiz_questions(self.session, profession_id)
        )
        logger.info(
            f"[QuizService] Starting quiz for candidate {candidate_id}, "
            f"profession {profession_id}, {len(questions)} questions"
        )
        return QuizSession(
            candidate_id=candidate_id,
            profession_id=profession_id,
            questions=questions,
        )

    async def submit_answer(
        self,
        session_obj: QuizSession,
        answer: str,
        profession_name: str = "",
    ) -> dict:
        """
        Validate answer, optionally evaluate with AI,
        save to DB, advance session.
        Returns dict with: ok, error, ai_score, ai_comment.
        """
        question = session_obj.current_question
        if question is None:
            return {"ok": False, "error": "no_question"}

        # ── Length validation ──
        min_len = question.min_answer_length or 10
        if len(answer.strip()) < min_len:
            return {
                "ok": False,
                "error": "too_short",
                "min_len": min_len,
            }

        # ── AI evaluation ──
        ai_score: Optional[float] = None
        ai_comment: Optional[str] = None

        if question.ai_evaluate:
            try:
                from app.services.openai_service import evaluate_quiz_answer
                ai_score, ai_comment = await evaluate_quiz_answer(
                    question=question.question_text,
                    answer=answer,
                    profession=profession_name,
                )
            except Exception as e:
                logger.warning(f"[QuizService] AI eval failed: {e}")

        # ── Save to DB ──
        await crud.save_quiz_result(
            self.session,
            candidate_id=session_obj.candidate_id,
            question_id=question.id,
            answer=answer,
            ai_score=ai_score,
            ai_comment=ai_comment,
            is_passed=True,
        )

        # ── Track in session ──
        session_obj.answers.append({
            "question_id": question.id,
            "question_text": question.question_text,
            "answer": answer,
            "ai_score": ai_score,
            "ai_comment": ai_comment,
        })

        # ── Advance ──
        session_obj.current_index += 1

        return {
            "ok": True,
            "ai_score": ai_score,
            "ai_comment": ai_comment,
        }

    async def finalise(self, session_obj: QuizSession) -> float | None:
        """
        Calculate and persist average quiz score.
        Returns the average score (0-10) or None.
        """
        avg = await crud.calculate_quiz_score(
            self.session, session_obj.candidate_id
        )
        if avg is not None:
            await crud.update_candidate(
                self.session,
                session_obj.candidate_id,
                quiz_score=round(avg, 2),
            )
            logger.info(
                f"[QuizService] Candidate {session_obj.candidate_id} "
                f"quiz finalised, avg score: {avg:.2f}"
            )
        return avg

    @staticmethod
    def score_label(score: float | None) -> str:
        """Human-readable score label."""
        if score is None:
            return "—"
        if score >= 8:
            return f"🌟 {score:.1f}/10 — Отлично"
        if score >= 6:
            return f"✅ {score:.1f}/10 — Хорошо"
        if score >= 4:
            return f"⚠️ {score:.1f}/10 — Удовлетворительно"
        return f"❌ {score:.1f}/10 — Слабо"
