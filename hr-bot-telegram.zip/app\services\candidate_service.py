"""
Candidate service — business logic for candidate lifecycle.
Separates business rules from raw CRUD operations.
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import crud
from app.database.models import (
    Candidate,
    CandidateStatus,
    ManagerDecisionType,
    MessageDirection,
)


class CandidateService:
    """High-level operations on candidates."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    # ─────────────────────────────────────────
    # REGISTRATION
    # ─────────────────────────────────────────

    async def can_register(self, telegram_id: int) -> tuple[bool, str]:
        """
        Check whether a user is allowed to start registration.
        Returns (allowed: bool, reason: str).
        """
        candidate = await crud.get_candidate_by_telegram_id(self.session, telegram_id)

        if candidate is None:
            return True, ""

        if candidate.is_blocked:
            return False, "blocked"

        if candidate.registration_completed_at is not None:
            return False, "already_submitted"

        # Incomplete registration — allow re-entry
        return True, "resume"

    async def get_or_create_candidate(
        self,
        telegram_id: int,
        telegram_username: Optional[str] = None,
        agency_id: Optional[int] = None,
        vacancy_id: Optional[int] = None,
    ) -> Candidate:
        """Return existing candidate or create a new one."""
        candidate = await crud.get_candidate_by_telegram_id(self.session, telegram_id)
        if candidate:
            return candidate
        candidate = await crud.create_candidate(
            self.session,
            telegram_id=telegram_id,
            telegram_username=telegram_username,
            agency_id=agency_id,
            vacancy_id=vacancy_id,
        )
        logger.info(
            f"[CandidateService] Created candidate #{candidate.sequential_number} "
            f"for TG {telegram_id}"
        )
        return candidate

    async def complete_registration(self, candidate_id: int) -> None:
        """Mark registration as complete and update status."""
        await crud.update_candidate(
            self.session,
            candidate_id,
            registration_completed_at=datetime.utcnow(),
            status=CandidateStatus.NEW,
        )
        logger.info(f"[CandidateService] Candidate {candidate_id} registration completed")

    # ─────────────────────────────────────────
    # STATUS TRANSITIONS
    # ─────────────────────────────────────────

    async def approve(
        self,
        candidate_id: int,
        manager_id: int,
        comment: Optional[str] = None,
    ) -> Candidate:
        """Approve a candidate."""
        await crud.update_candidate_status(self.session, candidate_id, CandidateStatus.APPROVED)
        await crud.assign_manager(self.session, candidate_id, manager_id)
        await crud.create_manager_decision(
            self.session, candidate_id, manager_id,
            ManagerDecisionType.APPROVED, comment
        )
        candidate = await crud.get_candidate_by_id(self.session, candidate_id)
        logger.info(f"[CandidateService] Candidate {candidate_id} APPROVED by manager {manager_id}")
        return candidate

    async def reject(
        self,
        candidate_id: int,
        manager_id: int,
        comment: Optional[str] = None,
    ) -> Candidate:
        """Reject a candidate."""
        await crud.update_candidate_status(self.session, candidate_id, CandidateStatus.REJECTED)
        await crud.create_manager_decision(
            self.session, candidate_id, manager_id,
            ManagerDecisionType.REJECTED, comment
        )
        candidate = await crud.get_candidate_by_id(self.session, candidate_id)
        logger.info(f"[CandidateService] Candidate {candidate_id} REJECTED by manager {manager_id}")
        return candidate

    async def request_clarification(
        self,
        candidate_id: int,
        manager_id: int,
        comment: Optional[str] = None,
    ) -> Candidate:
        """Set status to clarification_needed."""
        await crud.update_candidate_status(
            self.session, candidate_id, CandidateStatus.CLARIFICATION_NEEDED
        )
        await crud.create_manager_decision(
            self.session, candidate_id, manager_id,
            ManagerDecisionType.CLARIFICATION, comment
        )
        return await crud.get_candidate_by_id(self.session, candidate_id)

    async def transfer(
        self,
        candidate_id: int,
        from_manager_id: int,
        to_manager_id: int,
    ) -> Candidate:
        """Transfer candidate to another manager."""
        await crud.assign_manager(self.session, candidate_id, to_manager_id)
        await crud.create_manager_decision(
            self.session, candidate_id, from_manager_id,
            ManagerDecisionType.TRANSFERRED,
            f"Transferred to manager ID {to_manager_id}",
        )
        logger.info(
            f"[CandidateService] Candidate {candidate_id} transferred "
            f"{from_manager_id} → {to_manager_id}"
        )
        return await crud.get_candidate_by_id(self.session, candidate_id)

    # ─────────────────────────────────────────
    # MESSAGE LOGGING
    # ─────────────────────────────────────────

    async def log_incoming(
        self,
        candidate_id: int,
        text: str,
        msg_type: str = "text",
        tg_msg_id: Optional[int] = None,
    ) -> None:
        await crud.save_message(
            self.session, candidate_id,
            MessageDirection.IN, text, msg_type, tg_msg_id
        )

    async def log_outgoing(
        self,
        candidate_id: int,
        text: str,
        tg_msg_id: Optional[int] = None,
    ) -> None:
        await crud.save_message(
            self.session, candidate_id,
            MessageDirection.OUT, text, "text", tg_msg_id
        )

    # ─────────────────────────────────────────
    # BLOCKING
    # ─────────────────────────────────────────

    async def block(self, telegram_id: int, reason: str) -> None:
        await crud.block_candidate(self.session, telegram_id, reason)
        logger.warning(
            f"[CandidateService] Blocked TG {telegram_id}: {reason}"
        )

    # ─────────────────────────────────────────
    # QUERIES
    # ─────────────────────────────────────────

    async def get_by_telegram_id(self, telegram_id: int) -> Optional[Candidate]:
        return await crud.get_candidate_by_telegram_id(self.session, telegram_id)

    async def get_by_id(self, candidate_id: int) -> Optional[Candidate]:
        return await crud.get_candidate_by_id(self.session, candidate_id)

    async def get_status_text(self, candidate: Candidate) -> str:
        """Human-readable status for the candidate."""
        status_map = {
            CandidateStatus.NEW: (
                "📨 Ваша заявка получена и ожидает рассмотрения."
            ),
            CandidateStatus.IN_REVIEW: (
                "🔍 Ваша анкета сейчас рассматривается менеджером.\n"
                "Ожидайте уведомления."
            ),
            CandidateStatus.APPROVED: self._build_approved_text(candidate),
            CandidateStatus.REJECTED: (
                "❌ К сожалению, ваша кандидатура не прошла отбор.\n"
                "Благодарим за интерес!"
            ),
            CandidateStatus.CLARIFICATION_NEEDED: (
                "❓ Менеджер запросил дополнительную информацию.\n"
                "Пожалуйста, свяжитесь с менеджером напрямую."
            ),
            CandidateStatus.BLOCKED: (
                "🚫 Ваш аккаунт ограничен.\n"
                "Обратитесь к администратору."
            ),
        }
        status = (
            CandidateStatus(candidate.status)
            if isinstance(candidate.status, str)
            else candidate.status
        )
        return status_map.get(status, "Статус неизвестен.")

    @staticmethod
    def _build_approved_text(candidate: Candidate) -> str:
        text = "✅ Поздравляем! Ваша кандидатура одобрена!\n\n"
        if candidate.assigned_manager:
            m = candidate.assigned_manager
            text += f"👤 Ваш менеджер: <b>{m.full_name}</b>\n"
            if m.phone:
                text += f"📞 Телефон: <code>{m.phone}</code>\n"
            if m.telegram_username:
                text += f"💬 Telegram: @{m.telegram_username}\n"
        text += "\nМенеджер свяжется с вами в ближайшее время."
        return text
