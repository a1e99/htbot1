"""Candidates API router."""
from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.schemas.schemas import (
    CandidateDetail,
    CandidateListResponse,
    CandidateUpdate,
    OkResponse,
)
from app.database.base import get_session
from app.database import crud
from app.database.models import CandidateStatus

router = APIRouter(prefix="/candidates", tags=["candidates"])


@router.get("", response_model=CandidateListResponse)
async def list_candidates(
    status: Optional[str] = Query(None),
    agency_id: Optional[int] = Query(None),
    limit: int = Query(50, le=200),
    offset: int = Query(0),
    session: AsyncSession = Depends(get_session),
):
    status_enum = CandidateStatus(status) if status else None
    total = await crud.count_candidates(session, agency_id=agency_id, status=status_enum)
    items = await crud.get_all_candidates(
        session, agency_id=agency_id, status=status_enum, limit=limit, offset=offset
    )
    return CandidateListResponse(total=total, items=list(items))


@router.get("/{candidate_id}", response_model=CandidateDetail)
async def get_candidate(
    candidate_id: int,
    session: AsyncSession = Depends(get_session),
):
    candidate = await crud.get_candidate_by_id(session, candidate_id)
    if not candidate:
        raise HTTPException(status_code=404, detail="Candidate not found")
    # Enrich quiz results with question text
    for qr in candidate.quiz_results:
        if qr.question:
            qr.__dict__["question_text"] = qr.question.question_text
    return candidate


@router.patch("/{candidate_id}", response_model=OkResponse)
async def update_candidate(
    candidate_id: int,
    data: CandidateUpdate,
    session: AsyncSession = Depends(get_session),
):
    candidate = await crud.get_candidate_by_id(session, candidate_id)
    if not candidate:
        raise HTTPException(status_code=404, detail="Candidate not found")

    update_data = data.model_dump(exclude_none=True)
    if update_data:
        await crud.update_candidate(session, candidate_id, **update_data)
    return OkResponse(message="Candidate updated")


@router.post("/{candidate_id}/assign/{manager_id}", response_model=OkResponse)
async def assign_manager(
    candidate_id: int,
    manager_id: int,
    session: AsyncSession = Depends(get_session),
):
    candidate = await crud.get_candidate_by_id(session, candidate_id)
    if not candidate:
        raise HTTPException(status_code=404, detail="Candidate not found")
    await crud.assign_manager(session, candidate_id, manager_id)
    return OkResponse(message="Manager assigned")


@router.post("/{candidate_id}/block", response_model=OkResponse)
async def block_candidate(
    candidate_id: int,
    reason: str = Query(...),
    session: AsyncSession = Depends(get_session),
):
    candidate = await crud.get_candidate_by_id(session, candidate_id)
    if not candidate:
        raise HTTPException(status_code=404, detail="Candidate not found")
    await crud.block_candidate(session, candidate.telegram_id, reason)
    return OkResponse(message="Candidate blocked")


@router.get("/{candidate_id}/messages")
async def get_messages(
    candidate_id: int,
    session: AsyncSession = Depends(get_session),
):
    messages = await crud.get_candidate_messages(session, candidate_id)
    return [
        {
            "id": m.id,
            "direction": m.direction.value,
            "content": m.content,
            "message_type": m.message_type,
            "created_at": m.created_at.isoformat(),
        }
        for m in messages
    ]
