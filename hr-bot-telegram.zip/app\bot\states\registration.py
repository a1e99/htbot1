"""FSM States for candidate registration flow."""
from aiogram.fsm.state import State, StatesGroup


class SubscriptionStates(StatesGroup):
    # Waiting for channel subscription confirmation
    WAITING = State()


class RegistrationStates(StatesGroup):
    # Warning screen
    WARNING = State()

    # Personal data collection
    FULL_NAME = State()
    PHONE = State()
    EMAIL = State()
    CITY = State()
    RELOCATION = State()
    RELOCATION_DETAILS = State()
    SALARY_AMOUNT = State()
    SALARY_CURRENCY = State()
    SALARY_PERIOD = State()
    SALARY_CONFIRM = State()
    AGE = State()
    PHOTO = State()
    GENDER = State()
    NATIONALITY = State()
    CURRENT_COUNTRY = State()
    CURRENT_CITY = State()

    # Professional data
    PROFESSION_CATEGORY = State()
    PROFESSION = State()
    EXPERIENCE_YEARS = State()
    EXPERIENCE_DETAILS = State()

    # Resume upload (optional step after photo)
    RESUME = State()

    # Resume questionnaire (if candidate skipped file upload)
    RESUME_SPECIALTY = State()
    RESUME_EXPERIENCE_YEARS = State()
    RESUME_EXPERIENCE_DETAILS = State()
    RESUME_SKILLS = State()
    RESUME_EDUCATION = State()
    RESUME_LANGUAGES = State()
    REMINDER_FREQUENCY = State()

    # Completion
    CONFIRMATION = State()


class QuizStates(StatesGroup):
    ANSWERING = State()
    COMPLETED = State()
