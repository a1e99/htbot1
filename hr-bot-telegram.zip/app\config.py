from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field, field_validator
from pathlib import Path
from typing import Any, Optional

BASE_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=BASE_DIR / ".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
    )

    # Telegram
    bot_token: str = Field(..., alias="BOT_TOKEN")
    # Accepts "123,456" or "[123,456]" or "123" — all formats
    manager_chat_ids: list[int] = Field(default_factory=list, alias="MANAGER_CHAT_IDS")

    @field_validator("manager_chat_ids", mode="before")
    @classmethod
    def parse_manager_ids(cls, v: Any) -> list[int]:
        if isinstance(v, list):
            return [int(x) for x in v]
        if isinstance(v, int):
            return [v]
        if isinstance(v, str):
            v = v.strip().strip("[]")
            if not v:
                return []
            return [int(x.strip()) for x in v.split(",") if x.strip()]
        return []

    # OpenAI
    openai_api_key: str = Field(default="", alias="OPENAI_API_KEY")
    openai_model: str = Field(default="gpt-4o", alias="OPENAI_MODEL")

    # Database
    database_url: str = Field(
        default=f"sqlite+aiosqlite:///{BASE_DIR}/data/hr_bot.db",
        alias="DATABASE_URL",
    )

    # Web Panel
    web_host: str = Field(default="127.0.0.1", alias="WEB_HOST")
    web_port: int = Field(default=8000, alias="WEB_PORT")
    secret_key: str = Field(default="change_me_in_production", alias="SECRET_KEY")

    # Anti-spam
    rate_limit_messages: int = Field(default=5, alias="RATE_LIMIT_MESSAGES")
    rate_limit_window: int = Field(default=60, alias="RATE_LIMIT_WINDOW")
    min_message_length: int = Field(default=3, alias="MIN_MESSAGE_LENGTH")

    # Groups
    allow_group_creation: bool = Field(default=True, alias="ALLOW_GROUP_CREATION")

    # Storage
    photos_dir: Path = Field(default=BASE_DIR / "data" / "photos", alias="PHOTOS_DIR")
    logs_dir: Path = Field(default=BASE_DIR / "data" / "logs", alias="LOGS_DIR")

    # ── NocoDB ───────────────────────────────────────────
    nocodb_url: str = Field(default="http://localhost:8080", alias="NOCODB_URL")
    nocodb_email: str = Field(default="admin@hrbot.local", alias="NOCODB_EMAIL")
    nocodb_password: str = Field(default="AdminPassword123!", alias="NOCODB_PASSWORD")
    nocodb_project_id: str = Field(default="", alias="NOCODB_PROJECT_ID")

    # NocoDB table IDs (filled by setup_nocodb.py)
    noco_table_candidates: str = Field(default="", alias="NOCO_TABLE_CANDIDATES")
    noco_table_vacancies:  str = Field(default="", alias="NOCO_TABLE_VACANCIES")
    noco_table_questions:  str = Field(default="", alias="NOCO_TABLE_QUIZQUESTIONS")
    noco_table_answers:    str = Field(default="", alias="NOCO_TABLE_QUIZANSWERS")
    noco_table_knowledge:  str = Field(default="", alias="NOCO_TABLE_KNOWLEDGEDOCS")
    noco_table_partners:   str = Field(default="", alias="NOCO_TABLE_COMPANYPARTNERS")
    noco_table_channels:   str = Field(default="", alias="NOCO_TABLE_PUBLISHCHANNELS")
    noco_table_managers:   str = Field(default="", alias="NOCO_TABLE_MANAGERS")
    noco_table_broadcasts: str = Field(default="", alias="NOCO_TABLE_CANDIDATEBROADCASTS")
    noco_table_moderation_queue: str = Field(default="", alias="NOCO_TABLE_MODERATION_QUEUE")

    # ── ChromaDB (RAG vectors) ───────────────────────────
    chroma_dir: Path = Field(default=BASE_DIR / "data" / "chroma", alias="CHROMA_DIR")

    # ── NocoDB API token (alternative to email/password) ─
    nocodb_api_token: str = Field(default="", alias="NOCODB_API_TOKEN")

    # ── Required channel subscription (multiple, comma-separated) ──
    # e.g. REQUIRED_CHANNEL_IDS=@chan1,@chan2
    # Stored as raw strings; parsed into lists via properties below
    required_channel_ids_raw: str = Field(default="", alias="REQUIRED_CHANNEL_IDS")
    required_channel_titles_raw: str = Field(default="", alias="REQUIRED_CHANNEL_TITLES")

    @property
    def required_channel_ids(self) -> list[str]:
        return [x.strip() for x in (self.required_channel_ids_raw or "").split(",") if x.strip()]

    @property
    def required_channel_titles(self) -> list[str]:
        return [x.strip() for x in (self.required_channel_titles_raw or "").split(",") if x.strip()]

    # ── Vacancy ingestion from Telegram group with topics ─
    # Set to supergroup ID (e.g. -1003900420048)
    vacancy_source_group_id: Optional[int] = Field(default=None, alias="VACANCY_SOURCE_GROUP_ID")
    # Thread/topic ID inside the group (Generated Vacancies = 8)
    vacancy_source_group_thread_id: int = Field(default=8, alias="VACANCY_SOURCE_GROUP_THREAD_ID")

    # ── Matching ─────────────────────────────────────────
    noco_table_matches: str = Field(default="", alias="NOCO_TABLE_MATCHES")
    candidate_reminder_check_minutes: int = Field(default=60, alias="CANDIDATE_REMINDER_CHECK_MINUTES")

    @property
    def photos_dir_str(self) -> str:
        return str(self.photos_dir)

    @property
    def logs_dir_str(self) -> str:
        return str(self.logs_dir)


settings = Settings()
