"""
Async NocoDB REST API client.
All bot data operations go through this module.
Base URL: http://localhost:8080/api/v1
"""
from __future__ import annotations

import asyncio
from typing import Any, Optional
from loguru import logger
import httpx

from app.config import settings


class NocoDB:
    """Async client for NocoDB REST API v1."""

    def __init__(self):
        self._token: Optional[str] = None
        self._base = settings.nocodb_url.rstrip("/")
        self._client: Optional[httpx.AsyncClient] = None

    # ─────────────────────────────────────────────
    # CONNECTION
    # ─────────────────────────────────────────────

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=15.0)
        return self._client

    async def _ensure_token(self) -> str:
        """Authenticate with email/password and cache token."""
        if self._token:
            return self._token
        client = await self._get_client()
        resp = await client.post(
            f"{self._base}/api/v1/auth/user/signin",
            json={
                "email": settings.nocodb_email,
                "password": settings.nocodb_password,
            },
        )
        resp.raise_for_status()
        self._token = resp.json()["token"]
        logger.info("NocoDB: authenticated with email/password")
        return self._token

    async def _headers(self) -> dict:
        # Prefer static API token over email/password auth
        if settings.nocodb_api_token:
            return {"xc-token": settings.nocodb_api_token, "Content-Type": "application/json"}
        token = await self._ensure_token()
        return {"xc-auth": token, "Content-Type": "application/json"}

    async def close(self):
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    # ─────────────────────────────────────────────
    # GENERIC CRUD
    # ─────────────────────────────────────────────

    async def list_records(
        self,
        table_id: str,
        where: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
        sort: Optional[str] = None,
    ) -> list[dict]:
        """GET /api/v1/db/data/noco/{project_id}/{table_id}"""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if where:
            params["where"] = where
        if sort:
            params["sort"] = sort
        client = await self._get_client()
        headers = await self._headers()
        url = f"{self._base}/api/v1/db/data/noco/{settings.nocodb_project_id}/{table_id}"
        resp = await client.get(url, headers=headers, params=params)
        resp.raise_for_status()
        data = resp.json()
        return data.get("list", [])

    async def get_record(self, table_id: str, row_id: int) -> Optional[dict]:
        client = await self._get_client()
        headers = await self._headers()
        url = f"{self._base}/api/v1/db/data/noco/{settings.nocodb_project_id}/{table_id}/{row_id}"
        resp = await client.get(url, headers=headers)
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        return resp.json()

    async def create_record(self, table_id: str, data: dict) -> dict:
        client = await self._get_client()
        headers = await self._headers()
        url = f"{self._base}/api/v1/db/data/noco/{settings.nocodb_project_id}/{table_id}"
        resp = await client.post(url, headers=headers, json=data)
        resp.raise_for_status()
        return resp.json()

    async def update_record(self, table_id: str, row_id: int, data: dict) -> dict:
        client = await self._get_client()
        headers = await self._headers()
        url = f"{self._base}/api/v1/db/data/noco/{settings.nocodb_project_id}/{table_id}/{row_id}"
        resp = await client.patch(url, headers=headers, json=data)
        resp.raise_for_status()
        return resp.json()

    async def delete_record(self, table_id: str, row_id: int) -> bool:
        client = await self._get_client()
        headers = await self._headers()
        url = f"{self._base}/api/v1/db/data/noco/{settings.nocodb_project_id}/{table_id}/{row_id}"
        resp = await client.delete(url, headers=headers)
        return resp.status_code in (200, 204)

    async def find_one(self, table_id: str, where: str) -> Optional[dict]:
        records = await self.list_records(table_id, where=where, limit=1)
        return records[0] if records else None

    async def count(self, table_id: str, where: Optional[str] = None) -> int:
        params: dict[str, Any] = {}
        if where:
            params["where"] = where
        client = await self._get_client()
        headers = await self._headers()
        url = f"{self._base}/api/v1/db/data/noco/{settings.nocodb_project_id}/{table_id}/count"
        resp = await client.get(url, headers=headers, params=params)
        resp.raise_for_status()
        return resp.json().get("count", 0)

    # ─────────────────────────────────────────────
    # CANDIDATES
    # ─────────────────────────────────────────────

    async def get_candidate_by_telegram_id(self, telegram_id: int) -> Optional[dict]:
        return await self.find_one(
            settings.noco_table_candidates,
            f"(telegram_id,eq,{telegram_id})",
        )

    async def create_candidate(self, data: dict) -> dict:
        return await self.create_record(settings.noco_table_candidates, data)

    async def update_candidate(self, row_id: int, data: dict) -> dict:
        return await self.update_record(settings.noco_table_candidates, row_id, data)

    async def list_candidates(
        self,
        status: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict]:
        where = f"(status,eq,{status})" if status else None
        return await self.list_records(
            settings.noco_table_candidates,
            where=where,
            limit=limit,
            offset=offset,
            sort="-created_at",
        )

    # ─────────────────────────────────────────────
    # VACANCIES
    # ─────────────────────────────────────────────

    async def list_vacancies(self, active_only: bool = True) -> list[dict]:
        where = "(is_active,eq,true)" if active_only else None
        return await self.list_records(settings.noco_table_vacancies, where=where)

    async def get_vacancy(self, row_id: int) -> Optional[dict]:
        return await self.get_record(settings.noco_table_vacancies, row_id)

    async def create_vacancy(self, data: dict) -> dict:
        return await self.create_record(settings.noco_table_vacancies, data)

    # ─────────────────────────────────────────────
    # QUIZ QUESTIONS
    # ─────────────────────────────────────────────

    async def list_questions(self, vacancy_id: Optional[int] = None) -> list[dict]:
        where = f"(vacancy_id,eq,{vacancy_id})" if vacancy_id else "(is_active,eq,true)"
        return await self.list_records(
            settings.noco_table_questions,
            where=where,
            sort="order_num",
        )

    async def create_question(self, data: dict) -> dict:
        return await self.create_record(settings.noco_table_questions, data)

    # ─────────────────────────────────────────────
    # QUIZ ANSWERS
    # ─────────────────────────────────────────────

    async def save_answer(self, data: dict) -> dict:
        return await self.create_record(settings.noco_table_answers, data)

    async def list_answers(self, candidate_id: int) -> list[dict]:
        return await self.list_records(
            settings.noco_table_answers,
            where=f"(candidate_id,eq,{candidate_id})",
            sort="created_at",
        )

    # ─────────────────────────────────────────────
    # KNOWLEDGE BASE
    # ─────────────────────────────────────────────

    async def list_knowledge_docs(self, vacancy_id: Optional[int] = None) -> list[dict]:
        where = f"(vacancy_id,eq,{vacancy_id})" if vacancy_id else None
        return await self.list_records(settings.noco_table_knowledge, where=where, sort="-created_at")

    async def create_knowledge_doc(self, data: dict) -> dict:
        return await self.create_record(settings.noco_table_knowledge, data)

    async def update_knowledge_doc(self, row_id: int, data: dict) -> dict:
        return await self.update_record(settings.noco_table_knowledge, row_id, data)

    async def delete_knowledge_doc(self, row_id: int) -> bool:
        return await self.delete_record(settings.noco_table_knowledge, row_id)

    # ─────────────────────────────────────────────
    # COMPANY PARTNERS
    # ─────────────────────────────────────────────

    async def list_partners(self, active_only: bool = True) -> list[dict]:
        where = "(is_active,eq,true)" if active_only else None
        return await self.list_records(settings.noco_table_partners, where=where)

    async def create_partner(self, data: dict) -> dict:
        return await self.create_record(settings.noco_table_partners, data)

    async def update_partner(self, row_id: int, data: dict) -> dict:
        return await self.update_record(settings.noco_table_partners, row_id, data)

    # ─────────────────────────────────────────────
    # PUBLISH CHANNELS
    # ─────────────────────────────────────────────

    async def list_channels(self) -> list[dict]:
        return await self.list_records(
            settings.noco_table_channels,
            where="(is_active,eq,true)",
        )

    async def create_channel(self, data: dict) -> dict:
        return await self.create_record(settings.noco_table_channels, data)

    # ─────────────────────────────────────────────
    # MANAGERS
    # ─────────────────────────────────────────────

    async def list_managers(self) -> list[dict]:
        return await self.list_records(settings.noco_table_managers, where="(is_active,eq,true)")

    async def get_manager_by_telegram_id(self, telegram_id: int) -> Optional[dict]:
        return await self.find_one(
            settings.noco_table_managers,
            f"(telegram_id,eq,{telegram_id})",
        )

    # ─────────────────────────────────────────────
    # HEALTH CHECK
    # ─────────────────────────────────────────────

    async def ping(self) -> bool:
        try:
            client = await self._get_client()
            resp = await client.get(f"{self._base}/api/v1/health", timeout=5)
            return resp.status_code == 200
        except Exception:
            return False


# Singleton
noco = NocoDB()
