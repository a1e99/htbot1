"""
CRUD operations for all database models.
All functions are async and accept an AsyncSession.
"""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import Optional, Sequence

from sqlalchemy import select, update, func, and_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database.models import (
    Agency,
    Candidate,
    CandidateMessage,
    CandidateStatus,
    Company,
    ForbiddenWord,
    Manager,
    ManagerDecision,
    ManagerDecisionType,
    MessageDirection,
    Profession,
    ProfessionCategory,
    QuizQuestion,
    QuizResult,
    SpamEventType,
    SpamLog,
    Vacancy,
)


# ─────────────────────────────────────────────
# SEQUENCE NUMBER GENERATOR
# ─────────────────────────────────────────────

async def get_next_sequential_number(session: AsyncSession) -> int:
    result = await session.execute(select(func.max(Candidate.sequential_number)))
    max_num = result.scalar()
    return (max_num or 0) + 1


# ─────────────────────────────────────────────
# AGENCY
# ─────────────────────────────────────────────

async def get_agency_by_id(session: AsyncSession, agency_id: int) -> Optional[Agency]:
    result = await session.execute(
        select(Agency).where(Agency.id == agency_id, Agency.is_active == True)
    )
    return result.scalar_one_or_none()


async def get_agency_by_slug(session: AsyncSession, slug: str) -> Optional[Agency]:
    result = await session.execute(
        select(Agency).where(Agency.slug == slug, Agency.is_active == True)
    )
    return result.scalar_one_or_none()


async def get_all_agencies(session: AsyncSession) -> Sequence[Agency]:
    result = await session.execute(
        select(Agency).where(Agency.is_active == True).order_by(Agency.name)
    )
    return result.scalars().all()


# ─────────────────────────────────────────────
# MANAGER
# ─────────────────────────────────────────────

async def get_manager_by_telegram_id(
    session: AsyncSession, telegram_id: int
) -> Optional[Manager]:
    result = await session.execute(
        select(Manager).where(
            Manager.telegram_id == telegram_id, Manager.is_active == True
        )
    )
    return result.scalar_one_or_none()


async def get_managers_by_agency(
    session: AsyncSession, agency_id: int
) -> Sequence[Manager]:
    result = await session.execute(
        select(Manager).where(
            Manager.agency_id == agency_id, Manager.is_active == True
        ).order_by(Manager.full_name)
    )
    return result.scalars().all()


async def get_all_active_managers(session: AsyncSession) -> Sequence[Manager]:
    result = await session.execute(
        select(Manager).where(Manager.is_active == True).order_by(Manager.full_name)
    )
    return result.scalars().all()


# ─────────────────────────────────────────────
# CANDIDATE
# ─────────────────────────────────────────────

async def get_candidate_by_telegram_id(
    session: AsyncSession, telegram_id: int
) -> Optional[Candidate]:
    result = await session.execute(
        select(Candidate)
        .where(Candidate.telegram_id == telegram_id)
        .options(
            selectinload(Candidate.vacancy),
            selectinload(Candidate.assigned_manager),
            selectinload(Candidate.profession),
        )
    )
    return result.scalar_one_or_none()


async def get_candidate_by_id(
    session: AsyncSession, candidate_id: int
) -> Optional[Candidate]:
    result = await session.execute(
        select(Candidate)
        .where(Candidate.id == candidate_id)
        .options(
            selectinload(Candidate.vacancy),
            selectinload(Candidate.assigned_manager),
            selectinload(Candidate.profession),
            selectinload(Candidate.quiz_results).selectinload(QuizResult.question),
            selectinload(Candidate.messages),
            selectinload(Candidate.decisions).selectinload(ManagerDecision.manager),
        )
    )
    return result.scalar_one_or_none()


async def create_candidate(
    session: AsyncSession,
    telegram_id: int,
    telegram_username: Optional[str] = None,
    agency_id: Optional[int] = None,
    vacancy_id: Optional[int] = None,
) -> Candidate:
    seq_num = await get_next_sequential_number(session)
    candidate = Candidate(
        telegram_id=telegram_id,
        telegram_username=telegram_username,
        sequential_number=seq_num,
        agency_id=agency_id,
        vacancy_id=vacancy_id,
        status=CandidateStatus.NEW,
        registration_started_at=datetime.utcnow(),
    )
    session.add(candidate)
    await session.flush()
    return candidate


async def update_candidate(
    session: AsyncSession, candidate_id: int, **kwargs
) -> Optional[Candidate]:
    kwargs["updated_at"] = datetime.utcnow()
    await session.execute(
        update(Candidate).where(Candidate.id == candidate_id).values(**kwargs)
    )
    await session.flush()
    return await get_candidate_by_id(session, candidate_id)


async def update_candidate_status(
    session: AsyncSession, candidate_id: int, status: CandidateStatus
) -> None:
    await session.execute(
        update(Candidate)
        .where(Candidate.id == candidate_id)
        .values(status=status, updated_at=datetime.utcnow())
    )
    await session.flush()


async def assign_manager(
    session: AsyncSession, candidate_id: int, manager_id: int
) -> None:
    await session.execute(
        update(Candidate)
        .where(Candidate.id == candidate_id)
        .values(
            assigned_manager_id=manager_id,
            status=CandidateStatus.IN_REVIEW,
            updated_at=datetime.utcnow(),
        )
    )
    await session.flush()


async def get_all_candidates(
    session: AsyncSession,
    agency_id: Optional[int] = None,
    status: Optional[CandidateStatus] = None,
    limit: int = 50,
    offset: int = 0,
) -> Sequence[Candidate]:
    query = select(Candidate).options(
        selectinload(Candidate.assigned_manager),
        selectinload(Candidate.vacancy),
        selectinload(Candidate.profession),
    )
    if agency_id:
        query = query.where(Candidate.agency_id == agency_id)
    if status:
        query = query.where(Candidate.status == status)
    query = query.order_by(Candidate.created_at.desc()).limit(limit).offset(offset)
    result = await session.execute(query)
    return result.scalars().all()


async def count_candidates(
    session: AsyncSession,
    agency_id: Optional[int] = None,
    status: Optional[CandidateStatus] = None,
) -> int:
    query = select(func.count()).select_from(Candidate)
    if agency_id:
        query = query.where(Candidate.agency_id == agency_id)
    if status:
        query = query.where(Candidate.status == status)
    result = await session.execute(query)
    return result.scalar() or 0


async def block_candidate(
    session: AsyncSession, telegram_id: int, reason: str
) -> None:
    await session.execute(
        update(Candidate)
        .where(Candidate.telegram_id == telegram_id)
        .values(
            is_blocked=True,
            block_reason=reason,
            status=CandidateStatus.BLOCKED,
            updated_at=datetime.utcnow(),
        )
    )
    await session.flush()


# ─────────────────────────────────────────────
# MESSAGES
# ─────────────────────────────────────────────

async def save_message(
    session: AsyncSession,
    candidate_id: int,
    direction: MessageDirection,
    content: str,
    message_type: str = "text",
    telegram_msg_id: Optional[int] = None,
) -> CandidateMessage:
    msg = CandidateMessage(
        candidate_id=candidate_id,
        direction=direction,
        content=content,
        message_type=message_type,
        telegram_msg_id=telegram_msg_id,
    )
    session.add(msg)
    await session.flush()
    return msg


async def get_candidate_messages(
    session: AsyncSession, candidate_id: int, limit: int = 100
) -> Sequence[CandidateMessage]:
    result = await session.execute(
        select(CandidateMessage)
        .where(CandidateMessage.candidate_id == candidate_id)
        .order_by(CandidateMessage.created_at)
        .limit(limit)
    )
    return result.scalars().all()


# ─────────────────────────────────────────────
# QUIZ
# ─────────────────────────────────────────────

async def get_quiz_questions(
    session: AsyncSession, profession_id: int
) -> Sequence[QuizQuestion]:
    result = await session.execute(
        select(QuizQuestion)
        .where(QuizQuestion.profession_id == profession_id)
        .order_by(QuizQuestion.sort_order)
    )
    return result.scalars().all()


async def save_quiz_result(
    session: AsyncSession,
    candidate_id: int,
    question_id: int,
    answer: str,
    ai_score: Optional[float] = None,
    ai_comment: Optional[str] = None,
    is_passed: bool = True,
) -> QuizResult:
    result = QuizResult(
        candidate_id=candidate_id,
        question_id=question_id,
        answer=answer,
        ai_score=ai_score,
        ai_comment=ai_comment,
        is_passed=is_passed,
    )
    session.add(result)
    await session.flush()
    return result


async def get_candidate_quiz_results(
    session: AsyncSession, candidate_id: int
) -> Sequence[QuizResult]:
    result = await session.execute(
        select(QuizResult)
        .where(QuizResult.candidate_id == candidate_id)
        .options(selectinload(QuizResult.question))
        .order_by(QuizResult.answered_at)
    )
    return result.scalars().all()


async def calculate_quiz_score(
    session: AsyncSession, candidate_id: int
) -> Optional[float]:
    result = await session.execute(
        select(func.avg(QuizResult.ai_score)).where(
            QuizResult.candidate_id == candidate_id,
            QuizResult.ai_score.isnot(None),
        )
    )
    return result.scalar()


# ─────────────────────────────────────────────
# MANAGER DECISIONS
# ─────────────────────────────────────────────

async def create_manager_decision(
    session: AsyncSession,
    candidate_id: int,
    manager_id: int,
    decision: ManagerDecisionType,
    comment: Optional[str] = None,
) -> ManagerDecision:
    decision_obj = ManagerDecision(
        candidate_id=candidate_id,
        manager_id=manager_id,
        decision=decision,
        comment=comment,
    )
    session.add(decision_obj)
    await session.flush()
    return decision_obj


# ─────────────────────────────────────────────
# FORBIDDEN WORDS
# ─────────────────────────────────────────────

async def get_all_forbidden_words(session: AsyncSession) -> list[str]:
    result = await session.execute(
        select(ForbiddenWord.word).where(ForbiddenWord.is_active == True)
    )
    return list(result.scalars().all())


async def add_forbidden_word(
    session: AsyncSession,
    word: str,
    category: str = "spam",
    manager_id: Optional[int] = None,
) -> ForbiddenWord:
    fw = ForbiddenWord(word=word.lower().strip(), category=category, added_by=manager_id)
    session.add(fw)
    await session.flush()
    return fw


async def delete_forbidden_word(session: AsyncSession, word_id: int) -> None:
    result = await session.execute(
        select(ForbiddenWord).where(ForbiddenWord.id == word_id)
    )
    fw = result.scalar_one_or_none()
    if fw:
        await session.delete(fw)
        await session.flush()


# ─────────────────────────────────────────────
# SPAM LOG
# ─────────────────────────────────────────────

async def log_spam_event(
    session: AsyncSession,
    telegram_id: int,
    event_type: SpamEventType,
    details: Optional[str] = None,
) -> None:
    log = SpamLog(telegram_id=telegram_id, event_type=event_type, details=details)
    session.add(log)
    await session.flush()


async def count_spam_events(
    session: AsyncSession,
    telegram_id: int,
    event_type: SpamEventType,
    within_seconds: int = 60,
) -> int:
    since = datetime.utcnow() - timedelta(seconds=within_seconds)
    result = await session.execute(
        select(func.count()).select_from(SpamLog).where(
            and_(
                SpamLog.telegram_id == telegram_id,
                SpamLog.event_type == event_type,
                SpamLog.created_at >= since,
            )
        )
    )
    return result.scalar() or 0


# ─────────────────────────────────────────────
# PROFESSIONS
# ─────────────────────────────────────────────

async def get_all_profession_categories(
    session: AsyncSession,
) -> Sequence[ProfessionCategory]:
    result = await session.execute(
        select(ProfessionCategory).order_by(ProfessionCategory.sort_order)
    )
    return result.scalars().all()


async def get_professions_by_category(
    session: AsyncSession, category_id: int
) -> Sequence[Profession]:
    result = await session.execute(
        select(Profession).where(
            Profession.category_id == category_id, Profession.is_active == True
        ).order_by(Profession.name_ru)
    )
    return result.scalars().all()


async def get_profession_by_id(
    session: AsyncSession, profession_id: int
) -> Optional[Profession]:
    result = await session.execute(
        select(Profession).where(Profession.id == profession_id)
    )
    return result.scalar_one_or_none()


# ─────────────────────────────────────────────
# VACANCIES
# ─────────────────────────────────────────────

async def get_active_vacancy(
    session: AsyncSession, agency_id: Optional[int] = None
) -> Optional[Vacancy]:
    query = select(Vacancy).where(Vacancy.is_active == True)
    if agency_id:
        query = query.where(Vacancy.agency_id == agency_id)
    result = await session.execute(query.limit(1))
    return result.scalar_one_or_none()


async def get_all_vacancies(
    session: AsyncSession, agency_id: Optional[int] = None
) -> Sequence[Vacancy]:
    query = select(Vacancy).options(
        selectinload(Vacancy.company), selectinload(Vacancy.profession)
    )
    if agency_id:
        query = query.where(Vacancy.agency_id == agency_id)
    query = query.order_by(Vacancy.created_at.desc())
    result = await session.execute(query)
    return result.scalars().all()
