"""Healthcheck — validates config and NocoDB connection."""
import asyncio, sys
from loguru import logger

async def main():
    errors = []

    # Config
    try:
        from app.config import settings
        if not settings.bot_token or settings.bot_token.startswith("1234"):
            errors.append("BOT_TOKEN не установлен")
        if not settings.manager_chat_ids:
            errors.append("MANAGER_CHAT_IDS не установлены")
        if not settings.nocodb_project_id:
            errors.append("NOCODB_PROJECT_ID не установлен (запустите setup_nocodb.py)")
        if not settings.noco_table_candidates:
            errors.append("NOCO_TABLE_CANDIDATES не установлена (запустите setup_nocodb.py)")
    except Exception as e:
        errors.append(f"Config error: {e}")

    # NocoDB
    try:
        from app.nocodb.client import noco
        ok = await noco.ping()
        if ok:
            print("[OK] NocoDB доступен")
        else:
            errors.append("NocoDB недоступен — запустите: docker compose up -d")
    except Exception as e:
        errors.append(f"NocoDB error: {e}")

    # OpenAI
    try:
        from app.config import settings
        if settings.openai_api_key:
            print("[OK] OpenAI API key установлен")
        else:
            print("[WARN] OpenAI API key не установлен — AI-функции отключены")
    except Exception:
        pass

    if errors:
        print("\n[FAIL] Проверки не прошли:")
        for e in errors:
            print(f"  - {e}")
        sys.exit(1)
    else:
        print("\n[OK] Все проверки пройдены")
        sys.exit(0)

if __name__ == "__main__":
    asyncio.run(main())
