"""
Document loader for Knowledge Base.
Supports: PDF, DOCX, plain text, URL scraping.
Returns list of text chunks ready for embedding.
"""
from __future__ import annotations

import io
import re
import textwrap
from pathlib import Path
from typing import Optional
from loguru import logger


CHUNK_SIZE    = 800   # chars per chunk
CHUNK_OVERLAP = 150   # overlap between chunks


# ─────────────────────────────────────────────
# CHUNKER
# ─────────────────────────────────────────────

def _chunk_text(text: str, size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    """Split text into overlapping chunks."""
    text = re.sub(r"\n{3,}", "\n\n", text.strip())
    chunks, start = [], 0
    while start < len(text):
        end = min(start + size, len(text))
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        start += size - overlap
    return chunks


# ─────────────────────────────────────────────
# PDF
# ─────────────────────────────────────────────

def load_pdf(path: str | Path) -> list[str]:
    try:
        import pdfplumber
        text_parts = []
        with pdfplumber.open(str(path)) as pdf:
            for page in pdf.pages:
                t = page.extract_text()
                if t:
                    text_parts.append(t)
        full = "\n\n".join(text_parts)
        logger.info(f"PDF loaded: {path} — {len(full)} chars")
        return _chunk_text(full)
    except ImportError:
        # Fallback: pypdf
        try:
            import pypdf
            reader = pypdf.PdfReader(str(path))
            parts = [p.extract_text() or "" for p in reader.pages]
            full = "\n\n".join(parts)
            return _chunk_text(full)
        except Exception as e:
            logger.error(f"PDF load failed: {e}")
            return []
    except Exception as e:
        logger.error(f"PDF load error {path}: {e}")
        return []


# ─────────────────────────────────────────────
# DOCX
# ─────────────────────────────────────────────

def load_docx(path: str | Path) -> list[str]:
    try:
        import docx
        doc = docx.Document(str(path))
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        # Also grab tables
        for table in doc.tables:
            for row in table.rows:
                row_text = " | ".join(c.text.strip() for c in row.cells if c.text.strip())
                if row_text:
                    paragraphs.append(row_text)
        full = "\n\n".join(paragraphs)
        logger.info(f"DOCX loaded: {path} — {len(full)} chars")
        return _chunk_text(full)
    except ImportError:
        logger.error("python-docx not installed. Run: pip install python-docx")
        return []
    except Exception as e:
        logger.error(f"DOCX load error {path}: {e}")
        return []


# ─────────────────────────────────────────────
# PLAIN TEXT
# ─────────────────────────────────────────────

def load_text(text: str) -> list[str]:
    return _chunk_text(text)


# ─────────────────────────────────────────────
# URL SCRAPER
# ─────────────────────────────────────────────

def load_url(url: str, timeout: int = 15) -> list[str]:
    try:
        import httpx
        from html.parser import HTMLParser

        class TextExtractor(HTMLParser):
            def __init__(self):
                super().__init__()
                self._skip = False
                self.parts: list[str] = []

            def handle_starttag(self, tag, attrs):
                if tag in ("script", "style", "nav", "footer", "head"):
                    self._skip = True

            def handle_endtag(self, tag):
                if tag in ("script", "style", "nav", "footer", "head"):
                    self._skip = False

            def handle_data(self, data):
                if not self._skip:
                    t = data.strip()
                    if t:
                        self.parts.append(t)

        resp = httpx.get(url, timeout=timeout, follow_redirects=True,
                         headers={"User-Agent": "Mozilla/5.0"})
        resp.raise_for_status()
        extractor = TextExtractor()
        extractor.feed(resp.text)
        full = "\n".join(extractor.parts)
        full = re.sub(r"\n{3,}", "\n\n", full)
        logger.info(f"URL scraped: {url} — {len(full)} chars")
        return _chunk_text(full)
    except Exception as e:
        logger.error(f"URL scrape error {url}: {e}")
        return []


# ─────────────────────────────────────────────
# UNIFIED ENTRY POINT
# ─────────────────────────────────────────────

def load_document(
    *,
    path:     Optional[str | Path] = None,
    url:      Optional[str]        = None,
    text:     Optional[str]        = None,
    doc_type: str                  = "auto",
) -> list[str]:
    """
    Load and chunk a document.
    Returns list of text chunks.
    """
    if text:
        return load_text(text)

    if url:
        return load_url(url)

    if path:
        path = Path(path)
        suffix = path.suffix.lower()
        if doc_type == "pdf" or suffix == ".pdf":
            return load_pdf(path)
        elif doc_type == "docx" or suffix in (".docx", ".doc"):
            return load_docx(path)
        else:
            # Try as plain text
            try:
                return load_text(path.read_text(encoding="utf-8", errors="replace"))
            except Exception as e:
                logger.error(f"Text load error: {e}")
                return []

    logger.warning("load_document called with no input")
    return []
