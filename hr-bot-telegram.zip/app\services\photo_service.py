"""Photo save utility."""
from __future__ import annotations
import io
from pathlib import Path
from typing import Optional
from aiogram.types import Message
from app.config import settings
from loguru import logger


async def save_photo_from_message(message: Message) -> Optional[str]:
    try:
        photo = message.photo[-1]
        bot = message.bot
        file = await bot.get_file(photo.file_id)
        data = await bot.download_file(file.file_path)
        settings.photos_dir.mkdir(parents=True, exist_ok=True)
        path = settings.photos_dir / f"{message.from_user.id}.webp"
        from PIL import Image
        img = Image.open(io.BytesIO(data.read()))
        img = img.convert("RGB")
        img.thumbnail((800, 800))
        img.save(str(path), "WEBP", quality=85)
        return str(path)
    except Exception as e:
        logger.error(f"Photo save failed: {e}")
        return None
