"""
Vacancy ingestion from Telegram group with topics (forum supergroup).

Listens to the "Generated Vacancies" topic (thread) in the source group.
When a new message appears in that topic — parses it as a vacancy via AI.

Anti-duplicate: based on text hash.

Setup:
  1. Add bot to the source group (any role — read messages is enough)
  2. Set VACANCY_SOURCE_GROUP_ID=-1003900420048 in .env
  3. Set VACANCY_SOURCE_GROUP_THREAD_ID=8 (Generated Vacancies thread)

Managers can also forward messages to the bot manually for one-off ingestion.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone

from aiogram import Router, F
from aiogram.types import Message
from loguru import logger

from app.nocodb.client import noco
from app.config import settings

router = Router(name="vacancy_ingestion")

# Minimum text length to consider as a vacancy post
MIN_VACANCY_TEXT_LEN = 50


# ─────────────────────────────────────────────
# DEDUPLICATION
# ─────────────────────────────────────────────

def _text_hash(text: str) -> str:
    """Stable hash for deduplication."""
    normalized = " ".join(text.lower().split())
    return hashlib.sha256(normalized.encode()).hexdigest()[:16]


async def _is_duplicate(source_hash: str) -> bool:
    """Check if this post was already ingested."""
    try:
        existing = await noco.find_one(
            settings.noco_table_vacancies,
            f"(source_hash,eq,{source_hash})",
        )
        return existing is not None
    except Exception:
        return False


# ─────────────────────────────────────────────
# AI PARSING
# ─────────────────────────────────────────────

async def _parse_vacancy_text(text: str) -> dict | None:
    """
    Use OpenAI to extract structured vacancy fields from raw post text.
    Returns None if text is not a job vacancy.
    """
    prompt = (
        "Проанализируй текст из Telegram-канала. "
        "Если это объявление о вакансии — извлеки данные. "
        "Если это НЕ вакансия (новость, реклама, другое) — верни {\"is_vacancy\": false}.\n\n"
        f"=== ТЕКСТ ===\n{text[:2000]}\n\n"
        "Верни JSON без markdown:\n"
        "{\n"
        '  "is_vacancy": true,\n'
        '  "title": "Название должности",\n'
        '  "description": "Описание вакансии",\n'
        '  "requirements": "Требования к кандидату",\n'
        '  "salary_from": null,\n'
        '  "salary_to": null,\n'
        '  "currency": "RUB",\n'
        '  "city": null,\n'
        '  "employment_type": "full_time"\n'
        "}"
    )

    try:
        from app.services.openai_service import get_client
        response = await get_client().chat.completions.create(
            model=settings.openai_model,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=500,
            temperature=0.1,
        )
        raw = response.choices[0].message.content.strip()
        raw = raw.replace("```json", "").replace("```", "").strip()
        data = json.loads(raw)
        if not data.get("is_vacancy"):
            return None
        return data
    except Exception as e:
        logger.error(f"[Ingestion] AI parse failed: {e}")
        return None


# ─────────────────────────────────────────────
# CHANNEL POST HANDLER
# ─────────────────────────────────────────────

@router.message(F.text)
async def handle_group_topic_post(message: Message) -> None:
    """Auto-ingest vacancy from the 'Generated Vacancies' topic in the source group."""
    group_id = settings.vacancy_source_group_id
    thread_id = settings.vacancy_source_group_thread_id

    # Only process if source group is configured
    if not group_id:
        return

    # Must be from the configured group
    if message.chat.id != group_id:
        return

    # Must be from the correct topic thread
    if message.message_thread_id != thread_id:
        return

    text = message.text or ""
    if len(text) < MIN_VACANCY_TEXT_LEN:
        return

    logger.info(f"[Ingestion] New post in Generated Vacancies topic, len={len(text)}")

    # Dedup check
    h = _text_hash(text)
    if await _is_duplicate(h):
        logger.debug(f"[Ingestion] Duplicate post hash={h}, skipping")
        return

    # AI parsing
    parsed = await _parse_vacancy_text(text)
    if not parsed:
        logger.debug("[Ingestion] Post is not a vacancy, skipping")
        return

    # Save to NocoDB
    now_iso = datetime.now(timezone.utc).isoformat()
    vacancy_data = {
        "title": parsed.get("title", "Вакансия из группы"),
        "description": parsed.get("description", text[:1000]),
        "requirements": parsed.get("requirements", ""),
        "salary_from": parsed.get("salary_from"),
        "salary_to": parsed.get("salary_to"),
        "currency": parsed.get("currency", "EUR"),
        "city": parsed.get("city", ""),
        "employment_type": parsed.get("employment_type", ""),
        "is_active": True,
        "source_channel_id": str(group_id),
        "source_message_id": message.message_id,
        "source_hash": h,
        "created_at": now_iso,
    }

    try:
        vac = await noco.create_vacancy(vacancy_data)
        logger.info(f"[Ingestion] Created vacancy '{parsed.get('title')}' id={vac.get('Id')}")

        # Notify matching candidates about the new vacancy
        try:
            from app.bot.main import bot as global_bot
            from app.services.notification_service import notify_candidates_about_new_vacancy
            if global_bot:
                notified = await notify_candidates_about_new_vacancy(global_bot, vac)
                logger.info(f"[Ingestion] Notified {notified} candidates about new vacancy")
        except Exception as e:
            logger.warning(f"[Ingestion] Candidate notification failed: {e}")

    except Exception as e:
        logger.error(f"[Ingestion] Failed to save vacancy: {e}")


# ─────────────────────────────────────────────
# MANUAL FORWARD: manager forwards post to bot
# ─────────────────────────────────────────────

@router.message(F.forward_from_chat)
async def handle_forwarded_from_channel(message: Message) -> None:
    """
    Manager forwards a post from a channel to the bot.
    Bot parses it as a vacancy candidate for approval.
    """
    if message.from_user.id not in settings.manager_chat_ids:
        return

    text = message.text or message.caption or ""
    if len(text) < MIN_VACANCY_TEXT_LEN:
        await message.answer("⚠️ Сообщение слишком короткое для вакансии.")
        return

    h = _text_hash(text)
    if await _is_duplicate(h):
        await message.answer("⚠️ Эта вакансия уже есть в базе (дубликат).")
        return

    processing = await message.answer("⏳ Анализирую вакансию...")
    parsed = await _parse_vacancy_text(text)

    if not parsed:
        await processing.edit_text("❌ Не похоже на вакансию. Если это вакансия — добавьте вручную через /add_vacancy")
        return

    title = parsed.get("title", "Вакансия")
    now_iso = datetime.now(timezone.utc).isoformat()
    vacancy_data = {
        "title": title,
        "description": parsed.get("description", text[:1000]),
        "requirements": parsed.get("requirements", ""),
        "salary_from": parsed.get("salary_from"),
        "salary_to": parsed.get("salary_to"),
        "currency": parsed.get("currency", "RUB"),
        "city": parsed.get("city", ""),
        "employment_type": parsed.get("employment_type", ""),
        "is_active": True,
        "source_channel_id": str(message.forward_from_chat.id) if message.forward_from_chat else "",
        "source_hash": h,
        "created_at": now_iso,
    }

    try:
        vac = await noco.create_vacancy(vacancy_data)
        vid = vac.get("Id", 0)
        from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
        try:
            bot_info = await message.bot.get_me()
            deep_link = f"https://t.me/{bot_info.username}?start=vacancy_{vid}"
            link_text = f"\n\n🔗 Ссылка для кандидатов: {deep_link}"
        except Exception:
            link_text = ""

        await processing.edit_text(
            f"✅ Вакансия <b>«{title}»</b> добавлена в базу (#{vid}).{link_text}",
            parse_mode="HTML",
        )
        logger.info(f"[Ingestion] Manual forward: vacancy '{title}' id={vid}")
    except Exception as e:
        logger.error(f"[Ingestion] Manual forward save failed: {e}")
        await processing.edit_text(f"❌ Ошибка сохранения: {e}")
