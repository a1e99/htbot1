import sys
from pathlib import Path
from loguru import logger
from app.config import settings


def setup_logger() -> None:
    settings.logs_dir.mkdir(parents=True, exist_ok=True)

    logger.remove()

    # Console
    logger.add(
        sys.stderr,
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{line}</cyan> — <level>{message}</level>",
        level="INFO",
        colorize=True,
    )

    # Bot log file
    logger.add(
        settings.logs_dir / "bot.log",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{line} — {message}",
        level="DEBUG",
        rotation="10 MB",
        retention="30 days",
        compression="zip",
        filter=lambda record: "bot" in record["name"],
    )

    # API log file
    logger.add(
        settings.logs_dir / "api.log",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{line} — {message}",
        level="DEBUG",
        rotation="10 MB",
        retention="30 days",
        compression="zip",
        filter=lambda record: "api" in record["name"],
    )

    # System log (all)
    logger.add(
        settings.logs_dir / "system.log",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{line} — {message}",
        level="WARNING",
        rotation="50 MB",
        retention="60 days",
        compression="zip",
    )

    logger.info("Logger initialized")
