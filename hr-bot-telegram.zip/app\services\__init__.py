"""
Services package.

Keep this module lightweight: importing a specific service module must not
eagerly import the whole business layer.
"""

from importlib import import_module

_EXPORTS = {
    "CandidateService": ("app.services.candidate_service", "CandidateService"),
    "QuizService": ("app.services.quiz_service", "QuizService"),
    "QuizSession": ("app.services.quiz_service", "QuizSession"),
    "AntiSpamService": ("app.services.anti_spam_service", "AntiSpamService"),
    "anti_spam": ("app.services.anti_spam_service", "anti_spam"),
    "evaluate_quiz_answer": ("app.services.openai_service", "evaluate_quiz_answer"),
    "generate_candidate_summary": ("app.services.openai_service", "generate_candidate_summary"),
    "notify_managers_new_candidate": ("app.services.notification_service", "notify_managers_new_candidate"),
    "publish_vacancy_to_channel": ("app.services.notification_service", "publish_vacancy_to_channel"),
    "broadcast_candidate_to_partner": ("app.services.notification_service", "broadcast_candidate_to_partner"),
}

__all__ = list(_EXPORTS)


def __getattr__(name: str):
    if name not in _EXPORTS:
        raise AttributeError(name)
    module_name, attr_name = _EXPORTS[name]
    module = import_module(module_name)
    return getattr(module, attr_name)
