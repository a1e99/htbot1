"""
Pydantic v2 schemas for FastAPI request/response validation.
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional, Any
from pydantic import BaseModel, EmailStr, field_validator


# ─────────────────────────────────────────────
# COMMON
# ─────────────────────────────────────────────

class OkResponse(BaseModel):
    ok: bool = True
    message: str = "success"


class PaginationParams(BaseModel):
    limit: int = 50
    offset: int = 0


# ─────────────────────────────────────────────
# AGENCY
# ─────────────────────────────────────────────

class AgencyOut(BaseModel):
    id: int
    name: str
    slug: str
    is_active: bool
    created_at: datetime

    model_config = {"from_attributes": True}


# ─────────────────────────────────────────────
# MANAGER
# ─────────────────────────────────────────────

class ManagerCreate(BaseModel):
    telegram_id: int
    telegram_username: Optional[str] = None
    full_name: str
    email: Optional[str] = None
    phone: Optional[str] = None
    agency_id: Optional[int] = None
    is_admin: bool = False


class ManagerOut(BaseModel):
    id: int
    telegram_id: int
    telegram_username: Optional[str]
    full_name: str
    email: Optional[str]
    phone: Optional[str]
    is_active: bool
    is_admin: bool
    created_at: datetime

    model_config = {"from_attributes": True}


class ManagerUpdate(BaseModel):
    full_name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    is_active: Optional[bool] = None
    is_admin: Optional[bool] = None


# ─────────────────────────────────────────────
# PROFESSION
# ─────────────────────────────────────────────

class ProfessionCategoryOut(BaseModel):
    id: int
    name: str
    name_ru: Optional[str]
    icon: Optional[str]
    sort_order: int

    model_config = {"from_attributes": True}


class ProfessionOut(BaseModel):
    id: int
    name: str
    name_ru: Optional[str]
    description: Optional[str]
    skills: Optional[list]
    requirements: Optional[list]
    risks: Optional[list]
    is_active: bool
    category: Optional[ProfessionCategoryOut]

    model_config = {"from_attributes": True}


# ─────────────────────────────────────────────
# VACANCY
# ─────────────────────────────────────────────

class VacancyCreate(BaseModel):
    title: str
    description: str
    requirements: Optional[str] = None
    profession_id: Optional[int] = None
    company_id: Optional[int] = None
    agency_id: Optional[int] = None
    salary_from: Optional[float] = None
    salary_to: Optional[float] = None
    currency: str = "USD"
    country: Optional[str] = None
    city: Optional[str] = None
    employment_type: Optional[str] = None


class VacancyOut(BaseModel):
    id: int
    title: str
    description: str
    requirements: Optional[str]
    salary_from: Optional[float]
    salary_to: Optional[float]
    currency: str
    country: Optional[str]
    city: Optional[str]
    employment_type: Optional[str]
    is_active: bool
    created_at: datetime

    model_config = {"from_attributes": True}


# ─────────────────────────────────────────────
# QUIZ
# ─────────────────────────────────────────────

class QuizResultOut(BaseModel):
    id: int
    question_id: int
    question_text: Optional[str] = None
    answer: str
    ai_score: Optional[float]
    ai_comment: Optional[str]
    is_passed: bool
    answered_at: datetime

    model_config = {"from_attributes": True}


# ─────────────────────────────────────────────
# CANDIDATE
# ─────────────────────────────────────────────

class CandidateListItem(BaseModel):
    id: int
    sequential_number: int
    telegram_id: int
    telegram_username: Optional[str]
    full_name: Optional[str]
    age: Optional[int]
    nationality: Optional[str]
    current_country: Optional[str]
    profession_id: Optional[int]
    experience_years: Optional[int]
    quiz_score: Optional[float]
    status: str
    photo_path: Optional[str]
    created_at: datetime
    assigned_manager: Optional[ManagerOut]

    model_config = {"from_attributes": True}


class CandidateDetail(BaseModel):
    id: int
    sequential_number: int
    telegram_id: int
    telegram_username: Optional[str]

    full_name: Optional[str]
    phone: Optional[str]
    email: Optional[str]
    age: Optional[int]
    gender: Optional[str]
    nationality: Optional[str]
    current_country: Optional[str]
    current_city: Optional[str]
    relocation_preference: Optional[str]
    relocation_locations: Optional[str]
    desired_salary_amount: Optional[float]
    desired_salary_currency: Optional[str]
    desired_salary_period: Optional[str]
    desired_salary_text: Optional[str]
    desired_salary_warning: Optional[str]
    reminder_frequency_days: Optional[int]
    reminder_next_at: Optional[datetime]
    last_reminder_at: Optional[datetime]

    profession: Optional[ProfessionOut]
    experience_years: Optional[int]
    experience_details: Optional[str]

    photo_path: Optional[str]

    summary: Optional[str]
    ai_analysis: Optional[dict]
    weak_points: Optional[str]
    risks: Optional[str]
    quiz_score: Optional[float]

    status: str
    is_blocked: bool
    block_reason: Optional[str]

    registration_started_at: Optional[datetime]
    registration_completed_at: Optional[datetime]
    created_at: datetime
    updated_at: datetime

    assigned_manager: Optional[ManagerOut]
    vacancy: Optional[VacancyOut]
    quiz_results: list[QuizResultOut] = []

    model_config = {"from_attributes": True}


class CandidateUpdate(BaseModel):
    full_name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    age: Optional[int] = None
    current_city: Optional[str] = None
    relocation_preference: Optional[str] = None
    relocation_locations: Optional[str] = None
    desired_salary_amount: Optional[float] = None
    desired_salary_currency: Optional[str] = None
    desired_salary_period: Optional[str] = None
    desired_salary_text: Optional[str] = None
    desired_salary_warning: Optional[str] = None
    reminder_frequency_days: Optional[int] = None
    reminder_next_at: Optional[datetime] = None
    last_reminder_at: Optional[datetime] = None
    status: Optional[str] = None
    assigned_manager_id: Optional[int] = None
    vacancy_id: Optional[int] = None
    is_blocked: Optional[bool] = None
    block_reason: Optional[str] = None
    summary: Optional[str] = None


class CandidateListResponse(BaseModel):
    total: int
    items: list[CandidateListItem]


# ─────────────────────────────────────────────
# FORBIDDEN WORDS
# ─────────────────────────────────────────────

class ForbiddenWordCreate(BaseModel):
    word: str
    category: str = "spam"

    @field_validator("word")
    @classmethod
    def lowercase_word(cls, v: str) -> str:
        return v.lower().strip()


class ForbiddenWordOut(BaseModel):
    id: int
    word: str
    category: str
    is_active: bool
    created_at: datetime

    model_config = {"from_attributes": True}


# ─────────────────────────────────────────────
# DASHBOARD STATS
# ─────────────────────────────────────────────

class DashboardStats(BaseModel):
    total_candidates: int
    new_candidates: int
    in_review: int
    approved: int
    rejected: int
    total_vacancies: int
    total_managers: int
