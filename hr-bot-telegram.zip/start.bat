@echo off
chcp 65001 >nul
title HR Bot v6
cd /d "%~dp0"
color 0A

if not exist "venv\Scripts\python.exe" (
    echo [ERROR] Zapustite snachala install.bat
    pause & exit /b 1
)
if not exist ".env" (
    echo [ERROR] .env ne najden. Zapustite install.bat
    pause & exit /b 1
)
call venv\Scripts\activate.bat

:MENU
cls
echo.
echo  =============================================
echo   HR BOT SYSTEM v6
echo  =============================================
echo.
echo   [1] Zapustit VSE  (bot + veb-panel)
echo   [2] Tolko Telegram bot
echo   [3] Tolko veb-panel  (port 8000)
echo   [4] Tray-prilozhenie
echo   [5] NocoDB  (docker compose up)
echo   [6] Nastrojka tablic NocoDB
echo   [7] Healthcheck
echo   [0] Vyhod
echo.
echo  =============================================
echo.
set /p CH=  Vybor: 

if "%CH%"=="1" goto ALL
if "%CH%"=="2" goto BOT
if "%CH%"=="3" goto WEB
if "%CH%"=="4" goto TRAY
if "%CH%"=="5" goto NOCODB
if "%CH%"=="6" goto SETUP
if "%CH%"=="7" goto HEALTH
if "%CH%"=="0" exit /b 0
goto MENU

:ALL
echo.
start "HR Bot" /min cmd /c "cd /d %~dp0 && call venv\Scripts\activate.bat && python run_bot.py"
timeout /t 2 >nul
start "HR Web" /min cmd /c "cd /d %~dp0 && call venv\Scripts\activate.bat && python run_web.py"
timeout /t 3 >nul
start http://127.0.0.1:8000
echo [OK] Zapushcheno. Veb-panel: http://127.0.0.1:8000
echo     Nastrojki: http://127.0.0.1:8000/settings
echo     Ostanovka: stop.bat
echo.
pause
goto MENU

:BOT
start "HR Bot" cmd /k "cd /d %~dp0 && call venv\Scripts\activate.bat && python run_bot.py"
goto MENU

:WEB
start "HR Web" cmd /k "cd /d %~dp0 && call venv\Scripts\activate.bat && python run_web.py"
timeout /t 3 >nul & start http://127.0.0.1:8000
goto MENU

:TRAY
start "" venv\Scripts\pythonw.exe app\tray\app.py
echo [OK] Ikonka poyavitsya v uglu ekrana.
echo.
pause
goto MENU

:NOCODB
docker compose up -d
if errorlevel 1 (
    echo [ERROR] Docker nedostupyen.
) else (
    echo [OK] NocoDB: http://localhost:8080
    timeout /t 3 >nul
    start http://localhost:8080
)
pause
goto MENU

:SETUP
echo Nastrojka tablic NocoDB...
python setup_nocodb.py
echo.
pause
goto MENU

:HEALTH
python healthcheck.py
echo.
pause
goto MENU
