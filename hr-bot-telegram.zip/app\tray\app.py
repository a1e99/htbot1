"""
HR Bot System — Windows Tray Application (PySide6)

Что показывает:
  • Иконка в трее — меняет цвет (зелёный / оранжевый / красный)
  • Одиночный/двойной клик — открывает Панель управления
  • Правый клик — контекстное меню

Панель управления (4 вкладки):
  ⚙️ Сервисы   — управление ботом и веб-панелью
  📊 Статистика — live-граф кандидатов, разбивка по статусам
  📋 Лог        — хвост bot.log с цветами в реальном времени
  ℹ️ О системе  — python/пути/uptime/перезапуски
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from collections import deque
from datetime import datetime
from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, QTimer, QThread, Signal
from PySide6.QtGui import (
    QColor, QFont, QIcon, QPainter, QPen, QPixmap, QTextCursor,
)
from PySide6.QtWidgets import (
    QApplication, QDialog, QFrame, QHBoxLayout, QLabel,
    QMessageBox, QMenu, QPushButton,
    QSystemTrayIcon, QTabWidget, QTextEdit, QVBoxLayout, QWidget,
)

BASE_DIR = Path(__file__).resolve().parent.parent.parent

# ═══════════════════════════════════════════════
# COLOUR PALETTE
# ═══════════════════════════════════════════════
DARK   = "#0d0f14"
SURF   = "#141720"
SURF2  = "#1c2030"
SURF3  = "#242840"
BORD   = "#2a3050"
AMBER  = "#f5a623"
GREEN  = "#2ecc71"
RED    = "#e74c3c"
BLUE   = "#3b82f6"
PURPLE = "#9b59b6"
TEAL   = "#1abc9c"
TEXT   = "#e8eaf0"
MUTED  = "#5a637a"


# ═══════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════

def _uptime(s: float) -> str:
    if s < 60:   return f"{int(s)}с"
    if s < 3600: return f"{int(s//60)}м {int(s%60)}с"
    return f"{int(s//3600)}ч {int((s%3600)//60)}м"


def _make_icon(state: str = "idle") -> QIcon:
    colors = {
        "all":     ("#2ecc71", "#1a8a4a"),
        "partial": ("#f5a623", "#b87a18"),
        "stopped": ("#e74c3c", "#9b2d21"),
        "idle":    ("#505878", "#353b55"),
    }
    fill, ring = colors.get(state, colors["idle"])
    px = QPixmap(64, 64)
    px.fill(QColor(0, 0, 0, 0))
    p = QPainter(px)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setBrush(QColor(ring)); p.setPen(Qt.PenStyle.NoPen)
    p.drawEllipse(0, 0, 64, 64)
    p.setBrush(QColor(fill))
    p.drawEllipse(4, 4, 56, 56)
    p.setPen(QColor("#ffffff"))
    f = QFont("Arial", 17, QFont.Weight.Black)
    f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 1.0)
    p.setFont(f)
    p.drawText(px.rect(), Qt.AlignmentFlag.AlignCenter, "HR")
    p.end()
    return QIcon(px)


# ═══════════════════════════════════════════════
# LOG TAIL THREAD
# ═══════════════════════════════════════════════

class LogTailThread(QThread):
    new_lines = Signal(list)

    def __init__(self, path: Path, parent=None):
        super().__init__(parent)
        self._path = path
        self._running = True

    def run(self):
        while self._running:
            try:
                with open(self._path, "r", encoding="utf-8", errors="replace") as f:
                    f.seek(0, 2)
                    while self._running:
                        lines = f.readlines()
                        if lines:
                            self.new_lines.emit(lines)
                        time.sleep(0.4)
            except FileNotFoundError:
                time.sleep(2)

    def stop(self):
        self._running = False


# ═══════════════════════════════════════════════
# PROCESS MANAGER
# ═══════════════════════════════════════════════

class ProcessManager:
    def __init__(self):
        self._bot_proc: Optional[subprocess.Popen] = None
        self._web_proc: Optional[subprocess.Popen] = None
        self._bot_t0:   Optional[float] = None
        self._web_t0:   Optional[float] = None
        self._bot_restarts = 0
        self._web_restarts = 0

    def _py(self) -> str:
        v = BASE_DIR / "venv" / "Scripts" / "python.exe"
        return str(v) if v.exists() else sys.executable

    def _popen(self, script: str) -> subprocess.Popen:
        flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        return subprocess.Popen(
            [self._py(), str(BASE_DIR / script)],
            cwd=str(BASE_DIR), creationflags=flags,
        )

    def start_bot(self) -> bool:
        if self.bot_running(): return False
        try:
            self._bot_proc = self._popen("run_bot.py")
            self._bot_t0 = time.monotonic()
            return True
        except Exception: return False

    def stop_bot(self) -> bool:
        if not self.bot_running(): return False
        self._bot_proc.terminate()
        try: self._bot_proc.wait(5)
        except subprocess.TimeoutExpired: self._bot_proc.kill()
        self._bot_proc = None
        return True

    def bot_running(self) -> bool:
        return self._bot_proc is not None and self._bot_proc.poll() is None

    def bot_uptime(self) -> Optional[float]:
        return (time.monotonic() - self._bot_t0) if self.bot_running() and self._bot_t0 else None

    def restart_bot(self) -> bool:
        self.stop_bot(); time.sleep(0.5)
        ok = self.start_bot()
        if ok: self._bot_restarts += 1
        return ok

    def start_web(self) -> bool:
        if self.web_running(): return False
        try:
            self._web_proc = self._popen("run_web.py")
            self._web_t0 = time.monotonic()
            return True
        except Exception: return False

    def stop_web(self) -> bool:
        if not self.web_running(): return False
        self._web_proc.terminate()
        try: self._web_proc.wait(5)
        except subprocess.TimeoutExpired: self._web_proc.kill()
        self._web_proc = None
        return True

    def web_running(self) -> bool:
        return self._web_proc is not None and self._web_proc.poll() is None

    def web_uptime(self) -> Optional[float]:
        return (time.monotonic() - self._web_t0) if self.web_running() and self._web_t0 else None

    def restart_web(self) -> bool:
        self.stop_web(); time.sleep(0.5)
        ok = self.start_web()
        if ok: self._web_restarts += 1
        return ok

    def stop_all(self):
        self.stop_bot(); self.stop_web()


# ═══════════════════════════════════════════════
# WIDGETS
# ═══════════════════════════════════════════════

class StatCard(QFrame):
    def __init__(self, label: str, value: str = "—", color: str = AMBER):
        super().__init__()
        self._color = color
        self.setFixedHeight(84)
        self._set_style(color)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 8, 14, 8)
        lay.setSpacing(2)
        self._lbl = QLabel(label.upper())
        self._lbl.setStyleSheet(
            f"color:{MUTED};font-size:10px;letter-spacing:1.2px;"
            "border:none;background:transparent;"
        )
        self._val = QLabel(value)
        self._val.setStyleSheet(
            f"color:{color};font-size:24px;font-weight:900;"
            "font-family:'Segoe UI',sans-serif;border:none;background:transparent;"
        )
        lay.addWidget(self._lbl)
        lay.addWidget(self._val)

    def _set_style(self, c: str):
        self.setStyleSheet(
            f"QFrame{{background:{SURF2};border:1px solid {BORD};"
            f"border-top:3px solid {c};border-radius:9px;}}"
        )

    def update_value(self, v: str, color: Optional[str] = None):
        self._val.setText(v)
        if color:
            self._color = color
            self._val.setStyleSheet(
                f"color:{color};font-size:24px;font-weight:900;"
                "font-family:'Segoe UI',sans-serif;border:none;background:transparent;"
            )
            self._set_style(color)


class ServiceRow(QFrame):
    def __init__(self, name: str, icon: str):
        super().__init__()
        self.setStyleSheet(
            f"QFrame{{background:{SURF2};border:1px solid {BORD};border-radius:9px;}}"
        )
        lay = QHBoxLayout(self)
        lay.setContentsMargins(18, 13, 18, 13)
        self._dot = QLabel("●")
        self._dot.setFixedWidth(24)
        self._dot.setStyleSheet(
            f"color:{MUTED};font-size:20px;border:none;background:transparent;"
        )
        self._name = QLabel(f"{icon}  {name}")
        self._name.setStyleSheet(
            f"color:{TEXT};font-size:14px;font-weight:700;border:none;background:transparent;"
        )
        self._up = QLabel("—")
        self._up.setStyleSheet(
            f"color:{MUTED};font-size:12px;border:none;background:transparent;"
        )
        self.btn_start   = self._btn("▶  Старт",   GREEN)
        self.btn_stop    = self._btn("■  Стоп",    RED)
        self.btn_restart = self._btn("↺  Рестарт", AMBER)
        for w in (self._dot, self._name): lay.addWidget(w)
        lay.addStretch()
        lay.addWidget(self._up)
        lay.addSpacing(12)
        for b in (self.btn_start, self.btn_stop, self.btn_restart): lay.addWidget(b)

    @staticmethod
    def _btn(txt: str, c: str) -> QPushButton:
        b = QPushButton(txt)
        b.setFixedHeight(30)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.setStyleSheet(
            f"QPushButton{{background:transparent;color:{c};"
            f"border:1px solid {c};border-radius:5px;"
            f"padding:0 12px;font-size:12px;font-weight:600;}}"
            f"QPushButton:hover{{background:{c}22;}}"
            f"QPushButton:pressed{{background:{c}44;}}"
            f"QPushButton:disabled{{color:{MUTED};border-color:{MUTED};}}"
        )
        return b

    def set_running(self, running: bool, ut: Optional[float] = None):
        c = GREEN if running else RED
        self._dot.setStyleSheet(
            f"color:{c};font-size:20px;border:none;background:transparent;"
        )
        self._up.setText(f"⏱ {_uptime(ut)}" if ut is not None else "—")
        self.btn_start.setEnabled(not running)
        self.btn_stop.setEnabled(running)
        self.btn_restart.setEnabled(running)


class MiniChart(QWidget):
    """Bar chart with 60 data points."""
    def __init__(self, title: str = "", color: str = AMBER, parent=None):
        super().__init__(parent)
        self._title = title
        self._color = QColor(color)
        self._data: deque[int] = deque([0] * 60, maxlen=60)
        self.setMinimumHeight(110)
        self.setStyleSheet(
            f"background:{SURF2};border:1px solid {BORD};border-radius:9px;"
        )

    def push(self, val: int):
        self._data.append(val)
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        W, H = self.width(), self.height()
        PAD, TITLE_H = 10, 20
        cw = W - PAD * 2
        ch = H - PAD * 2 - TITLE_H

        data = list(self._data)
        mx = max(data) if max(data) > 0 else 1

        # Title
        p.setPen(QColor(MUTED))
        p.setFont(QFont("Segoe UI", 9))
        p.drawText(PAD, PAD + 13, self._title)

        # Bars
        bw = cw / len(data)
        for i, v in enumerate(data):
            bh = int((v / mx) * ch)
            x = PAD + i * bw
            y = PAD + TITLE_H + ch - bh
            a = int(100 + 155 * (v / mx))
            c = QColor(self._color); c.setAlpha(a)
            p.fillRect(int(x), int(y), max(1, int(bw) - 1), bh, c)

        # Baseline
        p.setPen(QPen(QColor(BORD), 1))
        base_y = PAD + TITLE_H + ch
        p.drawLine(PAD, base_y, W - PAD, base_y)

        # Max label
        if mx > 0:
            p.setPen(QColor(MUTED))
            p.setFont(QFont("Segoe UI", 8))
            p.drawText(PAD, PAD + TITLE_H + 10, str(mx))
        p.end()


class LogViewer(QTextEdit):
    MAX = 800

    def __init__(self):
        super().__init__()
        self.setReadOnly(True)
        self._count = 0
        self.setStyleSheet(
            f"QTextEdit{{background:#080a10;color:#9bb0cc;"
            f"font-family:Consolas,'Courier New',monospace;"
            f"font-size:12px;border:1px solid {BORD};border-radius:8px;padding:10px;}}"
        )

    def append_lines(self, lines: list):
        for line in lines:
            line = line.rstrip()
            if not line: continue
            if   "ERROR" in line or "CRITICAL" in line: c = RED
            elif "WARNING" in line or "WARN"   in line: c = AMBER
            elif "SUCCESS" in line:                     c = GREEN
            elif "DEBUG"   in line:                     c = MUTED
            else:                                       c = "#9bb0cc"
            self.setTextColor(QColor(c))
            self.append(line)
            self._count += 1

        if self._count > self.MAX:
            doc = self.document()
            cur = QTextCursor(doc)
            cur.movePosition(QTextCursor.MoveOperation.Start)
            for _ in range(self._count - self.MAX):
                cur.select(QTextCursor.SelectionType.LineUnderCursor)
                cur.removeSelectedText()
                cur.deleteChar()
            self._count = self.MAX

        sb = self.verticalScrollBar()
        sb.setValue(sb.maximum())


# ═══════════════════════════════════════════════
# STATUS WINDOW
# ═══════════════════════════════════════════════

class StatusWindow(QDialog):
    def __init__(self, pm: ProcessManager, app: "HRBotTray"):
        super().__init__(None, Qt.WindowType.Window)
        self._pm  = pm
        self._app = app
        self._log_thread: Optional[LogTailThread] = None
        self._stats: dict = {}

        self.setWindowTitle("HR Bot System — Панель управления")
        self.setMinimumSize(840, 640)
        self.resize(980, 720)
        self.setWindowIcon(_make_icon("all"))
        self._style()
        self._build()
        self._start_log()

        self._tmr = QTimer(self)
        self._tmr.timeout.connect(self._refresh)
        self._tmr.start(2000)
        self._refresh()

    # ── STYLE ──────────────────────────────

    def _style(self):
        self.setStyleSheet(
            f"QDialog{{background:{DARK};}}"
            f"QLabel{{color:{TEXT};}}"
            f"QTabWidget::pane{{border:1px solid {BORD};background:{DARK};"
            f"border-radius:0 0 8px 8px;}}"
            f"QTabBar::tab{{background:{SURF};color:{MUTED};"
            f"padding:9px 22px;border:1px solid {BORD};"
            f"border-bottom:none;border-radius:7px 7px 0 0;"
            f"margin-right:3px;font-size:13px;}}"
            f"QTabBar::tab:selected{{background:{SURF2};color:{TEXT};"
            f"border-bottom:2px solid {AMBER};}}"
            f"QTabBar::tab:hover{{color:{TEXT};}}"
            f"QScrollBar:vertical{{background:{SURF};width:7px;border-radius:4px;}}"
            f"QScrollBar::handle:vertical{{background:{BORD};border-radius:4px;"
            f"min-height:20px;}}"
            f"QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{{height:0;}}"
        )

    # ── BUILD ──────────────────────────────

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 14)
        root.setSpacing(12)

        # Header
        hdr = QHBoxLayout()
        ico = QLabel()
        ico.setPixmap(_make_icon("all").pixmap(36, 36))
        ttl = QLabel("HR Bot System")
        ttl.setStyleSheet(
            f"color:{TEXT};font-size:20px;font-weight:900;"
            "font-family:'Segoe UI',sans-serif;"
        )
        ver = QLabel("v1.0")
        ver.setStyleSheet(
            f"color:{MUTED};font-size:10px;border:1px solid {BORD};"
            f"border-radius:4px;padding:1px 7px;background:{SURF};"
        )
        self._lbl_time = QLabel()
        self._lbl_time.setStyleSheet(f"color:{MUTED};font-size:12px;")
        for w in (ico, ttl, ver): hdr.addWidget(w); hdr.addSpacing(6 if w is ico else 0)
        hdr.addStretch(); hdr.addWidget(self._lbl_time)
        root.addLayout(hdr)

        # Stat cards
        cards = QHBoxLayout(); cards.setSpacing(10)
        self._c_bot  = StatCard("Telegram Бот",  "—", GREEN)
        self._c_web  = StatCard("Веб-панель",     "—", BLUE)
        self._c_cand = StatCard("Кандидатов",     "—", AMBER)
        self._c_new  = StatCard("Новых",          "—", PURPLE)
        self._c_appr = StatCard("Одобрено",       "—", TEAL)
        for c in (self._c_bot, self._c_web, self._c_cand, self._c_new, self._c_appr):
            cards.addWidget(c)
        root.addLayout(cards)

        # Tabs
        self._tabs = QTabWidget()
        root.addWidget(self._tabs)
        self._tab_services()
        self._tab_stats()
        self._tab_log()
        self._tab_info()

        # Footer
        foot = QHBoxLayout(); foot.addStretch()
        b = QPushButton("↙  Свернуть в трей")
        b.setFixedHeight(32)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.setStyleSheet(
            f"QPushButton{{background:{SURF3};color:{MUTED};"
            f"border:1px solid {BORD};border-radius:7px;"
            f"font-size:12px;padding:0 18px;}}"
            f"QPushButton:hover{{color:{TEXT};}}"
        )
        b.clicked.connect(self.hide)
        foot.addWidget(b)
        root.addLayout(foot)

    # ── TAB: SERVICES ──────────────────────

    def _tab_services(self):
        w = QWidget(); w.setStyleSheet(f"background:{DARK};")
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 14, 0, 0)
        lay.setSpacing(10)

        self._row_bot = ServiceRow("Telegram Бот", "🤖")
        self._row_web = ServiceRow("Веб-панель",   "🌐")
        self._row_bot.btn_start.clicked.connect(self._app.start_bot)
        self._row_bot.btn_stop.clicked.connect(self._app.stop_bot)
        self._row_bot.btn_restart.clicked.connect(
            lambda: (self._pm.restart_bot(), self._refresh())
        )
        self._row_web.btn_start.clicked.connect(self._app.start_web)
        self._row_web.btn_stop.clicked.connect(self._app.stop_web)
        self._row_web.btn_restart.clicked.connect(
            lambda: (self._pm.restart_web(), self._refresh())
        )
        lay.addWidget(self._row_bot)
        lay.addWidget(self._row_web)

        # Quick bar
        qa = QFrame()
        qa.setStyleSheet(
            f"background:{SURF2};border:1px solid {BORD};border-radius:9px;"
        )
        ql = QHBoxLayout(qa); ql.setContentsMargins(16, 10, 16, 10); ql.setSpacing(10)
        ql.addWidget(self._solid("🚀  Запустить всё",  self._app.start_all, GREEN, DARK))
        ql.addWidget(self._solid("⏹  Остановить всё", self._app.stop_all,  RED,   DARK))
        ql.addWidget(self._solid("🌐  Открыть панель", self._app.open_web,  BLUE,  DARK))
        ql.addStretch()
        ql.addWidget(self._solid("📂  Папка логов",   self._app.open_logs, SURF3, TEXT))
        lay.addWidget(qa)
        lay.addStretch()
        self._tabs.addTab(w, "⚙️  Сервисы")

    # ── TAB: STATS ─────────────────────────

    def _tab_stats(self):
        w = QWidget(); w.setStyleSheet(f"background:{DARK};")
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 14, 0, 0)
        lay.setSpacing(12)

        # Charts
        ch_row = QHBoxLayout(); ch_row.setSpacing(10)
        self._ch_total = MiniChart("Всего кандидатов",  AMBER)
        self._ch_new   = MiniChart("Новые кандидаты",   PURPLE)
        ch_row.addWidget(self._ch_total)
        ch_row.addWidget(self._ch_new)
        lay.addLayout(ch_row)

        # Status breakdown
        bd = QFrame()
        bd.setStyleSheet(
            f"background:{SURF2};border:1px solid {BORD};border-radius:9px;"
        )
        bl = QVBoxLayout(bd); bl.setContentsMargins(16, 12, 16, 12)
        hdr = QLabel("КАНДИДАТЫ ПО СТАТУСАМ")
        hdr.setStyleSheet(
            f"color:{MUTED};font-size:10px;letter-spacing:1.2px;"
            "border:none;background:transparent;"
        )
        bl.addWidget(hdr)
        self._st_vals: dict[str, QLabel] = {}
        statuses = [
            ("new",                  "🆕 Новые",            PURPLE),
            ("in_review",            "🔍 На рассмотрении",  BLUE),
            ("approved",             "✅ Одобрены",          GREEN),
            ("rejected",             "❌ Отклонены",         RED),
            ("clarification_needed", "❓ Уточнение",         AMBER),
        ]
        for key, label, color in statuses:
            r = QHBoxLayout()
            lb = QLabel(label)
            lb.setStyleSheet(
                f"color:{TEXT};font-size:13px;border:none;background:transparent;"
            )
            vl = QLabel("—")
            vl.setStyleSheet(
                f"color:{color};font-size:13px;font-weight:700;"
                "font-family:'Segoe UI',sans-serif;border:none;background:transparent;"
            )
            self._st_vals[key] = vl
            r.addWidget(lb); r.addStretch(); r.addWidget(vl)
            bl.addLayout(r)
        lay.addWidget(bd)

        # Events
        ev = QFrame()
        ev.setStyleSheet(
            f"background:{SURF2};border:1px solid {BORD};border-radius:9px;"
        )
        el = QVBoxLayout(ev); el.setContentsMargins(16, 12, 16, 12)
        eh = QLabel("ПОСЛЕДНИЕ СОБЫТИЯ")
        eh.setStyleSheet(
            f"color:{MUTED};font-size:10px;letter-spacing:1.2px;"
            "border:none;background:transparent;"
        )
        self._ev_lbl = QLabel("—")
        self._ev_lbl.setStyleSheet(
            f"color:{TEXT};font-size:12px;line-height:1.7;"
            "border:none;background:transparent;"
        )
        self._ev_lbl.setWordWrap(True)
        el.addWidget(eh); el.addWidget(self._ev_lbl)
        lay.addWidget(ev)

        self._tabs.addTab(w, "📊  Статистика")

    # ── TAB: LOG ───────────────────────────

    def _tab_log(self):
        w = QWidget(); w.setStyleSheet(f"background:{DARK};")
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 12, 0, 0)
        lay.setSpacing(8)

        bar = QHBoxLayout()
        lbl = QLabel("📋  bot.log — в реальном времени")
        lbl.setStyleSheet(f"color:{MUTED};font-size:12px;")
        btn_clear = QPushButton("🗑  Очистить")
        btn_clear.setFixedHeight(26)
        btn_clear.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_clear.setStyleSheet(
            f"QPushButton{{background:transparent;color:{MUTED};"
            f"border:1px solid {BORD};border-radius:5px;"
            f"font-size:11px;padding:0 10px;}}"
            f"QPushButton:hover{{color:{TEXT};border-color:{TEXT};}}"
        )
        self._log_view = LogViewer()
        btn_clear.clicked.connect(self._log_view.clear)
        bar.addWidget(lbl); bar.addStretch(); bar.addWidget(btn_clear)
        lay.addLayout(bar)
        lay.addWidget(self._log_view)
        self._tabs.addTab(w, "📋  Лог")

    # ── TAB: INFO ──────────────────────────

    def _tab_info(self):
        w = QWidget(); w.setStyleSheet(f"background:{DARK};")
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 12, 0, 0)
        self._info = QTextEdit()
        self._info.setReadOnly(True)
        self._info.setStyleSheet(
            f"QTextEdit{{background:{SURF2};color:{TEXT};"
            f"border:1px solid {BORD};border-radius:9px;"
            f"padding:16px;font-size:13px;font-family:'Segoe UI',sans-serif;}}"
        )
        lay.addWidget(self._info)
        self._tabs.addTab(w, "ℹ️  О системе")

    # ── REFRESH ────────────────────────────

    def _refresh(self):
        self._lbl_time.setText(datetime.now().strftime("%d.%m.%Y  %H:%M:%S"))
        bot = self._pm.bot_running()
        web = self._pm.web_running()

        self._c_bot.update_value("Работает" if bot else "Стоп", GREEN if bot else RED)
        self._c_web.update_value("Работает" if web else "Стоп", BLUE  if web else RED)
        self._row_bot.set_running(bot, self._pm.bot_uptime())
        self._row_web.set_running(web, self._pm.web_uptime())

        if web:
            threading.Thread(target=self._fetch, daemon=True).start()

        self._rebuild_info(bot, web)

    def _fetch(self):
        try:
            with urllib.request.urlopen(
                "http://127.0.0.1:8000/api/dashboard/stats", timeout=1
            ) as r:
                self._stats = json.loads(r.read())
                QTimer.singleShot(0, self._apply_stats)
        except Exception:
            pass

    def _apply_stats(self):
        d = self._stats
        total = d.get("total_candidates", 0)
        new   = d.get("new_candidates",   0)
        appr  = d.get("approved_candidates", 0)

        self._c_cand.update_value(str(total), AMBER)
        self._c_new.update_value(str(new),    PURPLE)
        self._c_appr.update_value(str(appr),  TEAL)

        self._ch_total.push(int(total))
        self._ch_new.push(int(new))

        by = d.get("by_status", {})
        for k, lbl in self._st_vals.items():
            lbl.setText(str(by.get(k, 0)))

        # Read last 5 events from log
        events = []
        log = BASE_DIR / "data" / "logs" / "bot.log"
        if log.exists():
            try:
                with open(log, "r", encoding="utf-8", errors="replace") as f:
                    lines = f.readlines()
                for line in reversed(lines[-60:]):
                    line = line.strip()
                    if line and any(t in line for t in ("INFO", "WARNING", "ERROR")):
                        parts = line.split("|")
                        clean = (parts[-1].strip() if len(parts) > 1 else line)[:88]
                        events.append(clean)
                        if len(events) >= 5: break
            except Exception:
                pass
        self._ev_lbl.setText(
            "\n".join(f"• {e}" for e in events) if events else "—"
        )

    def _rebuild_info(self, bot: bool, web: bool):
        b_up = _uptime(self._pm.bot_uptime()) if self._pm.bot_uptime() else "—"
        w_up = _uptime(self._pm.web_uptime()) if self._pm.web_uptime() else "—"
        db   = BASE_DIR / "data" / "hr_bot.db"
        db_s = f"{db.stat().st_size/1024:.1f} KB" if db.exists() else "не создана"

        def row(k, v):
            return (
                f"<tr>"
                f"<td style='color:{MUTED};font-size:10px;text-transform:uppercase;"
                f"letter-spacing:.5px;padding:7px 10px;border-bottom:1px solid {BORD};"
                f"width:175px'>{k}</td>"
                f"<td style='font-size:13px;padding:7px 10px;"
                f"border-bottom:1px solid {BORD}'>{v}</td>"
                f"</tr>"
            )
        def section(title):
            return (
                f"<h3 style='color:{AMBER};font-size:10px;text-transform:uppercase;"
                f"letter-spacing:1px;margin:14px 0 4px'>{title}</h3>"
            )

        html = (
            f"<style>body{{font-family:'Segoe UI',sans-serif;color:{TEXT};"
            f"margin:0}}table{{border-collapse:collapse;width:100%}}</style>"
            + section("Telegram Бот")
            + "<table>"
            + row("Статус", f"{'🟢 Работает' if bot else '🔴 Остановлен'}")
            + row("Uptime", b_up)
            + row("Перезапусков", str(self._pm._bot_restarts))
            + "</table>"
            + section("Веб-панель")
            + "<table>"
            + row("Статус", f"{'🟢 Работает' if web else '🔴 Остановлена'}")
            + row("Адрес",
                  f'<a href="http://127.0.0.1:8000" style="color:{BLUE}">'
                  f'http://127.0.0.1:8000</a>')
            + row("Uptime", w_up)
            + row("Перезапусков", str(self._pm._web_restarts))
            + "</table>"
            + section("Система")
            + "<table>"
            + row("Версия",      "HR Bot System 1.0")
            + row("Python",      sys.version.split()[0])
            + row("Директория",  str(BASE_DIR))
            + row("База данных", f"{db.name}  ({db_s})")
            + row("Логи",        str(BASE_DIR / 'data' / 'logs'))
            + "</table>"
        )
        self._info.setHtml(html)

    # ── LOG TAIL ───────────────────────────

    def _start_log(self):
        log = BASE_DIR / "data" / "logs" / "bot.log"
        log.parent.mkdir(parents=True, exist_ok=True)
        self._log_thread = LogTailThread(log)
        self._log_thread.new_lines.connect(self._log_view.append_lines)
        self._log_thread.start()

    def closeEvent(self, e):
        e.ignore(); self.hide()

    def cleanup(self):
        if self._log_thread:
            self._log_thread.stop()
            self._log_thread.wait(1000)

    # ── HELPERS ────────────────────────────

    @staticmethod
    def _solid(txt: str, fn, bg: str, fg: str = DARK) -> QPushButton:
        b = QPushButton(txt)
        b.setFixedHeight(34)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.setStyleSheet(
            f"QPushButton{{background:{bg};color:{fg};border:none;"
            f"border-radius:7px;font-size:13px;font-weight:700;padding:0 16px;}}"
            f"QPushButton:hover{{background:{bg}cc;}}"
            f"QPushButton:pressed{{background:{bg}99;}}"
        )
        b.clicked.connect(fn)
        return b


# ═══════════════════════════════════════════════
# TRAY APPLICATION
# ═══════════════════════════════════════════════

class HRBotTray(QWidget):
    def __init__(self):
        super().__init__()
        self.pm = ProcessManager()
        self._win: Optional[StatusWindow] = None
        self._crashes = {"bot": 0, "web": 0}

        self._setup_tray()
        self._build_menu()

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(3000)

    def _setup_tray(self):
        if not QSystemTrayIcon.isSystemTrayAvailable():
            QMessageBox.critical(None, "HR Bot", "Системный трей недоступен.")
            sys.exit(1)
        self.tray = QSystemTrayIcon(self)
        self.tray.setIcon(_make_icon("idle"))
        self.tray.setToolTip("HR Bot System")
        self.tray.activated.connect(self._on_activate)
        self.tray.show()
        self.tray.showMessage(
            "HR Bot System",
            "Запущен ✅\nНажмите на иконку для открытия панели управления.",
            QSystemTrayIcon.MessageIcon.Information, 3500,
        )

    def _build_menu(self):
        m = QMenu()
        t = m.addAction("🤖  HR Bot System"); t.setEnabled(False)
        m.addSeparator()
        m.addAction("📊  Открыть панель").triggered.connect(self.show_window)
        m.addAction("🌐  Открыть веб-панель").triggered.connect(self.open_web)
        m.addSeparator()
        self._a_start_all = m.addAction("🚀  Запустить всё")
        self._a_stop_all  = m.addAction("⏹  Остановить всё")
        self._a_start_all.triggered.connect(self.start_all)
        self._a_stop_all.triggered.connect(self.stop_all)
        m.addSeparator()
        self._a_start_bot = m.addAction("▶  Бот: Запустить")
        self._a_stop_bot  = m.addAction("■  Бот: Стоп")
        self._a_start_bot.triggered.connect(self.start_bot)
        self._a_stop_bot.triggered.connect(self.stop_bot)
        m.addSeparator()
        self._a_start_web = m.addAction("▶  Веб: Запустить")
        self._a_stop_web  = m.addAction("■  Веб: Стоп")
        self._a_start_web.triggered.connect(self.start_web)
        self._a_stop_web.triggered.connect(self.stop_web)
        m.addSeparator()
        m.addAction("📂  Папка логов").triggered.connect(self.open_logs)
        m.addSeparator()
        self._a_status = m.addAction("⚪  Статус...")
        self._a_status.setEnabled(False)
        m.addSeparator()
        m.addAction("❌  Выход").triggered.connect(self.quit_app)
        self.tray.setContextMenu(m)

    def _tick(self):
        bot = self.pm.bot_running()
        web = self.pm.web_running()

        # Auto-restart on crash (max 5)
        if not bot and self.pm._bot_t0 is not None and self._crashes["bot"] < 5:
            self._crashes["bot"] += 1
            self.pm.start_bot()
            self.tray.showMessage("HR Bot",
                f"⚠️ Бот упал, перезапуск #{self._crashes['bot']}",
                QSystemTrayIcon.MessageIcon.Warning, 3000)

        if not web and self.pm._web_t0 is not None and self._crashes["web"] < 5:
            self._crashes["web"] += 1
            self.pm.start_web()

        bot = self.pm.bot_running()
        web = self.pm.web_running()
        state = "all" if (bot and web) else "partial" if (bot or web) else "stopped"
        self.tray.setIcon(_make_icon(state))

        b = _uptime(self.pm.bot_uptime()) if self.pm.bot_uptime() else "—"
        w = _uptime(self.pm.web_uptime()) if self.pm.web_uptime() else "—"
        self.tray.setToolTip(
            f"HR Bot System\n"
            f"{'🟢' if bot else '🔴'} Бот: {b}\n"
            f"{'🟢' if web else '🔴'} Веб: {w}"
        )
        self._a_status.setText(
            f"  {'🟢' if bot else '🔴'} Бот   {'🟢' if web else '🔴'} Веб"
        )
        self._a_start_bot.setEnabled(not bot)
        self._a_stop_bot.setEnabled(bot)
        self._a_start_web.setEnabled(not web)
        self._a_stop_web.setEnabled(web)
        self._a_start_all.setEnabled(not (bot and web))
        self._a_stop_all.setEnabled(bot or web)

        if self._win and self._win.isVisible():
            self._win._refresh()

    def show_window(self):
        if self._win is None:
            self._win = StatusWindow(self.pm, self)
        self._win.show()
        self._win.raise_()
        self._win.activateWindow()

    def _on_activate(self, reason: QSystemTrayIcon.ActivationReason):
        if reason in (
            QSystemTrayIcon.ActivationReason.Trigger,
            QSystemTrayIcon.ActivationReason.DoubleClick,
        ):
            self.show_window()

    def start_bot(self):
        self._crashes["bot"] = 0
        if self.pm.start_bot():
            self.tray.showMessage("HR Bot", "🤖 Бот запущен",
                QSystemTrayIcon.MessageIcon.Information, 2000)
        self._tick()

    def stop_bot(self):
        self.pm._bot_t0 = None
        self.pm.stop_bot()
        self.tray.showMessage("HR Bot", "⏹ Бот остановлен",
            QSystemTrayIcon.MessageIcon.Warning, 2000)
        self._tick()

    def start_web(self):
        self._crashes["web"] = 0
        if self.pm.start_web():
            self.tray.showMessage("HR Bot", "🌐 Веб-панель запущена",
                QSystemTrayIcon.MessageIcon.Information, 2000)
            QTimer.singleShot(2500, self.open_web)
        self._tick()

    def stop_web(self):
        self.pm._web_t0 = None
        self.pm.stop_web()
        self._tick()

    def start_all(self):
        self._crashes = {"bot": 0, "web": 0}
        self.pm.start_bot()
        self.pm.start_web()
        self.tray.showMessage("HR Bot", "🚀 Все сервисы запущены",
            QSystemTrayIcon.MessageIcon.Information, 2500)
        QTimer.singleShot(2500, self.open_web)
        self._tick()

    def stop_all(self):
        self.pm._bot_t0 = None
        self.pm._web_t0 = None
        self.pm.stop_all()
        self.tray.showMessage("HR Bot", "⏹ Все сервисы остановлены",
            QSystemTrayIcon.MessageIcon.Warning, 2000)
        self._tick()

    def open_web(self):
        webbrowser.open("http://127.0.0.1:8000")

    def open_logs(self):
        logs = BASE_DIR / "data" / "logs"
        logs.mkdir(parents=True, exist_ok=True)
        if sys.platform == "win32":
            os.startfile(str(logs))

    def quit_app(self):
        if QMessageBox.question(
            None, "HR Bot — Выход",
            "Остановить все сервисы и выйти?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        ) == QMessageBox.StandardButton.Yes:
            self.pm.stop_all()
            if self._win:
                self._win.cleanup()
            self.tray.hide()
            QApplication.quit()


# ═══════════════════════════════════════════════
# ENTRY POINT
# ═══════════════════════════════════════════════

def run_tray():
    QApplication.setQuitOnLastWindowClosed(False)
    app = QApplication(sys.argv)
    app.setApplicationName("HR Bot System")
    app.setStyle("Fusion")
    tray = HRBotTray()
    tray.start_all()
    sys.exit(app.exec())


if __name__ == "__main__":
    sys.path.insert(0, str(BASE_DIR))
    try:
        from app.logger import setup_logger
        setup_logger()
    except Exception:
        pass
    run_tray()
