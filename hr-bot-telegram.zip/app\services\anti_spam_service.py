"""
Anti-spam service — reusable spam checking logic.
Can be used both from middleware and from handlers.
"""
from __future__ import annotations

import time
from collections import defaultdict, deque
from typing import Optional

from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.database import crud
from app.database.models import SpamEventType


class AntiSpamService:
    """
    Centralised anti-spam logic.
    Shared singleton — import `anti_spam` at module level.
    """

    def __init__(self) -> None:
        # {telegram_id: deque[timestamp]}
        self._timestamps: dict[int, deque] = defaultdict(
            lambda: deque(maxlen=settings.rate_limit_messages * 4)
        )
        # forbidden words cache
        self._forbidden: list[str] = []
        self._loaded_at: float = 0.0
        self._cache_ttl: float = 300.0  # 5 minutes

    # ─────────────────────────────────────────
    # RATE LIMITING
    # ─────────────────────────────────────────

    def check_rate_limit(self, telegram_id: int) -> bool:
        """Return True if user is within allowed rate."""
        now = time.monotonic()
        dq = self._timestamps[telegram_id]
        cutoff = now - settings.rate_limit_window
        while dq and dq[0] < cutoff:
            dq.popleft()
        if len(dq) >= settings.rate_limit_messages:
            return False      # rate limited
        dq.append(now)
        return True           # ok

    def reset_rate_limit(self, telegram_id: int) -> None:
        self._timestamps.pop(telegram_id, None)

    # ─────────────────────────────────────────
    # FORBIDDEN WORDS
    # ─────────────────────────────────────────

    async def refresh_forbidden_words(self, session: AsyncSession) -> None:
        """Force reload forbidden words from DB."""
        self._forbidden = await crud.get_all_forbidden_words(session)
        self._loaded_at = time.monotonic()
        logger.debug(f"[AntiSpam] Loaded {len(self._forbidden)} forbidden words")

    async def get_forbidden_words(self, session: AsyncSession) -> list[str]:
        """Return cached list, refreshing if stale."""
        if time.monotonic() - self._loaded_at > self._cache_ttl:
            await self.refresh_forbidden_words(session)
        return self._forbidden

    async def contains_forbidden_word(
        self, text: str, session: AsyncSession
    ) -> Optional[str]:
        """Return the matched forbidden word or None."""
        forbidden = await self.get_forbidden_words(session)
        text_lower = text.lower()
        for word in forbidden:
            if word in text_lower:
                return word
        return None

    # ─────────────────────────────────────────
    # MESSAGE QUALITY
    # ─────────────────────────────────────────

    def is_too_short(self, text: str, min_len: Optional[int] = None) -> bool:
        length = min_len or settings.min_message_length
        return len(text.strip()) < length

    def looks_like_spam(self, text: str) -> bool:
        """Heuristic: repeated chars, all caps short text, etc."""
        stripped = text.strip()
        if not stripped:
            return True
        # All same character
        if len(set(stripped.lower())) <= 2 and len(stripped) > 3:
            return True
        # ALL CAPS and short
        if stripped.isupper() and len(stripped) < 10:
            return True
        return False

    # ─────────────────────────────────────────
    # FULL CHECK — call from handler
    # ─────────────────────────────────────────

    async def check_message(
        self,
        telegram_id: int,
        text: str,
        session: AsyncSession,
        min_len: Optional[int] = None,
    ) -> tuple[bool, str]:
        """
        Run all checks on an incoming message.
        Returns (ok: bool, reason: str).
        Reason is empty string when ok=True.
        """
        # 1. Rate limit
        if not self.check_rate_limit(telegram_id):
            await crud.log_spam_event(
                session, telegram_id, SpamEventType.FLOOD,
                f">{settings.rate_limit_messages} msgs/{settings.rate_limit_window}s"
            )
            return False, "flood"

        # 2. Too short
        if text and self.is_too_short(text, min_len):
            await crud.log_spam_event(
                session, telegram_id, SpamEventType.SHORT_MESSAGE, text[:100]
            )
            return False, "too_short"

        # 3. Looks like spam
        if text and self.looks_like_spam(text):
            await crud.log_spam_event(
                session, telegram_id, SpamEventType.SHORT_MESSAGE,
                f"spam_pattern: {text[:50]}"
            )
            return False, "spam_pattern"

        # 4. Forbidden word
        if text:
            found = await self.contains_forbidden_word(text, session)
            if found:
                await crud.log_spam_event(
                    session, telegram_id, SpamEventType.FORBIDDEN_WORD,
                    f"word='{found}'"
                )
                return False, f"forbidden_word:{found}"

        return True, ""

    async def log_repeat_registration(
        self, telegram_id: int, session: AsyncSession
    ) -> None:
        await crud.log_spam_event(
            session, telegram_id, SpamEventType.REPEAT_REGISTRATION
        )
        logger.warning(f"[AntiSpam] Repeat registration attempt: {telegram_id}")


# ── Singleton instance ───────────────────────
anti_spam = AntiSpamService()
