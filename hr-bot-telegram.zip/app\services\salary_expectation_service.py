"""
Helpers for candidate salary expectations.

The logic is intentionally heuristic:
- vacancy salary range wins when available
- otherwise we estimate by profession keyword + country multiplier
"""
from __future__ import annotations

from dataclasses import dataclass


CURRENCY_TO_EUR = {
    "EUR": 1.0,
    "USD": 0.93,
    "PLN": 0.23,
    "CZK": 0.04,
    "UAH": 0.022,
    "GBP": 1.17,
}

COUNTRY_MULTIPLIERS = {
    "poland": 0.9,
    "польш": 0.9,
    "czech": 1.0,
    "чех": 1.0,
    "slovak": 0.95,
    "слова": 0.95,
    "germany": 1.45,
    "герман": 1.45,
    "deutschland": 1.45,
    "netherlands": 1.55,
    "нидерланд": 1.55,
    "holland": 1.55,
    "литв": 0.95,
    "latv": 0.9,
    "латв": 0.9,
    "estonia": 1.0,
    "эстон": 1.0,
    "norway": 2.2,
    "норв": 2.2,
    "sweden": 1.8,
    "швец": 1.8,
}

ROLE_BANDS_MONTHLY_EUR = {
    "свар": 2800,
    "welder": 2800,
    "electric": 2500,
    "элект": 2500,
    "driver": 2600,
    "водител": 2600,
    "truck": 2700,
    "warehouse": 1800,
    "склад": 1800,
    "forklift": 2000,
    "погруз": 2000,
    "clean": 1500,
    "клин": 1500,
    "убор": 1500,
    "cook": 2100,
    "повар": 2100,
    "builder": 2200,
    "стро": 2200,
    "монтаж": 2300,
    "installer": 2300,
    "operator": 2100,
    "оператор": 2100,
    "it": 4000,
    "developer": 4000,
}


@dataclass(slots=True)
class SalaryEvaluation:
    is_high: bool
    warning_text: str
    benchmark_salary_text: str


def _normalize_currency(currency: str | None) -> str:
    currency = (currency or "EUR").strip().upper()
    return currency if currency in CURRENCY_TO_EUR else "EUR"


def _monthly_amount(amount: float | int | None, currency: str | None, period: str | None) -> float:
    if not amount:
        return 0.0

    eur_rate = CURRENCY_TO_EUR.get(_normalize_currency(currency), 1.0)
    value_eur = float(amount) * eur_rate
    if period == "hour":
        return value_eur * 174
    return value_eur


def format_salary_expectation(amount: float | int | None, currency: str | None, period: str | None) -> str:
    if amount in (None, ""):
        return ""

    try:
        numeric = float(amount)
    except (TypeError, ValueError):
        return ""

    suffix = "в час" if period == "hour" else "в месяц"
    if numeric.is_integer():
        display = f"{int(numeric)}"
    else:
        display = f"{numeric:.2f}".rstrip("0").rstrip(".")
    return f"{display} {(_normalize_currency(currency))} {suffix}"


def _infer_country_multiplier(vacancy: dict | None) -> float:
    haystack = " ".join(
        filter(
            None,
            [
                str((vacancy or {}).get("country", "")),
                str((vacancy or {}).get("city", "")),
                str((vacancy or {}).get("location", "")),
                str((vacancy or {}).get("title", "")),
            ],
        )
    ).lower()

    for key, multiplier in COUNTRY_MULTIPLIERS.items():
        if key in haystack:
            return multiplier
    return 1.0


def _infer_role_base(vacancy_title: str) -> float:
    title = (vacancy_title or "").lower()
    for key, base in ROLE_BANDS_MONTHLY_EUR.items():
        if key in title:
            return float(base)
    return 2200.0


def _vacancy_market_monthly(vacancy: dict | None) -> float | None:
    if not vacancy:
        return None

    top = vacancy.get("salary_to") or vacancy.get("salary_from")
    if not top:
        return None

    currency = vacancy.get("currency") or "EUR"
    return _monthly_amount(top, currency, "month")


def evaluate_salary_expectation(
    amount: float | int | None,
    currency: str | None,
    period: str | None,
    vacancy_title: str,
    vacancy: dict | None = None,
) -> SalaryEvaluation:
    desired_monthly_eur = _monthly_amount(amount, currency, period)
    if desired_monthly_eur <= 0:
        return SalaryEvaluation(False, "", "")

    benchmark_monthly = _vacancy_market_monthly(vacancy)
    if benchmark_monthly is None:
        benchmark_monthly = _infer_role_base(vacancy_title) * _infer_country_multiplier(vacancy)

    benchmark_salary_text = f"около {int(round(benchmark_monthly))} EUR в месяц"
    ratio = desired_monthly_eur / benchmark_monthly if benchmark_monthly else 1.0
    if ratio < 1.35:
        return SalaryEvaluation(False, "", benchmark_salary_text)

    warning_text = (
        f"По нашей оценке это заметно выше типичной ставки по рынку "
        f"для этой специальности: <b>{benchmark_salary_text}</b>."
    )
    if ratio >= 1.8:
        warning_text += " Разница очень большая."

    return SalaryEvaluation(True, warning_text, benchmark_salary_text)
