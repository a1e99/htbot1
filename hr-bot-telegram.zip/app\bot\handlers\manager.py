"""Manager bot commands - NocoDB version."""
from __future__ import annotations
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from loguru import logger
from app.nocodb.client import noco
from app.config import settings

router = Router(name="manager")

def is_manager(tg_id: int) -> bool:
    return tg_id in settings.manager_chat_ids

class BroadcastStates(StatesGroup):
    WRITING_MESSAGE = State()

class PublishStates(StatesGroup):
    CHOOSING_VACANCY  = State()
    CHOOSING_CHANNELS = State()


# ── Candidate decision callbacks ──────────────────────────────────────

@router.callback_query(F.data.startswith("mgr_approve:"))
async def mgr_approve(cb: CallbackQuery):
    if not is_manager(cb.from_user.id): return await cb.answer("Нет доступа.")
    cid = int(cb.data.split(":")[1])
    await noco.update_candidate(cid, {"status": "approved"})
    cand = await noco.get_record(settings.noco_table_candidates, cid)
    if cand and cand.get("telegram_id"):
        try: await cb.bot.send_message(cand["telegram_id"], "🎉 <b>Ваша кандидатура одобрена!</b>\nС вами свяжется менеджер.", parse_mode="HTML")
        except Exception: pass
    await cb.message.edit_reply_markup(); await cb.answer("✅ Одобрен")
    await cb.message.reply(f"✅ Кандидат #{cid:06d} одобрен.")

@router.callback_query(F.data.startswith("mgr_reject:"))
async def mgr_reject(cb: CallbackQuery):
    if not is_manager(cb.from_user.id): return await cb.answer("Нет доступа.")
    cid = int(cb.data.split(":")[1])
    await noco.update_candidate(cid, {"status": "rejected"})
    cand = await noco.get_record(settings.noco_table_candidates, cid)
    if cand and cand.get("telegram_id"):
        try: await cb.bot.send_message(cand["telegram_id"], "❌ К сожалению, ваша кандидатура <b>не прошла отбор</b>.", parse_mode="HTML")
        except Exception: pass
    await cb.message.edit_reply_markup(); await cb.answer("❌ Отклонён")
    await cb.message.reply(f"❌ Кандидат #{cid:06d} отклонён.")

@router.callback_query(F.data.startswith("mgr_clarify:"))
async def mgr_clarify(cb: CallbackQuery):
    if not is_manager(cb.from_user.id): return await cb.answer("Нет доступа.")
    cid = int(cb.data.split(":")[1])
    await noco.update_candidate(cid, {"status": "clarification_needed"})
    cand = await noco.get_record(settings.noco_table_candidates, cid)
    if cand and cand.get("telegram_id"):
        try: await cb.bot.send_message(cand["telegram_id"], "❓ Менеджер запросил уточнение по вашей анкете.", parse_mode="HTML")
        except Exception: pass
    await cb.message.edit_reply_markup(); await cb.answer("❓ Обновлено")

@router.callback_query(F.data.startswith("mgr_forward:"))
async def mgr_forward(cb: CallbackQuery, state: FSMContext):
    if not is_manager(cb.from_user.id): return await cb.answer("Нет доступа.")
    cid = int(cb.data.split(":")[1])
    partners = await noco.list_partners(active_only=True)
    if not partners: return await cb.answer("Нет партнёров.", show_alert=True)
    btns = [[InlineKeyboardButton(text=f"🏢 {p['name']}", callback_data=f"ps:{cid}:{p['Id']}")] for p in partners]
    btns.append([InlineKeyboardButton(text="✅ Всем", callback_data=f"ps:{cid}:all")])
    await cb.message.answer(f"Выберите партнёра:", reply_markup=InlineKeyboardMarkup(inline_keyboard=btns))
    await cb.answer()

@router.callback_query(F.data.startswith("ps:"))
async def partner_sel(cb: CallbackQuery, state: FSMContext):
    _, cid_str, pid = cb.data.split(":")
    await state.update_data(bc_cid=int(cid_str), bc_pid=pid)
    await state.set_state(BroadcastStates.WRITING_MESSAGE)
    await cb.message.edit_reply_markup()
    await cb.message.answer("Сопроводительное сообщение (или <code>-</code> чтобы пропустить):", parse_mode="HTML")
    await cb.answer()

@router.message(BroadcastStates.WRITING_MESSAGE, F.text)
async def broadcast_send(message: Message, state: FSMContext):
    data = await state.get_data()
    cid, pid = data["bc_cid"], data["bc_pid"]
    msg = "" if message.text.strip() == "-" else message.text.strip()
    cand = await noco.get_record(settings.noco_table_candidates, cid)
    if not cand: await message.answer("Кандидат не найден."); return await state.clear()
    answers = await noco.list_answers(cid)
    from app.services.notification_service import broadcast_candidate_to_partner
    partners = await noco.list_partners() if pid == "all" else ([await noco.get_record(settings.noco_table_partners, int(pid))] if pid else [])
    sent = sum([1 for p in partners if p and await broadcast_candidate_to_partner(
        message.bot, cand, answers, p, cand.get("summary_text",""), cand.get("summary_score",50), message.from_user.id, msg)])
    await state.clear()
    await message.answer(f"📤 Отправлено {sent} из {len(partners)} партнёрам.")


# ── Publish vacancy to channel ─────────────────────────────────────────

@router.message(Command("publish_vacancy"))
async def cmd_publish(message: Message, state: FSMContext):
    if not is_manager(message.from_user.id): return
    vacs = await noco.list_vacancies(active_only=True)
    if not vacs: return await message.answer("Нет активных вакансий.")
    btns = [[InlineKeyboardButton(text=f"💼 {v['title']}", callback_data=f"pv:{v['Id']}")] for v in vacs]
    await message.answer("Выберите вакансию:", reply_markup=InlineKeyboardMarkup(inline_keyboard=btns))
    await state.set_state(PublishStates.CHOOSING_VACANCY)

@router.callback_query(F.data.startswith("pv:"), PublishStates.CHOOSING_VACANCY)
async def pub_choose_channel(cb: CallbackQuery, state: FSMContext):
    vid = int(cb.data.split(":")[1])
    channels = await noco.list_channels()
    if not channels:
        await cb.message.answer("Нет каналов. Добавьте через /add_channel")
        await state.clear(); return await cb.answer()
    await state.update_data(pub_vid=vid)
    btns = [[InlineKeyboardButton(text=f"📢 {c['title']}", callback_data=f"pc:{c['Id']}:{c['telegram_chat_id']}")] for c in channels]
    btns.append([InlineKeyboardButton(text="📢 Все каналы", callback_data="pc:all:all")])
    await cb.message.edit_reply_markup()
    await cb.message.answer("Выберите канал:", reply_markup=InlineKeyboardMarkup(inline_keyboard=btns))
    await state.set_state(PublishStates.CHOOSING_CHANNELS); await cb.answer()

@router.callback_query(F.data.startswith("pc:"), PublishStates.CHOOSING_CHANNELS)
async def pub_execute(cb: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    vid = data["pub_vid"]
    _, cid_str, tg_str = cb.data.split(":")
    vac = await noco.get_vacancy(vid)
    if not vac: await cb.answer("Вакансия не найдена.", show_alert=True); await state.clear(); return
    from app.services.notification_service import publish_vacancy_to_channel
    channels = await noco.list_channels() if cid_str == "all" else ([await noco.get_record(settings.noco_table_channels, int(cid_str))] if cid_str else [])
    sent = sum([1 for c in channels if c and await publish_vacancy_to_channel(cb.bot, vac, c["telegram_chat_id"], cb.from_user.id)])
    await state.clear(); await cb.message.edit_reply_markup()
    await cb.message.answer(f"📢 «{vac['title']}» опубликована в {sent}/{len(channels)} каналах."); await cb.answer()

    # Notify matching candidates in background
    try:
        from app.services.notification_service import notify_candidates_about_new_vacancy
        notified = await notify_candidates_about_new_vacancy(cb.bot, vac)
        if notified:
            await cb.message.answer(f"🔔 Уведомлено {notified} подходящих кандидатов.")
    except Exception as e:
        logger.warning(f"Candidate match notify failed: {e}")


# ── Info commands ──────────────────────────────────────────────────────

@router.message(Command("candidates"))
async def cmd_candidates(message: Message):
    if not is_manager(message.from_user.id): return
    total = await noco.count(settings.noco_table_candidates)
    new   = await noco.count(settings.noco_table_candidates, "(status,eq,new)")
    appr  = await noco.count(settings.noco_table_candidates, "(status,eq,approved)")
    rej   = await noco.count(settings.noco_table_candidates, "(status,eq,rejected)")
    await message.answer(
        f"👥 <b>Кандидаты:</b>\nВсего: <b>{total}</b>\n🆕 Новые: <b>{new}</b>\n✅ Одобрены: <b>{appr}</b>\n❌ Отклонены: <b>{rej}</b>\n\n📊 NocoDB: http://localhost:8080",
        parse_mode="HTML")

@router.message(Command("add_channel"))
async def cmd_add_channel(message: Message):
    if not is_manager(message.from_user.id): return
    await message.answer("Перешлите сообщение из канала или введите chat_id (напр. <code>-1001234567890</code>)", parse_mode="HTML")

@router.message(Command("list_channels"))
async def cmd_list_channels(message: Message):
    if not is_manager(message.from_user.id): return
    chs = await noco.list_channels()
    if not chs: return await message.answer("Каналов нет.")
    text = "📢 <b>Каналы:</b>\n\n" + "\n".join(f"• {c['title']} (<code>{c['telegram_chat_id']}</code>)" for c in chs)
    await message.answer(text, parse_mode="HTML")
