"""FastAPI main - NocoDB version. REST API + Jinja2 web panel."""
from __future__ import annotations
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from loguru import logger
from sqlalchemy import func, select
from app.config import settings
from app.api.routers import settings as settings_router
from app.database.base import async_session_factory
from app.database.models import BotGroup, BotGroupMember, Manager

BASE_DIR = Path(__file__).resolve().parent
WEB_DIR  = BASE_DIR.parent / "web"

app = FastAPI(title="HR Bot Admin Panel", version="2.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])

static_dir = WEB_DIR / "static"
static_dir.mkdir(parents=True, exist_ok=True)
app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")
templates = Jinja2Templates(directory=str(WEB_DIR / "templates"))

# API Routers
app.include_router(settings_router.router, prefix="/api")


# ── Dashboard stats (NocoDB) ──────────────────────────────────────────
@app.get("/api/dashboard/stats")
async def dashboard_stats():
    try:
        from app.nocodb.client import noco
        total = await noco.count(settings.noco_table_candidates)
        new   = await noco.count(settings.noco_table_candidates, "(status,eq,new)")
        rev   = await noco.count(settings.noco_table_candidates, "(status,eq,in_review)")
        appr  = await noco.count(settings.noco_table_candidates, "(status,eq,approved)")
        rej   = await noco.count(settings.noco_table_candidates, "(status,eq,rejected)")
        vacs  = await noco.count(settings.noco_table_vacancies)
        return {"total_candidates": total, "new_candidates": new, "in_review": rev,
                "approved": appr, "rejected": rej, "total_vacancies": vacs}
    except Exception:
        return {"total_candidates": 0, "new_candidates": 0, "in_review": 0,
                "approved": 0, "rejected": 0, "total_vacancies": 0}


# ── Candidates API ────────────────────────────────────────────────────
@app.get("/api/candidates")
async def api_candidates(status: str | None = None, limit: int = 50, offset: int = 0):
    from app.nocodb.client import noco
    return await noco.list_candidates(status=status, limit=limit, offset=offset)

@app.get("/api/candidates/{cid}")
async def api_candidate(cid: int):
    from app.nocodb.client import noco
    c = await noco.get_record(settings.noco_table_candidates, cid)
    if not c:
        from fastapi import HTTPException; raise HTTPException(404)
    answers = await noco.list_answers(cid)
    return {**c, "answers": answers}

@app.patch("/api/candidates/{cid}")
async def api_update_candidate(cid: int, data: dict):
    from app.nocodb.client import noco
    return await noco.update_candidate(cid, data)


# ── Web panel routes ──────────────────────────────────────────────────
@app.get("/",           response_class=HTMLResponse)
async def web_dashboard(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request})

@app.get("/candidates", response_class=HTMLResponse)
async def web_candidates(request: Request):
    return templates.TemplateResponse("candidates.html", {"request": request})

@app.get("/candidates/{cid}", response_class=HTMLResponse)
async def web_candidate_detail(request: Request, cid: int):
    return templates.TemplateResponse("candidate_detail.html", {"request": request, "candidate_id": cid})

@app.get("/vacancies",  response_class=HTMLResponse)
async def web_vacancies(request: Request):
    return templates.TemplateResponse("vacancies.html", {"request": request})

@app.get("/groups", response_class=HTMLResponse)
async def web_groups(request: Request):
    return templates.TemplateResponse("groups.html", {"request": request})

@app.get("/managers",   response_class=HTMLResponse)
async def web_managers(request: Request):
    return templates.TemplateResponse("managers.html", {"request": request})

@app.get("/settings",   response_class=HTMLResponse)
async def web_settings(request: Request):
    return templates.TemplateResponse("settings.html", {"request": request})

@app.get("/photos/{filename}")
async def serve_photo(filename: str):
    from fastapi.responses import FileResponse
    from fastapi import HTTPException
    p = settings.photos_dir / filename
    if not p.exists(): raise HTTPException(404)
    return FileResponse(str(p))


@app.get("/api/groups")
async def api_groups():
    async with async_session_factory() as session:
        result = await session.execute(
            select(
                BotGroup.id,
                BotGroup.title,
                BotGroup.purpose,
                BotGroup.telegram_chat_id,
                BotGroup.status,
                BotGroup.created_at,
                Manager.full_name.label("creator_name"),
                func.count(BotGroupMember.id).label("member_count"),
            )
            .outerjoin(Manager, Manager.id == BotGroup.created_by)
            .outerjoin(
                BotGroupMember,
                (BotGroupMember.group_id == BotGroup.id)
                & (BotGroupMember.left_at.is_(None)),
            )
            .group_by(
                BotGroup.id,
                BotGroup.title,
                BotGroup.purpose,
                BotGroup.telegram_chat_id,
                BotGroup.status,
                BotGroup.created_at,
                Manager.full_name,
            )
            .order_by(BotGroup.created_at.desc())
        )

    return [
        {
            "id": row.id,
            "title": row.title,
            "purpose": row.purpose,
            "telegram_chat_id": row.telegram_chat_id,
            "status": row.status.value if hasattr(row.status, "value") else row.status,
            "created_at": row.created_at.isoformat() if row.created_at else None,
            "creator_name": row.creator_name,
            "member_count": int(row.member_count or 0),
        }
        for row in result
    ]

@app.on_event("startup")
async def startup():
    logger.info(f"Web panel: http://{settings.web_host}:{settings.web_port}")
