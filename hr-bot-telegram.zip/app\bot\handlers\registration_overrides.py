"""
Overrides for registration flow that require moderation and draft recovery.
"""
from __future__ import annotations

from pathlib import Path

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from loguru import logger

from app.bot.handlers import registration as base_registration
from app.bot.states.registration import RegistrationStates
from app.nocodb.client import noco

router = Router(name="registration_overrides")


@router.message(RegistrationStates.RESUME, F.document)
async def reg_resume_with_moderation(message: Message, state: FSMContext) -> None:
    doc = message.document
    ext = Path(doc.file_name or "").suffix.lower()
    if ext not in {".pdf", ".doc", ".docx", ".txt"}:
        await message.answer(
            "⚠️ Поддерживаются форматы: PDF, DOC, DOCX и TXT.\n"
            "Попробуйте ещё раз или нажмите «Пропустить»."
        )
        return

    processing = await message.answer("⏳ Обрабатываю резюме...")
    data = await state.get_data()
    candidate_id = data["candidate_id"]
    resume_text = ""
    ai_profile: dict = {}

    try:
        from app.services.resume_service import (
            download_document,
            extract_text_from_bytes,
            parse_resume_with_ai,
            save_resume_file,
        )

        file_data = await download_document(message.bot, doc.file_id)
        resume_path = await save_resume_file(file_data, doc.file_name or "resume.pdf", candidate_id)
        resume_text = await extract_text_from_bytes(file_data, doc.file_name or "resume.pdf")
        ai_profile = await parse_resume_with_ai(resume_text)

        update: dict = {"resume_path": resume_path}
        if ai_profile.get("skills"):
            update["resume_skills"] = ", ".join(ai_profile["skills"][:20])
        if ai_profile.get("experience_years"):
            update["experience_years"] = ai_profile["experience_years"]
        if ai_profile.get("experience_details"):
            update["experience_details"] = ai_profile["experience_details"]
        if ai_profile.get("summary"):
            update["resume_summary"] = ai_profile["summary"]
        if ai_profile.get("education"):
            update["education"] = ai_profile["education"]
        if ai_profile.get("languages"):
            update["languages"] = ", ".join(ai_profile["languages"])
        await noco.update_candidate(candidate_id, update)

        skills_text = ""
        if ai_profile.get("skills"):
            skills_text = "\n\n🔧 <b>Навыки:</b> " + ", ".join(ai_profile["skills"][:12])
        await processing.edit_text(
            f"✅ Резюме загружено и проанализировано.{skills_text}",
            parse_mode="HTML",
        )
    except Exception as exc:
        logger.error(f"[ResumeOverride] error: {exc}")
        await processing.edit_text("⚠️ Не удалось полностью обработать файл. Отправляю его на модерацию.")

    preview_text = "\n".join(
        part
        for part in [ai_profile.get("summary", ""), ai_profile.get("experience_details", ""), resume_text]
        if part
    ) or f"Resume file: {doc.file_name or 'resume'}"

    is_approved = await base_registration._moderate_resume_and_continue(
        message=message,
        state=state,
        candidate_id=candidate_id,
        candidate_name=data.get("full_name", message.from_user.full_name),
        vacancy_title=data.get("vacancy_title", ""),
        resume_text=preview_text,
    )
    if is_approved:
        await base_registration._proceed_to_quiz(message, state, candidate_id)


async def _save_resume_questionnaire_with_moderation(
    message: Message,
    state: FSMContext,
    languages: str,
) -> None:
    data = await state.get_data()
    candidate_id = data["candidate_id"]

    specialty = data.get("rq_specialty", "")
    exp_years = data.get("rq_experience_years", 0)
    exp_details = data.get("rq_experience_details", "")
    skills = data.get("rq_skills", "")
    education = data.get("rq_education", "")

    await noco.update_candidate(
        candidate_id,
        {
            "resume_specialty": specialty,
            "experience_years": exp_years,
            "experience_details": exp_details,
            "resume_skills": skills,
            "education": education,
            "languages": languages,
            "resume_source": "questionnaire",
        },
    )

    exp_label = {
        0: "нет опыта",
        1: "до 1 года",
        2: "1-3 года",
        4: "3-5 лет",
        7: "5-10 лет",
        11: "более 10 лет",
    }.get(exp_years, f"{exp_years} лет")

    await message.answer(
        "✅ <b>Отлично, мини-резюме готово.</b>\n\n"
        f"👔 Специальность: <b>{specialty}</b>\n"
        f"📆 Опыт: <b>{exp_label}</b>\n"
        f"🔧 Навыки: {skills[:80]}{'...' if len(skills) > 80 else ''}\n"
        f"🎓 Образование: {education[:60]}{'...' if len(education) > 60 else ''}\n"
        f"🌍 Языки: {languages}",
        parse_mode="HTML",
    )

    preview_text = (
        f"Специальность: {specialty}\n"
        f"Опыт: {exp_label}\n"
        f"Детали опыта: {exp_details}\n"
        f"Навыки: {skills}\n"
        f"Образование: {education}\n"
        f"Языки: {languages}"
    )
    is_approved = await base_registration._moderate_resume_and_continue(
        message=message,
        state=state,
        candidate_id=candidate_id,
        candidate_name=data.get("full_name", message.from_user.full_name),
        vacancy_title=data.get("vacancy_title", ""),
        resume_text=preview_text,
    )
    if is_approved:
        await base_registration._proceed_to_quiz(message, state, candidate_id)


@router.callback_query(F.data.startswith("lang:"), RegistrationStates.RESUME_LANGUAGES)
async def rq_languages_cb_override(callback: CallbackQuery, state: FSMContext) -> None:
    value = callback.data.split(":", 1)[1]
    await callback.message.edit_reply_markup()
    await callback.answer()
    if value == "other":
        await callback.message.answer(
            "✏️ Напишите языки вручную. Например: Русский, Польский, Английский."
        )
        return
    await _save_resume_questionnaire_with_moderation(callback.message, state, value)


@router.message(RegistrationStates.RESUME_LANGUAGES, F.text)
async def rq_languages_text_override(message: Message, state: FSMContext) -> None:
    await _save_resume_questionnaire_with_moderation(message, state, message.text.strip())


@router.callback_query(F.data.startswith("resume_continue:"))
async def resume_continue(callback: CallbackQuery, state: FSMContext) -> None:
    candidate_id = int(callback.data.split(":")[1])
    candidate = await noco.get_record(__import__("app.config", fromlist=["settings"]).settings.noco_table_candidates, candidate_id)
    if not candidate or int(candidate.get("telegram_id", 0) or 0) != callback.from_user.id:
        await callback.answer("Продолжение анкеты недоступно.", show_alert=True)
        return

    if candidate.get("resume_moderation_status") != "approved":
        await callback.answer("Резюме ещё не одобрено.", show_alert=True)
        return

    await callback.answer()
    await state.clear()
    await state.update_data(
        candidate_id=candidate_id,
        vacancy_id=int(candidate.get("vacancy_id", 0) or 0),
        vacancy_title=candidate.get("vacancy_title", ""),
    )
    await base_registration._proceed_to_quiz(callback.message, state, candidate_id)
