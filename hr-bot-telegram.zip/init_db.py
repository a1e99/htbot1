"""
Run this script once to create the database and populate it with seed data.
Usage: python init_db.py
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from app.logger import setup_logger
from app.database.base import init_db, async_session_factory
from app.database.seed import seed_database


async def main():
    setup_logger()
    print("🗄️  Initializing database...")
    await init_db()
    print("🌱 Seeding initial data...")
    async with async_session_factory() as session:
        await seed_database(session)
    print("✅ Done! Database is ready.")


if __name__ == "__main__":
    asyncio.run(main())
