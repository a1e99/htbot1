"""Managers router."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.api.schemas.schemas import ManagerCreate, ManagerOut, ManagerUpdate, OkResponse
from app.database.base import get_session
from app.database import crud
from app.database.models import Manager

router = APIRouter(prefix="/managers", tags=["managers"])


@router.get("", response_model=list[ManagerOut])
async def list_managers(session: AsyncSession = Depends(get_session)):
    managers = await crud.get_all_active_managers(session)
    return list(managers)


@router.post("", response_model=ManagerOut)
async def create_manager(data: ManagerCreate, session: AsyncSession = Depends(get_session)):
    existing = await crud.get_manager_by_telegram_id(session, data.telegram_id)
    if existing:
        raise HTTPException(400, "Manager with this Telegram ID already exists")
    manager = Manager(**data.model_dump())
    session.add(manager)
    await session.flush()
    return manager


@router.patch("/{manager_id}", response_model=OkResponse)
async def update_manager(
    manager_id: int,
    data: ManagerUpdate,
    session: AsyncSession = Depends(get_session),
):
    from sqlalchemy import select, update
    result = await session.execute(select(Manager).where(Manager.id == manager_id))
    m = result.scalar_one_or_none()
    if not m:
        raise HTTPException(404, "Manager not found")
    update_data = data.model_dump(exclude_none=True)
    if update_data:
        await session.execute(update(Manager).where(Manager.id == manager_id).values(**update_data))
    return OkResponse(message="Manager updated")
