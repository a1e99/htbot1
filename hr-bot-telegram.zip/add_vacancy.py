"""
CLI utility to add a vacancy directly to the database.

Usage:
    python add_vacancy.py
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))


async def main() -> None:
    from app.database.base import init_db, async_session_factory
    from app.database import crud
    from app.database.models import Vacancy

    await init_db()

    print("=" * 45)
    print("  HR Bot — Add Vacancy")
    print("=" * 45)
    print()

    try:
        async with async_session_factory() as session:
            # Show existing professions
            cats = await crud.get_all_profession_categories(session)
            print("Available profession categories:")
            for c in cats:
                print(f"  [{c.id}] {c.name_ru}")
            print()

            cat_id_str = input("Category ID (press Enter to skip): ").strip()
            profession = None
            if cat_id_str.isdigit():
                profs = await crud.get_professions_by_category(session, int(cat_id_str))
                if profs:
                    print("\nProfessions in this category:")
                    for p in profs:
                        print(f"  [{p.id}] {p.name_ru}")
                    prof_id_str = input("Profession ID (press Enter to skip): ").strip()
                    if prof_id_str.isdigit():
                        profession = await crud.get_profession_by_id(session, int(prof_id_str))

            print()
            title = input("Vacancy title: ").strip()
            if not title:
                print("❌ Title cannot be empty.")
                return

            description = input("Description (short): ").strip()
            country     = input("Country: ").strip() or None
            city        = input("City: ").strip() or None
            sal_from    = input("Salary from (EUR/USD, press Enter to skip): ").strip()
            sal_to      = input("Salary to (press Enter to skip): ").strip()

            vacancy = Vacancy(
                title=title,
                description=description or title,
                profession_id=profession.id if profession else None,
                country=country,
                city=city,
                salary_from=float(sal_from) if sal_from else None,
                salary_to=float(sal_to) if sal_to else None,
                currency="EUR",
                employment_type="full-time",
                is_active=True,
            )
            session.add(vacancy)
            await session.commit()
            await session.refresh(vacancy)

        print()
        print("✅ Vacancy created!")
        print(f"   ID: {vacancy.id}")
        print(f"   Title: {vacancy.title}")
        print(f"   Country: {vacancy.country or '—'}")

    except KeyboardInterrupt:
        print("\nCancelled.")


if __name__ == "__main__":
    asyncio.run(main())
