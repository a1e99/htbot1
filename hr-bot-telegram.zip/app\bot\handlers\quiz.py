"""
Quiz FSM - NocoDB version.
Handles text and voice answers, then moves candidate to reminder preference.
"""
from __future__ import annotations

from datetime import datetime, timezone

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import Message
from loguru import logger

from app.bot.states.registration import QuizStates
from app.nocodb.client import noco
from app.services.stt_service import transcribe_voice
from app.services.summary_service import build_summary

router = Router(name="quiz")


async def _process_answer(message: Message, state: FSMContext, answer_text: str) -> None:
    data = await state.get_data()
    candidate_id: int = data["candidate_id"]
    question_ids: list[int] = data.get("quiz_questions", [])
    index: int = data.get("quiz_question_index", 0)
    min_lengths: dict = data.get("quiz_min_lengths", {})
    question_texts: dict = data.get("quiz_question_texts", {})

    if index >= len(question_ids):
        await _finish_quiz(message, state, candidate_id)
        return

    current_q_id = question_ids[index]
    min_len = min_lengths.get(current_q_id, 10)
    if len(answer_text) < min_len:
        await message.answer(
            f"⚠️ Ответ слишком короткий, минимум {min_len} символов.\n"
            "Пожалуйста, дайте более развёрнутый ответ."
        )
        return

    ai_score = None
    ai_comment = None
    try:
        from app.services.openai_service import evaluate_quiz_answer

        q_text = question_texts.get(current_q_id, "")
        ai_score, ai_comment = await evaluate_quiz_answer(
            question=q_text,
            answer=answer_text,
            profession_name=data.get("vacancy_title", ""),
        )
    except Exception as exc:
        logger.debug(f"AI eval skipped: {exc}")

    await noco.save_answer(
        {
            "candidate_id": candidate_id,
            "question_id": current_q_id,
            "question_text": question_texts.get(current_q_id, ""),
            "answer_text": answer_text,
            "ai_score": ai_score,
            "ai_comment": ai_comment or "",
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
    )

    next_index = index + 1
    await state.update_data(quiz_question_index=next_index)

    if next_index >= len(question_ids):
        await _finish_quiz(message, state, candidate_id)
        return

    next_q_id = question_ids[next_index]
    next_q_text = question_texts.get(next_q_id, "")
    await message.answer(
        "✅ Ответ принят.\n\n"
        f"<b>Вопрос {next_index + 1} из {len(question_ids)}:</b>\n\n"
        f"{next_q_text}",
        parse_mode="HTML",
    )


@router.message(QuizStates.ANSWERING, F.text)
async def quiz_text_answer(message: Message, state: FSMContext) -> None:
    await _process_answer(message, state, message.text.strip())


@router.message(QuizStates.ANSWERING, F.voice)
async def quiz_voice_answer(message: Message, state: FSMContext) -> None:
    processing_msg = await message.answer("🎙 Распознаю голосовое сообщение...")
    text = await transcribe_voice(message)
    if not text:
        await processing_msg.delete()
        await message.answer("⚠️ Не удалось распознать голосовое сообщение. Попробуйте ответить текстом.")
        return

    await processing_msg.edit_text(f"🎙 Распознано: <i>{text}</i>", parse_mode="HTML")
    await _process_answer(message, state, text)


async def _finish_quiz(message: Message, state: FSMContext, candidate_id: int) -> None:
    answers = await noco.list_answers(candidate_id)
    candidate = await noco.get_record(
        __import__("app.config", fromlist=["settings"]).settings.noco_table_candidates,
        candidate_id,
    )

    summary_text = ""
    summary_score = 0
    ai_recommendation = "manual_review"
    try:
        summary_text, summary_score, ai_recommendation = await build_summary(candidate, answers)
    except Exception as exc:
        logger.warning(f"Summary build failed: {exc}")

    await noco.update_candidate(
        candidate_id,
        {
            "status": "new",
            "registration_completed_at": datetime.now(timezone.utc).isoformat(),
            "summary_text": summary_text,
            "summary_score": summary_score,
            "ai_recommendation": ai_recommendation,
        },
    )

    try:
        from app.services.notification_service import notify_managers_new_candidate

        await notify_managers_new_candidate(candidate_id, candidate, answers, summary_text, summary_score)
    except Exception as exc:
        logger.error(f"Manager notification failed: {exc}")

    try:
        from app.services.matching_service import find_best_vacancies_for_candidate, save_match

        matches = await find_best_vacancies_for_candidate(candidate, top_n=3, min_score=60)
        for match in matches:
            await save_match(candidate_id, match["vacancy"].get("Id", 0), match["score"], match["reasons"])
        logger.info(f"[Match] Candidate {candidate_id} matched {len(matches)} vacancies")
    except Exception as exc:
        logger.warning(f"[Match] post-quiz matching failed: {exc}")

    from app.bot.handlers.registration import complete_after_quiz

    await complete_after_quiz(message, state, candidate_id)
