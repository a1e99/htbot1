"""
CLI utility to add a manager directly to the database.
Useful for initial setup before the web panel is running.

Usage:
    python add_manager.py
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))


async def main() -> None:
    from app.database.base import init_db, async_session_factory
    from app.database import crud
    from app.database.models import Manager

    await init_db()

    print("=" * 45)
    print("  HR Bot — Add Manager")
    print("=" * 45)
    print()
    print("To find your Telegram ID, send /start to @userinfobot")
    print()

    try:
        tg_id_str = input("Telegram ID (numbers only): ").strip()
        if not tg_id_str.isdigit():
            print("❌ Telegram ID must be numeric.")
            return
        tg_id = int(tg_id_str)

        full_name = input("Full name: ").strip()
        if not full_name:
            print("❌ Name cannot be empty.")
            return

        username  = input("Telegram username (without @, press Enter to skip): ").strip() or None
        phone     = input("Phone (press Enter to skip): ").strip() or None
        email     = input("Email (press Enter to skip): ").strip() or None
        is_admin  = input("Is admin? (y/N): ").strip().lower() == "y"

        async with async_session_factory() as session:
            existing = await crud.get_manager_by_telegram_id(session, tg_id)
            if existing:
                print(f"\n⚠️  Manager with Telegram ID {tg_id} already exists: {existing.full_name}")
                return

            manager = Manager(
                telegram_id=tg_id,
                telegram_username=username,
                full_name=full_name,
                phone=phone,
                email=email,
                is_active=True,
                is_admin=is_admin,
            )
            session.add(manager)
            await session.commit()
            await session.refresh(manager)

        print()
        print("✅ Manager added successfully!")
        print(f"   ID: {manager.id}")
        print(f"   Name: {manager.full_name}")
        print(f"   Telegram ID: {manager.telegram_id}")
        print(f"   Admin: {'Yes' if manager.is_admin else 'No'}")
        print()
        print("Don't forget to add this Telegram ID to MANAGER_CHAT_IDS in .env")

    except KeyboardInterrupt:
        print("\nCancelled.")


if __name__ == "__main__":
    asyncio.run(main())
