"""
Candidate ↔ Vacancy matching service.

Score 0–100 based on:
  - profession/title match
  - skills overlap (from resume_skills vs vacancy requirements)
  - experience years vs required experience
  - location match (if specified)
  - AI holistic scoring

Usage:
    score, reasons = await match_candidate_to_vacancy(candidate, vacancy)
    matches = await find_best_vacancies_for_candidate(candidate, top_n=3)
    matches = await find_best_candidates_for_vacancy(vacancy, top_n=5)
"""
from __future__ import annotations

import json
from typing import Optional
from loguru import logger

from app.nocodb.client import noco
from app.config import settings


# ─────────────────────────────────────────────
# CORE SCORING
# ─────────────────────────────────────────────

async def match_candidate_to_vacancy(
    candidate: dict,
    vacancy: dict,
) -> tuple[int, str]:
    """
    Compute match score (0-100) between a candidate and a vacancy.
    Returns (score, explanation_text).
    """
    prompt = _build_match_prompt(candidate, vacancy)

    try:
        from app.services.openai_service import get_client
        response = await get_client().chat.completions.create(
            model=settings.openai_model,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=300,
            temperature=0.2,
        )
        raw = response.choices[0].message.content.strip()
        raw = raw.replace("```json", "").replace("```", "").strip()
        data = json.loads(raw)
        score = max(0, min(100, int(data.get("score", 0))))
        reasons = data.get("reasons", "")
        return score, reasons
    except Exception as e:
        logger.error(f"[Match] AI scoring failed: {e}")
        # Fallback: keyword overlap scoring
        return _keyword_score(candidate, vacancy), "Базовый анализ по ключевым словам"


def _build_match_prompt(candidate: dict, vacancy: dict) -> str:
    c_name = candidate.get("full_name", "Кандидат")
    c_city = candidate.get("city", "")
    c_exp = candidate.get("experience_years") or candidate.get("experience_details", "")
    c_skills = candidate.get("resume_skills", "")
    c_summary = candidate.get("resume_summary") or candidate.get("summary_text", "")
    c_vacancy_title = candidate.get("vacancy_title", "")

    v_title = vacancy.get("title", "")
    v_desc = vacancy.get("description", "")
    v_req = vacancy.get("requirements", "")
    v_city = vacancy.get("city") or vacancy.get("location", "")
    v_exp_min = vacancy.get("experience_from", "")

    return (
        "Ты — AI рекрутер. Оцени совместимость кандидата с вакансией по шкале 0–100.\n\n"
        f"=== КАНДИДАТ ===\n"
        f"Имя: {c_name}\n"
        f"Желаемая позиция: {c_vacancy_title}\n"
        f"Опыт: {c_exp}\n"
        f"Навыки: {c_skills}\n"
        f"Город: {c_city}\n"
        f"Профиль: {c_summary[:300]}\n\n"
        f"=== ВАКАНСИЯ ===\n"
        f"Должность: {v_title}\n"
        f"Описание: {v_desc[:400]}\n"
        f"Требования: {v_req[:400]}\n"
        f"Город: {v_city}\n"
        f"Опыт от (лет): {v_exp_min}\n\n"
        "Верни JSON без markdown:\n"
        '{"score": 75, "reasons": "Краткое обоснование (1-2 предложения)"}'
    )


def _keyword_score(candidate: dict, vacancy: dict) -> int:
    """Simple keyword overlap fallback scoring."""
    candidate_text = " ".join([
        candidate.get("resume_skills", ""),
        candidate.get("vacancy_title", ""),
        candidate.get("experience_details", ""),
        candidate.get("resume_summary", ""),
    ]).lower()

    vacancy_text = " ".join([
        vacancy.get("title", ""),
        vacancy.get("description", ""),
        vacancy.get("requirements", ""),
    ]).lower()

    if not candidate_text.strip() or not vacancy_text.strip():
        return 30

    vacancy_words = set(w for w in vacancy_text.split() if len(w) > 3)
    if not vacancy_words:
        return 30

    matches = sum(1 for w in vacancy_words if w in candidate_text)
    return min(90, int(30 + (matches / len(vacancy_words)) * 60))


# ─────────────────────────────────────────────
# FIND BEST MATCHES
# ─────────────────────────────────────────────

async def find_best_vacancies_for_candidate(
    candidate: dict,
    top_n: int = 3,
    min_score: int = 50,
) -> list[dict]:
    """
    Find top-N vacancies matching a candidate.
    Returns list of {vacancy, score, reasons}.
    """
    vacancies = await noco.list_vacancies(active_only=True)
    results = []
    for vac in vacancies:
        score, reasons = await match_candidate_to_vacancy(candidate, vac)
        if score >= min_score:
            results.append({"vacancy": vac, "score": score, "reasons": reasons})

    results.sort(key=lambda x: x["score"], reverse=True)
    return results[:top_n]


async def find_best_candidates_for_vacancy(
    vacancy: dict,
    top_n: int = 5,
    min_score: int = 50,
) -> list[dict]:
    """
    Find top-N candidates matching a vacancy.
    Returns list of {candidate, score, reasons}.
    """
    candidates = await noco.list_candidates(limit=200)
    results = []
    for cand in candidates:
        # Only completed registrations
        if not cand.get("registration_completed_at"):
            continue
        score, reasons = await match_candidate_to_vacancy(cand, vacancy)
        if score >= min_score:
            results.append({"candidate": cand, "score": score, "reasons": reasons})

    results.sort(key=lambda x: x["score"], reverse=True)
    return results[:top_n]


# ─────────────────────────────────────────────
# SAVE MATCH TO NOCODB
# ─────────────────────────────────────────────

async def save_match(candidate_id: int, vacancy_id: int, score: int, reasons: str) -> Optional[dict]:
    """Upsert a match record into NocoDB matches table."""
    table = getattr(settings, "noco_table_matches", "")
    if not table:
        logger.debug("[Match] noco_table_matches not configured, skipping save")
        return None
    try:
        existing = await noco.find_one(
            table,
            f"(candidate_id,eq,{candidate_id})~and(vacancy_id,eq,{vacancy_id})",
        )
        data = {
            "candidate_id": candidate_id,
            "vacancy_id": vacancy_id,
            "score": score,
            "reasons": reasons[:500],
        }
        if existing:
            return await noco.update_record(table, existing["Id"], data)
        return await noco.create_record(table, data)
    except Exception as e:
        logger.error(f"[Match] save_match failed: {e}")
        return None
