"""Telegram keyboards — Reply and Inline."""
from __future__ import annotations

from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder

from app.database.models import Manager


# ─────────────────────────────────────────────
# REPLY KEYBOARDS
# ─────────────────────────────────────────────

def kb_start_registration() -> ReplyKeyboardMarkup:
    """Button to start filling the form."""
    builder = ReplyKeyboardBuilder()
    builder.button(text="📝 Начать заполнение анкеты")
    builder.adjust(1)
    return builder.as_markup(resize_keyboard=True, one_time_keyboard=True)


def kb_gender() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.button(text="👨 Мужской")
    builder.button(text="👩 Женский")
    builder.adjust(2)
    return builder.as_markup(resize_keyboard=True, one_time_keyboard=True)


def kb_experience_years() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    for label in ["Нет опыта", "Менее 1 года", "1–2 года", "3–5 лет", "5–10 лет", "Более 10 лет"]:
        builder.button(text=label)
    builder.adjust(2)
    return builder.as_markup(resize_keyboard=True, one_time_keyboard=True)


def kb_skip() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.button(text="⏭ Пропустить")
    builder.adjust(1)
    return builder.as_markup(resize_keyboard=True, one_time_keyboard=True)


def kb_confirm() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.button(text="✅ Подтвердить и отправить")
    builder.button(text="❌ Отменить")
    builder.adjust(1)
    return builder.as_markup(resize_keyboard=True, one_time_keyboard=True)


def kb_status() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.button(text="📊 Статус моей заявки")
    builder.adjust(1)
    return builder.as_markup(resize_keyboard=True)


def remove_keyboard() -> ReplyKeyboardRemove:
    return ReplyKeyboardRemove()


# ─────────────────────────────────────────────
# PROFESSION CATEGORY KEYBOARD
# ─────────────────────────────────────────────

def kb_profession_categories(categories: list) -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    for cat in categories:
        builder.button(text=cat.name_ru)
    builder.adjust(2)
    return builder.as_markup(resize_keyboard=True, one_time_keyboard=True)


def kb_professions(professions: list) -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    for prof in professions:
        builder.button(text=prof.name_ru)
    builder.button(text="⬅️ Назад")
    builder.adjust(2)
    return builder.as_markup(resize_keyboard=True, one_time_keyboard=True)


# ─────────────────────────────────────────────
# INLINE KEYBOARDS (for managers)
# ─────────────────────────────────────────────

def kb_manager_decision(candidate_id: int) -> InlineKeyboardMarkup:
    """Inline keyboard sent to manager with candidate summary."""
    builder = InlineKeyboardBuilder()
    builder.button(
        text="✅ Принять",
        callback_data=f"decision:approve:{candidate_id}",
    )
    builder.button(
        text="❌ Отклонить",
        callback_data=f"decision:reject:{candidate_id}",
    )
    builder.button(
        text="❓ Запросить уточнение",
        callback_data=f"decision:clarify:{candidate_id}",
    )
    builder.button(
        text="➡️ Передать другому",
        callback_data=f"decision:transfer:{candidate_id}",
    )
    builder.adjust(2, 2)
    return builder.as_markup()


def kb_transfer_managers(managers: list[Manager], candidate_id: int) -> InlineKeyboardMarkup:
    """List of managers to transfer candidate to."""
    builder = InlineKeyboardBuilder()
    for manager in managers:
        builder.button(
            text=f"👤 {manager.full_name}",
            callback_data=f"transfer:{candidate_id}:{manager.id}",
        )
    builder.button(text="⬅️ Назад", callback_data=f"decision:back:{candidate_id}")
    builder.adjust(1)
    return builder.as_markup()


def kb_confirm_decision(decision: str, candidate_id: int) -> InlineKeyboardMarkup:
    """Confirm/cancel a manager decision."""
    builder = InlineKeyboardBuilder()
    builder.button(
        text="✅ Подтвердить",
        callback_data=f"confirm:{decision}:{candidate_id}",
    )
    builder.button(
        text="⬅️ Отмена",
        callback_data=f"decision:back:{candidate_id}",
    )
    builder.adjust(2)
    return builder.as_markup()
