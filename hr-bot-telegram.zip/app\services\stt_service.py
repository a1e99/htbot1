"""
Speech-to-text service using OpenAI Whisper API.
Handles voice messages from Telegram.
"""
from __future__ import annotations

import io
import tempfile
import os
from pathlib import Path
from typing import Optional
from loguru import logger

from aiogram.types import Message
from app.config import settings


async def transcribe_voice(message: Message) -> Optional[str]:
    """
    Download voice message from Telegram and transcribe with Whisper.
    Returns transcribed text or None on failure.
    """
    if not settings.openai_api_key:
        logger.warning("STT: OpenAI API key not set")
        return None

    try:
        from openai import AsyncOpenAI
        client = AsyncOpenAI(api_key=settings.openai_api_key)

        # Get bot from message
        bot = message.bot
        voice = message.voice

        # Download file
        file = await bot.get_file(voice.file_id)
        voice_bytes = await bot.download_file(file.file_path)

        # Write to temp file (Whisper API needs a named file)
        with tempfile.NamedTemporaryFile(suffix=".ogg", delete=False) as tmp:
            tmp.write(voice_bytes.read())
            tmp_path = tmp.name

        try:
            with open(tmp_path, "rb") as audio_file:
                transcript = await client.audio.transcriptions.create(
                    model="whisper-1",
                    file=audio_file,
                    language="ru",
                    response_format="text",
                )
            text = transcript.strip() if isinstance(transcript, str) else transcript.text.strip()
            logger.info(f"STT: transcribed {voice.duration}s voice -> {len(text)} chars")
            return text
        finally:
            os.unlink(tmp_path)

    except Exception as e:
        logger.error(f"STT transcription failed: {e}")
        return None
