"""
Summary service - builds candidate profile from quiz answers using GPT.
Returns: (summary_text, score_0_100, recommendation)
"""
from __future__ import annotations

import json

from loguru import logger

from app.config import settings
from app.services.salary_expectation_service import format_salary_expectation


SUMMARY_PROMPT = """
Ты HR-аналитик. Оцени кандидата на основе анкеты и ответов на тест.

Данные кандидата:
{candidate_info}

Ответы на тест:
{answers_text}

Задача:
1. Напиши краткое резюме кандидата (3-5 предложений) на русском языке
2. Выстави итоговый балл от 0 до 100
3. Дай рекомендацию: "hire", "maybe" или "reject"

Ответь строго в формате JSON:
{{
  "summary": "текст резюме",
  "score": 75,
  "recommendation": "hire"
}}
"""


def _candidate_info(candidate: dict) -> str:
    desired_salary = candidate.get("desired_salary_text") or format_salary_expectation(
        candidate.get("desired_salary_amount"),
        candidate.get("desired_salary_currency"),
        candidate.get("desired_salary_period"),
    )
    relocation = candidate.get("relocation_preference", "")
    relocation_locations = candidate.get("relocation_locations", "")
    if relocation == "none":
        relocation = "не готов(а)"
    elif relocation == "any":
        relocation = "готов(а) в любой город"
    elif relocation == "specific":
        relocation = f"готов(а): {relocation_locations or 'уточнить'}"

    return (
        f"Имя: {candidate.get('full_name', 'Не указано')}\n"
        f"Телефон: {candidate.get('phone', 'Не указан')}\n"
        f"Email: {candidate.get('email', 'Не указан')}\n"
        f"Город: {candidate.get('current_city') or candidate.get('city', 'Не указан')}\n"
        f"Возраст: {candidate.get('age', 'Не указан')}\n"
        f"Вакансия: {candidate.get('vacancy_title', 'Не указана')}\n"
        f"Релокация: {relocation or 'не указана'}\n"
        f"Желаемая ставка: {desired_salary or 'не указана'}\n"
        f"Предупреждение по ставке: {candidate.get('desired_salary_warning', 'нет')}"
    )


async def build_summary(candidate: dict, answers: list[dict]) -> tuple[str, int, str]:
    if not settings.openai_api_key:
        return _fallback_summary(candidate, answers)

    try:
        from openai import AsyncOpenAI

        client = AsyncOpenAI(api_key=settings.openai_api_key)
        answers_text = "\n".join(
            [
                f"Q: {answer.get('question_text', '')}\nA: {answer.get('answer_text', '')}"
                + (f"\n[AI score: {answer['ai_score']}/10]" if answer.get("ai_score") else "")
                for answer in answers
            ]
        )

        response = await client.chat.completions.create(
            model=settings.openai_model,
            messages=[
                {
                    "role": "user",
                    "content": SUMMARY_PROMPT.format(
                        candidate_info=_candidate_info(candidate),
                        answers_text=answers_text or "Ответов нет",
                    ),
                }
            ],
            temperature=0.3,
            max_tokens=600,
            response_format={"type": "json_object"},
        )

        data = json.loads(response.choices[0].message.content)
        summary = data.get("summary", "")
        score = max(0, min(100, int(data.get("score", 50))))
        recommendation = data.get("recommendation", "maybe")
        if recommendation not in {"hire", "maybe", "reject"}:
            recommendation = "maybe"

        logger.info(f"Summary built: score={score} rec={recommendation}")
        return summary, score, recommendation
    except Exception as exc:
        logger.error(f"Summary generation failed: {exc}")
        return _fallback_summary(candidate, answers)


def _fallback_summary(candidate: dict, answers: list[dict]) -> tuple[str, int, str]:
    name = candidate.get("full_name", "Кандидат")
    vacancy = candidate.get("vacancy_title", "вакансия")
    city = candidate.get("current_city") or candidate.get("city", "")
    age = candidate.get("age", "")
    desired_salary = candidate.get("desired_salary_text") or format_salary_expectation(
        candidate.get("desired_salary_amount"),
        candidate.get("desired_salary_currency"),
        candidate.get("desired_salary_period"),
    )

    summary = (
        f"{name} подал(а) заявку на вакансию «{vacancy}»"
        + (f", город: {city}" if city else "")
        + (f", возраст: {age}" if age else "")
        + (f", ставка: {desired_salary}" if desired_salary else "")
        + f". Ответил(а) на {len(answers)} вопросов теста."
        + " Требуется ручная проверка менеджером."
    )
    return summary, 50, "maybe"


def format_summary_for_telegram(candidate: dict, answers: list[dict], summary_text: str, score: int) -> str:
    name = candidate.get("full_name", "Неизвестно")
    phone = candidate.get("phone", "Не указан")
    email = candidate.get("email", "")
    city = candidate.get("current_city") or candidate.get("city", "Не указан")
    age = candidate.get("age", "")
    vacancy = candidate.get("vacancy_title", "Не указана")
    username = candidate.get("username", "")
    raw_candidate_id = candidate.get("Id")
    try:
        candidate_id = int(raw_candidate_id)
    except (TypeError, ValueError):
        candidate_id = 0
    desired_salary = candidate.get("desired_salary_text") or format_salary_expectation(
        candidate.get("desired_salary_amount"),
        candidate.get("desired_salary_currency"),
        candidate.get("desired_salary_period"),
    )
    relocation = candidate.get("relocation_preference", "")
    relocation_locations = candidate.get("relocation_locations", "")
    salary_warning = candidate.get("desired_salary_warning", "")

    if relocation == "none":
        relocation_text = "не готов(а)"
    elif relocation == "any":
        relocation_text = "готов(а) в любой город"
    elif relocation == "specific":
        relocation_text = f"готов(а): {relocation_locations or 'уточнить'}"
    else:
        relocation_text = ""

    score_emoji = "🟢" if score >= 70 else "🟡" if score >= 40 else "🔴"
    lines = [
        f"👤 <b>Новый кандидат #{candidate_id:06d}</b>" if candidate_id else "👤 <b>Новый кандидат</b>",
        "",
        f"📋 <b>Вакансия:</b> {vacancy}",
        f"👤 <b>Имя:</b> {name}",
        f"📞 <b>Телефон:</b> {phone}",
        f"🏙 <b>Город:</b> {city}",
    ]
    if age:
        lines.append(f"🎂 <b>Возраст:</b> {age}")
    if email:
        lines.append(f"📧 <b>Email:</b> {email}")
    if username:
        lines.append(f"💬 <b>Telegram:</b> @{username}")
    if relocation_text:
        lines.append(f"🚚 <b>Релокация:</b> {relocation_text}")
    if desired_salary:
        lines.append(f"💶 <b>Желаемая ставка:</b> {desired_salary}")
    if salary_warning:
        lines.append(f"⚠️ <b>Предупреждение:</b> {salary_warning}")

    lines.extend(
        [
            "",
            f"{score_emoji} <b>AI оценка:</b> {score}/100",
            "",
            "📝 <b>Резюме:</b>",
            summary_text or "Требуется ручная проверка.",
        ]
    )

    if answers:
        lines.append(f"\n<b>Ответы на тест ({len(answers)}):</b>")
        for idx, answer in enumerate(answers[:3], start=1):
            question = answer.get("question_text", "")[:60]
            reply = answer.get("answer_text", "")[:100]
            lines.append(f"\n{idx}. <i>{question}</i>\n→ {reply}")
        if len(answers) > 3:
            lines.append(f"\n... и ещё {len(answers) - 3} ответов")

    return "\n".join(lines)
