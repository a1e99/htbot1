"""
Seed initial data: profession categories, professions, quiz questions,
forbidden words and a default agency.
Run once after DB creation.
"""
from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.database.models import (
    Agency,
    ForbiddenWord,
    ForbiddenWordCategory,
    Profession,
    ProfessionCategory,
    QuizQuestion,
    QuestionType,
)
from loguru import logger


# ─────────────────────────────────────────────
# PROFESSION CATEGORIES
# ─────────────────────────────────────────────

PROFESSION_CATEGORIES = [
    {"name": "construction", "name_ru": "🏗️ Строительство", "icon": "🏗️", "sort_order": 1},
    {"name": "welding", "name_ru": "🔥 Сварка", "icon": "🔥", "sort_order": 2},
    {"name": "electrical", "name_ru": "⚡ Электрика", "icon": "⚡", "sort_order": 3},
    {"name": "manufacturing", "name_ru": "🏭 Производство", "icon": "🏭", "sort_order": 4},
    {"name": "warehouse", "name_ru": "📦 Склад и логистика", "icon": "📦", "sort_order": 5},
    {"name": "transport", "name_ru": "🚛 Транспорт", "icon": "🚛", "sort_order": 6},
    {"name": "agriculture", "name_ru": "🌾 Сельское хозяйство", "icon": "🌾", "sort_order": 7},
    {"name": "cleaning", "name_ru": "🧹 Клининг", "icon": "🧹", "sort_order": 8},
    {"name": "installation", "name_ru": "🔧 Монтаж и установка", "icon": "🔧", "sort_order": 9},
    {"name": "operators", "name_ru": "⚙️ Операторы оборудования", "icon": "⚙️", "sort_order": 10},
    {"name": "it", "name_ru": "💻 IT и технологии", "icon": "💻", "sort_order": 11},
]


# ─────────────────────────────────────────────
# PROFESSIONS PER CATEGORY
# ─────────────────────────────────────────────

PROFESSIONS: dict[str, list[dict]] = {
    "construction": [
        {
            "name": "bricklayer", "name_ru": "Каменщик",
            "skills": ["кладка кирпича", "работа с раствором", "чтение чертежей"],
            "requirements": ["опыт от 1 года", "физическая выносливость"],
            "risks": ["работа на высоте", "физические нагрузки"],
        },
        {
            "name": "concrete_worker", "name_ru": "Бетонщик",
            "skills": ["заливка бетона", "опалубка", "армирование"],
            "requirements": ["знание технологий бетонных работ"],
            "risks": ["тяжёлый физический труд"],
        },
        {
            "name": "plasterer", "name_ru": "Штукатур",
            "skills": ["штукатурка стен", "шпаклёвка", "выравнивание"],
            "requirements": ["аккуратность", "опыт от 6 месяцев"],
            "risks": ["контакт с химическими смесями"],
        },
        {
            "name": "painter", "name_ru": "Маляр",
            "skills": ["покраска поверхностей", "работа с краскопультом", "подготовка поверхностей"],
            "requirements": ["знание типов красок", "аккуратность"],
            "risks": ["пары химикатов", "работа на высоте"],
        },
        {
            "name": "carpenter", "name_ru": "Плотник",
            "skills": ["работа с деревом", "установка конструкций", "чтение чертежей"],
            "requirements": ["опыт от 1 года"],
            "risks": ["работа с острыми инструментами"],
        },
    ],
    "welding": [
        {
            "name": "mig_welder", "name_ru": "Сварщик MIG/MAG",
            "skills": ["полуавтоматическая сварка", "MIG/MAG", "контроль качества швов"],
            "requirements": ["удостоверение сварщика", "опыт от 2 лет"],
            "risks": ["ожоги", "вредные испарения", "работа с током"],
        },
        {
            "name": "tig_welder", "name_ru": "Сварщик TIG",
            "skills": ["аргонодуговая сварка", "TIG", "работа с нержавейкой и алюминием"],
            "requirements": ["высокая квалификация", "опыт от 3 лет"],
            "risks": ["ультрафиолетовое излучение", "вредные газы"],
        },
        {
            "name": "electrode_welder", "name_ru": "Сварщик РДС (электрод)",
            "skills": ["ручная дуговая сварка", "электроды", "разные позиции"],
            "requirements": ["базовое удостоверение", "опыт от 1 года"],
            "risks": ["ожоги", "поражение током"],
        },
    ],
    "electrical": [
        {
            "name": "electrician", "name_ru": "Электрик",
            "skills": ["монтаж электропроводки", "схемы", "ПУЭ"],
            "requirements": ["допуск по электробезопасности", "опыт от 2 лет"],
            "risks": ["поражение электрическим током", "работа на высоте"],
        },
        {
            "name": "electrician_industrial", "name_ru": "Электрик промышленный",
            "skills": ["обслуживание промышленного оборудования", "частотные преобразователи"],
            "requirements": ["3-4 группа по электробезопасности"],
            "risks": ["высокое напряжение", "аварийные ситуации"],
        },
    ],
    "manufacturing": [
        {
            "name": "assembler", "name_ru": "Сборщик",
            "skills": ["ручная сборка деталей", "контроль качества", "работа с инструментом"],
            "requirements": ["внимательность", "мелкая моторика"],
            "risks": ["монотонность", "производственный шум"],
        },
        {
            "name": "cnc_operator", "name_ru": "Оператор ЧПУ",
            "skills": ["управление станком ЧПУ", "G-код", "замеры"],
            "requirements": ["знание ЧПУ", "опыт от 1 года"],
            "risks": ["стружка металла", "режущие инструменты"],
        },
        {
            "name": "quality_control", "name_ru": "Контролёр качества",
            "skills": ["измерительные инструменты", "документация", "стандарты ISO"],
            "requirements": ["внимательность", "знание стандартов"],
            "risks": ["профессиональная ответственность"],
        },
    ],
    "warehouse": [
        {
            "name": "warehouse_worker", "name_ru": "Работник склада",
            "skills": ["приёмка/отгрузка товаров", "инвентаризация", "работа со сканером"],
            "requirements": ["физическая выносливость"],
            "risks": ["физические нагрузки", "работа со штабелёром"],
        },
        {
            "name": "forklift_operator", "name_ru": "Оператор вилочного погрузчика",
            "skills": ["управление погрузчиком", "работа на складе", "ТБ"],
            "requirements": ["права на погрузчик", "опыт от 1 года"],
            "risks": ["несчастные случаи при погрузке"],
        },
        {
            "name": "picker", "name_ru": "Комплектовщик",
            "skills": ["комплектация заказов", "работа с терминалом", "скорость"],
            "requirements": ["внимательность", "физическая форма"],
            "risks": ["нагрузка на ноги"],
        },
    ],
    "transport": [
        {
            "name": "truck_driver", "name_ru": "Водитель грузовика",
            "skills": ["управление грузовиком", "тахограф", "международные перевозки"],
            "requirements": ["права C/CE", "карта водителя", "опыт от 2 лет"],
            "risks": ["усталость при дальних рейсах", "ДТП"],
        },
        {
            "name": "bus_driver", "name_ru": "Водитель автобуса",
            "skills": ["управление автобусом", "пассажиры", "маршруты"],
            "requirements": ["права D", "медицинская справка"],
            "risks": ["ответственность за пассажиров"],
        },
    ],
    "agriculture": [
        {
            "name": "agricultural_worker", "name_ru": "Работник сельского хозяйства",
            "skills": ["ручной сбор урожая", "теплицы", "сортировка"],
            "requirements": ["физическая выносливость", "готовность к сезонной работе"],
            "risks": ["сезонность", "физические нагрузки"],
        },
        {
            "name": "tractor_driver", "name_ru": "Тракторист",
            "skills": ["управление трактором", "сельхозтехника", "обслуживание"],
            "requirements": ["права тракториста", "опыт"],
            "risks": ["работа в поле", "травмоопасность"],
        },
    ],
    "cleaning": [
        {
            "name": "cleaner", "name_ru": "Уборщик/Клинер",
            "skills": ["уборка помещений", "профессиональная химия", "оборудование"],
            "requirements": ["аккуратность", "ответственность"],
            "risks": ["химические средства", "скользкие поверхности"],
        },
        {
            "name": "industrial_cleaner", "name_ru": "Промышленный клинер",
            "skills": ["промышленная уборка", "работа на высоте", "специальные смеси"],
            "requirements": ["допуск к работе на высоте"],
            "risks": ["высота", "агрессивные химикаты"],
        },
    ],
    "installation": [
        {
            "name": "hvac_technician", "name_ru": "Монтажник HVAC",
            "skills": ["монтаж вентиляции", "кондиционирование", "трубопроводы"],
            "requirements": ["опыт от 1 года", "чтение схем"],
            "risks": ["работа на высоте", "давление в системах"],
        },
        {
            "name": "pipeline_installer", "name_ru": "Монтажник трубопроводов",
            "skills": ["монтаж труб", "сварка труб", "опрессовка"],
            "requirements": ["опыт в сантехнике или промышленных трубопроводах"],
            "risks": ["давление в трубах", "горячие поверхности"],
        },
    ],
    "operators": [
        {
            "name": "machine_operator", "name_ru": "Оператор производственной линии",
            "skills": ["управление линией", "наблюдение за процессом", "мелкий ремонт"],
            "requirements": ["техническое образование или опыт"],
            "risks": ["монотонность", "производственный травматизм"],
        },
        {
            "name": "crane_operator", "name_ru": "Крановщик",
            "skills": ["управление краном", "стропальные работы", "ТБ"],
            "requirements": ["удостоверение крановщика"],
            "risks": ["падение грузов", "высота"],
        },
    ],
    "it": [
        {
            "name": "python_developer", "name_ru": "Python разработчик",
            "skills": ["Python", "FastAPI/Django", "SQL", "Git"],
            "requirements": ["опыт от 1 года", "знание алгоритмов"],
            "risks": ["удалённая работа", "переработки"],
        },
        {
            "name": "system_admin", "name_ru": "Системный администратор",
            "skills": ["Linux", "сети", "администрирование серверов", "Docker"],
            "requirements": ["опыт от 2 лет", "сертификаты приветствуются"],
            "risks": ["ночные дежурства", "аварии"],
        },
    ],
}


# ─────────────────────────────────────────────
# QUIZ QUESTIONS PER PROFESSION
# ─────────────────────────────────────────────

QUIZ_QUESTIONS: dict[str, list[dict]] = {
    "mig_welder": [
        {
            "question_text": "Какие типы металлов вы варили с помощью MIG/MAG сварки?",
            "min_answer_length": 15,
            "sort_order": 1,
        },
        {
            "question_text": "Опишите ваш опыт настройки параметров сварочного аппарата (ток, напряжение, скорость подачи проволоки).",
            "min_answer_length": 20,
            "sort_order": 2,
        },
        {
            "question_text": "Как вы контролируете качество сварного шва? Какие дефекты вы умеете определять?",
            "min_answer_length": 20,
            "sort_order": 3,
        },
        {
            "question_text": "Расскажите о вашем опыте работы в различных пространственных положениях (нижнее, вертикальное, потолочное).",
            "min_answer_length": 15,
            "sort_order": 4,
        },
        {
            "question_text": "Какие средства индивидуальной защиты вы используете при сварке?",
            "min_answer_length": 10,
            "sort_order": 5,
        },
    ],
    "electrician": [
        {
            "question_text": "Какая у вас группа допуска по электробезопасности?",
            "min_answer_length": 5,
            "sort_order": 1,
        },
        {
            "question_text": "Опишите ваш опыт монтажа электропроводки в жилых или промышленных объектах.",
            "min_answer_length": 20,
            "sort_order": 2,
        },
        {
            "question_text": "Умеете ли вы читать электрические схемы? Приведите пример задачи, которую вы решали по схеме.",
            "min_answer_length": 20,
            "sort_order": 3,
        },
        {
            "question_text": "Расскажите о требованиях техники безопасности при работе с электроустановками.",
            "min_answer_length": 20,
            "sort_order": 4,
        },
    ],
    "truck_driver": [
        {
            "question_text": "Какие категории водительских прав у вас есть? (C, CE и др.)",
            "min_answer_length": 5,
            "sort_order": 1,
        },
        {
            "question_text": "Есть ли у вас карта водителя для тахографа? Расскажите о вашем опыте работы с тахографом.",
            "min_answer_length": 10,
            "sort_order": 2,
        },
        {
            "question_text": "Какой опыт международных перевозок у вас есть? Какие страны?",
            "min_answer_length": 10,
            "sort_order": 3,
        },
        {
            "question_text": "Опишите ситуацию, когда вам пришлось решить проблему в дороге (поломка, таможня, и т.д.).",
            "min_answer_length": 20,
            "sort_order": 4,
        },
    ],
    "warehouse_worker": [
        {
            "question_text": "Расскажите о вашем опыте работы на складе. Что именно вы делали?",
            "min_answer_length": 15,
            "sort_order": 1,
        },
        {
            "question_text": "Умеете ли вы работать со складскими программами или терминалами сбора данных?",
            "min_answer_length": 10,
            "sort_order": 2,
        },
        {
            "question_text": "Какой максимальный вес вы поднимали в рамках рабочих обязанностей?",
            "min_answer_length": 5,
            "sort_order": 3,
        },
    ],
    "default": [
        {
            "question_text": "Опишите ваш опыт работы по данной специальности. Сколько лет и где работали?",
            "min_answer_length": 20,
            "sort_order": 1,
        },
        {
            "question_text": "Какие инструменты, оборудование или технологии вы используете в работе?",
            "min_answer_length": 15,
            "sort_order": 2,
        },
        {
            "question_text": "Расскажите о самой сложной задаче, которую вам приходилось решать на работе.",
            "min_answer_length": 20,
            "sort_order": 3,
        },
        {
            "question_text": "Почему вы хотите работать за рубежом? К каким условиям жизни и работы вы готовы?",
            "min_answer_length": 20,
            "sort_order": 4,
        },
        {
            "question_text": "Знаете ли вы иностранные языки? Какой уровень?",
            "min_answer_length": 5,
            "sort_order": 5,
        },
    ],
}


# ─────────────────────────────────────────────
# FORBIDDEN WORDS
# ─────────────────────────────────────────────

FORBIDDEN_WORDS = [
    # Spam
    ("spam", ForbiddenWordCategory.SPAM),
    ("casino", ForbiddenWordCategory.SPAM),
    ("криптовалюта", ForbiddenWordCategory.SPAM),
    ("заработок", ForbiddenWordCategory.SPAM),
    ("млм", ForbiddenWordCategory.SPAM),
    ("пирамида", ForbiddenWordCategory.SPAM),
    ("бесплатно", ForbiddenWordCategory.SPAM),
    # Offensive
    ("мат1", ForbiddenWordCategory.OFFENSIVE),
    ("мат2", ForbiddenWordCategory.OFFENSIVE),
    # Irrelevant non-answers
    ("не знаю", ForbiddenWordCategory.IRRELEVANT),
    ("хз", ForbiddenWordCategory.IRRELEVANT),
    ("ничего", ForbiddenWordCategory.IRRELEVANT),
    ("нет ответа", ForbiddenWordCategory.IRRELEVANT),
    ("аааа", ForbiddenWordCategory.IRRELEVANT),
    ("qqq", ForbiddenWordCategory.IRRELEVANT),
    ("asdf", ForbiddenWordCategory.IRRELEVANT),
    ("test", ForbiddenWordCategory.IRRELEVANT),
    ("тест", ForbiddenWordCategory.IRRELEVANT),
]


# ─────────────────────────────────────────────
# SEED FUNCTION
# ─────────────────────────────────────────────

async def seed_database(session: AsyncSession) -> None:
    """Populate the database with initial data."""
    logger.info("Starting database seeding...")

    # 1. Default Agency
    existing_agency = await session.execute(
        select(Agency).where(Agency.slug == "default")
    )
    if not existing_agency.scalar_one_or_none():
        agency = Agency(name="HR Agency", slug="default", is_active=True)
        session.add(agency)
        await session.flush()
        logger.info("Created default agency")

    # 2. Profession Categories
    cat_map: dict[str, ProfessionCategory] = {}
    for cat_data in PROFESSION_CATEGORIES:
        existing = await session.execute(
            select(ProfessionCategory).where(
                ProfessionCategory.name == cat_data["name"]
            )
        )
        cat = existing.scalar_one_or_none()
        if not cat:
            cat = ProfessionCategory(**cat_data)
            session.add(cat)
            await session.flush()
        cat_map[cat_data["name"]] = cat

    logger.info(f"Seeded {len(cat_map)} profession categories")

    # 3. Professions
    prof_map: dict[str, Profession] = {}
    total_professions = 0
    for cat_name, professions in PROFESSIONS.items():
        cat = cat_map.get(cat_name)
        if not cat:
            continue
        for prof_data in professions:
            existing = await session.execute(
                select(Profession).where(Profession.name == prof_data["name"])
            )
            prof = existing.scalar_one_or_none()
            if not prof:
                prof = Profession(
                    category_id=cat.id,
                    name=prof_data["name"],
                    name_ru=prof_data["name_ru"],
                    skills=prof_data.get("skills", []),
                    requirements=prof_data.get("requirements", []),
                    risks=prof_data.get("risks", []),
                    is_active=True,
                )
                session.add(prof)
                await session.flush()
                total_professions += 1
            prof_map[prof_data["name"]] = prof

    logger.info(f"Seeded {total_professions} professions")

    # 4. Quiz Questions
    total_questions = 0
    for prof_name, questions in QUIZ_QUESTIONS.items():
        if prof_name == "default":
            # Assign default questions to professions without specific questions
            for prof in prof_map.values():
                existing = await session.execute(
                    select(QuizQuestion).where(QuizQuestion.profession_id == prof.id)
                )
                if not existing.scalars().first():
                    for q_data in questions:
                        q = QuizQuestion(
                            profession_id=prof.id,
                            question_text=q_data["question_text"],
                            question_type=QuestionType.OPEN,
                            min_answer_length=q_data.get("min_answer_length", 10),
                            sort_order=q_data.get("sort_order", 0),
                            is_required=True,
                            ai_evaluate=True,
                        )
                        session.add(q)
                        total_questions += 1
            continue

        prof = prof_map.get(prof_name)
        if not prof:
            continue
        existing = await session.execute(
            select(QuizQuestion).where(QuizQuestion.profession_id == prof.id)
        )
        if existing.scalars().first():
            continue
        for q_data in questions:
            q = QuizQuestion(
                profession_id=prof.id,
                question_text=q_data["question_text"],
                question_type=QuestionType.OPEN,
                min_answer_length=q_data.get("min_answer_length", 10),
                sort_order=q_data.get("sort_order", 0),
                is_required=True,
                ai_evaluate=True,
            )
            session.add(q)
            total_questions += 1

    await session.flush()
    logger.info(f"Seeded {total_questions} quiz questions")

    # 5. Forbidden Words
    total_words = 0
    for word, category in FORBIDDEN_WORDS:
        existing = await session.execute(
            select(ForbiddenWord).where(ForbiddenWord.word == word.lower())
        )
        if not existing.scalar_one_or_none():
            fw = ForbiddenWord(word=word.lower(), category=category, is_active=True)
            session.add(fw)
            total_words += 1

    await session.flush()
    logger.info(f"Seeded {total_words} forbidden words")

    await session.commit()
    logger.info("✅ Database seeding completed successfully")
