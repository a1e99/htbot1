# HR Bot System v6

Telegram HR-бот с интеграцией NocoDB как визуальной базы данных.

## Стек

- **aiogram 3.x** — Telegram бот
- **FastAPI + Jinja2** — Веб-панель
- **NocoDB** — Визуальная БД (Docker)
- **ChromaDB** — RAG векторная база
- **OpenAI GPT-4o** — Анализ кандидатов, AI Summary
- **OpenAI Whisper** — Speech-to-text
- **PySide6** — Windows tray

## Быстрый старт

### 1. Установка зависимостей
```
install.bat
```

### 2. Запуск NocoDB
```
docker compose up -d
```
Открыть http://localhost:8080, создать аккаунт.

### 3. Настройка таблиц
```
python setup_nocodb.py
```
Скрипт создаст все таблицы и выведет ID для `.env`.

### 4. Заполнить `.env`
Вставить ID таблиц из `nocodb_table_ids.txt`.

### 5. Проверка
```
python healthcheck.py
```

### 6. Запуск
```
start.bat → [1] Запустить всё
```

## Команды бота (для менеджеров)

| Команда | Описание |
|---------|----------|
| `/candidates` | Статистика кандидатов |
| `/publish_vacancy` | Опубликовать вакансию в TG каналы |
| `/add_channel` | Добавить канал для публикации |
| `/list_channels` | Список каналов |
| `/newgroup` | Создать группу |

## Функционал

- ✅ Выбор вакансии при регистрации
- ✅ Голосовые сообщения (Whisper STT)
- ✅ AI Summary кандидата (GPT-4o)
- ✅ Публикация вакансий в Telegram каналы
- ✅ Рассылка карточек партнёрам
- ✅ RAG библиотека знаний (PDF/DOCX/URL/текст)
- ✅ NocoDB — визуальный CRUD всех данных
- ✅ Tray-приложение Windows
