"""Bot instance holder (set at startup)."""
from aiogram import Bot
bot: Bot = None
