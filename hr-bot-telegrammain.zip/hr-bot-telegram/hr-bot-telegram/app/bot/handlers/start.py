"""
/start handler.
Flow:
  1. Check channel subscription (if REQUIRED_CHANNEL_ID configured)
  2. Check existing candidate / blocked status
  3. Show vacancy list or auto-select via deep-link
  4. Begin registration FSM

Deep-links: /start vacancy_42 → auto-select vacancy #42
"""
from __future__ import annotations

from aiogram import Router, F
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import (
    Message, CallbackQuery,
    InlineKeyboardMarkup, InlineKeyboardButton,
)
from loguru import logger

from app.config import settings
from app.nocodb.client import noco
from app.bot.states.registration import RegistrationStates, SubscriptionStates

router = Router(name="start")

WARNING_TEXT = """
⚠️ <b>ВАЖНО! Прочитайте перед началом</b>

Данная анкета заполняется <b>только один раз</b>.

📋 Убедитесь в следующем:
• Информация должна быть <b>корректной и актуальной</b>
• После отправки <b>изменить данные нельзя</b>
• Повторная подача <b>невозможна</b>

✅ Выберите вакансию ниже и начните заполнение.
"""

STATUS_MAP = {
    "new":                  "🆕 Анкета получена, ожидает обработки.",
    "in_review":            "🔍 Ваша анкета рассматривается менеджером.",
    "approved":             "✅ Поздравляем! Ваша кандидатура одобрена.",
    "rejected":             "❌ К сожалению, ваша кандидатура не прошла отбор.",
    "clarification_needed": "❓ Менеджер запросил уточнение. Ожидайте сообщения.",
    "blocked":              "🚫 Ваш аккаунт заблокирован.",
}


# ─────────────────────────────────────────────
# SUBSCRIPTION GATE
# ─────────────────────────────────────────────

def _channel_url(channel_id: str) -> str | None:
    """Return invite URL for @username channel, None for numeric IDs."""
    s = str(channel_id).strip()
    if s.startswith("@"):
        return f"https://t.me/{s.lstrip('@')}"
    return None


async def _is_subscribed(bot, user_id: int) -> bool:
    """Return True only if user is subscribed to ALL required channels."""
    channels = settings.required_channel_ids
    if not channels:
        return True
    for channel in channels:
        try:
            member = await bot.get_chat_member(channel, user_id)
            if member.status in ("left", "kicked", "banned"):
                return False
        except Exception as e:
            logger.warning(f"[Sub] check failed for {user_id} in {channel}: {e}")
            # Can't verify (bot not admin) → don't block
    return True


async def _send_subscription_gate(message: Message, state: FSMContext) -> None:
    """Show 'please subscribe' screen with buttons for all required channels."""
    await state.set_state(SubscriptionStates.WAITING)

    channels = settings.required_channel_ids
    titles = settings.required_channel_titles

    buttons = []
    for i, channel_id in enumerate(channels):
        title = titles[i] if i < len(titles) else channel_id
        url = _channel_url(channel_id)
        if url:
            buttons.append([InlineKeyboardButton(text=f"📢 {title}", url=url)])

    buttons.append([InlineKeyboardButton(text="✅ Я подписался на все каналы", callback_data="check_sub")])

    channel_list = "\n".join(
        f"• <b>{titles[i] if i < len(titles) else ch}</b>"
        for i, ch in enumerate(channels)
    )

    await message.answer(
        f"👋 Привет, <b>{message.from_user.full_name}</b>!\n\n"
        f"Для использования бота необходимо подписаться на наши каналы:\n\n"
        f"{channel_list}\n\n"
        "После подписки нажмите кнопку ниже 👇",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
    )


@router.callback_query(F.data == "check_sub", SubscriptionStates.WAITING)
async def check_subscription_callback(callback: CallbackQuery, state: FSMContext) -> None:
    """User clicked 'I subscribed' — re-check and proceed or remind."""
    subscribed = await _is_subscribed(callback.bot, callback.from_user.id)
    if not subscribed:
        await callback.answer(
            "❌ Вы ещё не подписались на все каналы. Подпишитесь и попробуйте снова.",
            show_alert=True,
        )
        return

    await callback.message.edit_reply_markup()
    await callback.answer("✅ Подписка подтверждена!")

    # Restore pending deep-link vacancy if any
    data = await state.get_data()
    pending_vacancy_id = data.get("pending_vacancy_id")
    await state.clear()

    # Re-run start flow
    await _run_start(callback.message, state, callback.from_user, pending_vacancy_id)


# ─────────────────────────────────────────────
# DEEP-LINK PARSER
# ─────────────────────────────────────────────

def _parse_deep_link(text: str) -> int | None:
    """
    /start vacancy_42  → 42
    /start v42         → 42
    """
    parts = (text or "").strip().split(maxsplit=1)
    if len(parts) < 2:
        return None
    payload = parts[1]
    for prefix in ("vacancy_", "v"):
        if payload.startswith(prefix):
            rest = payload[len(prefix):]
            if rest.isdigit():
                return int(rest)
    return None


# ─────────────────────────────────────────────
# VACANCY KEYBOARD
# ─────────────────────────────────────────────

async def _vacancy_keyboard() -> InlineKeyboardMarkup:
    vacancies = await noco.list_vacancies(active_only=True)
    buttons = [
        [InlineKeyboardButton(text=f"💼 {v['title']}", callback_data=f"vacancy:{v['Id']}")]
        for v in vacancies
    ]
    if not buttons:
        buttons = [[InlineKeyboardButton(text="📋 Общая анкета", callback_data="vacancy:0")]]
    return InlineKeyboardMarkup(inline_keyboard=buttons)


# ─────────────────────────────────────────────
# CORE START LOGIC
# ─────────────────────────────────────────────

async def _run_start(message: Message, state: FSMContext, user, deep_vacancy_id: int | None = None) -> None:
    """Main start logic — called after subscription is confirmed."""
    telegram_id = user.id
    candidate = await noco.get_candidate_by_telegram_id(telegram_id)

    if candidate:
        if candidate.get("is_blocked"):
            await message.answer("🚫 <b>Доступ ограничен.</b>\nВаш аккаунт заблокирован.", parse_mode="HTML")
            return
        if candidate.get("registration_completed_at"):
            status = candidate.get("status", "new")
            num = candidate.get("Id", "?")
            await message.answer(
                f"📋 <b>Ваша анкета уже была отправлена.</b>\n\n"
                f"📊 <b>Статус #{num:06d}:</b>\n{STATUS_MAP.get(status, 'Статус неизвестен.')}",
                parse_mode="HTML",
            )
            return

    # Deep-link → auto-select vacancy
    if deep_vacancy_id:
        vacancy = await noco.get_vacancy(deep_vacancy_id)
        if vacancy and vacancy.get("is_active"):
            vacancy_title = vacancy.get("title", "Вакансия")
            await message.answer(
                f"👋 Здравствуйте, <b>{user.full_name}</b>!\n\n"
                f"Вы перешли по ссылке на вакансию <b>«{vacancy_title}»</b>.\n\n"
                "Заполните анкету — это займёт 10–15 минут.",
                parse_mode="HTML",
            )
            await message.answer(WARNING_TEXT, parse_mode="HTML")
            await _start_registration(message, state, deep_vacancy_id, vacancy_title, user)
            return
        await message.answer("⚠️ Вакансия не найдена или уже закрыта. Выберите из актуальных:")

    # Regular start
    await message.answer(
        f"👋 Здравствуйте, <b>{user.full_name}</b>!\n\n"
        "Добро пожаловать в систему подбора персонала.\n\n"
        "Процесс:\n"
        "1️⃣ Выбор вакансии\n"
        "2️⃣ Заполнение анкеты\n"
        "3️⃣ Профессиональный тест\n\n"
        "Примерное время: <b>10–15 минут</b>.",
        parse_mode="HTML",
    )
    kb = await _vacancy_keyboard()
    await message.answer(WARNING_TEXT, parse_mode="HTML", reply_markup=kb)
    await state.set_state(RegistrationStates.WARNING)


async def _start_registration(
    message: Message,
    state: FSMContext,
    vacancy_id: int | None,
    vacancy_title: str,
    user,
) -> None:
    """Transition into registration FSM."""
    await state.update_data(
        vacancy_id=vacancy_id or 0,
        vacancy_title=vacancy_title,
        telegram_id=user.id,
        full_name=user.full_name,
        username=user.username or "",
    )
    await state.set_state(RegistrationStates.FULL_NAME)
    await message.answer(
        f"✅ Выбрана вакансия: <b>{vacancy_title}</b>\n\n"
        "📝 Как вас зовут? Введите <b>ФИО полностью</b>:",
        parse_mode="HTML",
    )


# ─────────────────────────────────────────────
# /start ENTRY POINT
# ─────────────────────────────────────────────

@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext) -> None:
    user = message.from_user
    logger.info(f"[/start] user={user.id} text={message.text!r}")

    deep_vacancy_id = _parse_deep_link(message.text or "")

    # ── Subscription gate ──────────────────────────────────
    if settings.required_channel_ids:
        subscribed = await _is_subscribed(message.bot, user.id)
        if not subscribed:
            # Save deep-link for after subscription
            await state.update_data(pending_vacancy_id=deep_vacancy_id)
            await _send_subscription_gate(message, state)
            return

    await _run_start(message, state, user, deep_vacancy_id)


# ─────────────────────────────────────────────
# VACANCY SELECTION CALLBACK
# ─────────────────────────────────────────────

@router.callback_query(F.data.startswith("vacancy:"))
async def select_vacancy(callback: CallbackQuery, state: FSMContext) -> None:
    vacancy_id = int(callback.data.split(":")[1])
    vacancy_title = "Общая анкета"
    if vacancy_id:
        vacancy = await noco.get_vacancy(vacancy_id)
        if vacancy:
            vacancy_title = vacancy.get("title", "Вакансия")

    await callback.message.edit_reply_markup()
    await _start_registration(callback.message, state, vacancy_id, vacancy_title, callback.from_user)
    await callback.answer()


# ─────────────────────────────────────────────
# STATUS CHECK
# ─────────────────────────────────────────────

@router.message(F.text == "📊 Статус моей заявки")
async def check_status(message: Message) -> None:
    candidate = await noco.get_candidate_by_telegram_id(message.from_user.id)
    if not candidate or not candidate.get("registration_completed_at"):
        await message.answer("У вас пока нет поданной анкеты.")
        return
    status = candidate.get("status", "new")
    num = candidate.get("Id", "?")
    await message.answer(
        f"📊 <b>Статус #{num:06d}:</b>\n\n{STATUS_MAP.get(status, 'Статус неизвестен.')}",
        parse_mode="HTML",
    )
