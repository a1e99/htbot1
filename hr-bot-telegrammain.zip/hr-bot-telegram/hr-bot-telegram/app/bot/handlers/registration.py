"""
Registration FSM handler - NocoDB version.
Collects candidate profile, optional resume, fallback resume questionnaire
and reminder preference before final submission.
"""
from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    Message,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
)
from loguru import logger

from app.bot.states.registration import QuizStates, RegistrationStates
from app.nocodb.client import noco
from app.services.photo_service import save_photo_from_message
from app.services.salary_expectation_service import (
    evaluate_salary_expectation,
    format_salary_expectation,
)

router = Router(name="registration")

PHONE_RE = re.compile(r"^\+?[\d\s\-\(\)]{7,20}$")
EMAIL_RE = re.compile(r"^[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}$", re.IGNORECASE)

SHARE_PHONE_KB = ReplyKeyboardMarkup(
    keyboard=[[KeyboardButton(text="📱 Поделиться номером", request_contact=True)]],
    resize_keyboard=True,
    one_time_keyboard=True,
)

SKIP_RESUME_KB = InlineKeyboardMarkup(
    inline_keyboard=[[InlineKeyboardButton(text="⏭ Пропустить", callback_data="skip_resume")]]
)

RELOCATION_KB = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="Нет, не готов(а)", callback_data="reloc:none")],
        [InlineKeyboardButton(text="Да, в любой город", callback_data="reloc:any")],
        [InlineKeyboardButton(text="Да, в конкретный город", callback_data="reloc:specific")],
    ]
)

SALARY_CURRENCY_KB = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="EUR", callback_data="salary_currency:EUR"),
            InlineKeyboardButton(text="USD", callback_data="salary_currency:USD"),
        ],
        [
            InlineKeyboardButton(text="PLN", callback_data="salary_currency:PLN"),
            InlineKeyboardButton(text="CZK", callback_data="salary_currency:CZK"),
        ],
        [InlineKeyboardButton(text="UAH", callback_data="salary_currency:UAH")],
    ]
)

SALARY_PERIOD_KB = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="В час", callback_data="salary_period:hour"),
            InlineKeyboardButton(text="В месяц", callback_data="salary_period:month"),
        ]
    ]
)

SALARY_CONFIRM_KB = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="Оставить как есть", callback_data="salary_confirm:keep")],
        [InlineKeyboardButton(text="Изменить ставку", callback_data="salary_confirm:change")],
    ]
)

REMINDER_KB = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="Не напоминать", callback_data="reminder:0"),
            InlineKeyboardButton(text="Раз в 3 дня", callback_data="reminder:3"),
        ],
        [
            InlineKeyboardButton(text="Раз в неделю", callback_data="reminder:7"),
            InlineKeyboardButton(text="Раз в 2 недели", callback_data="reminder:14"),
        ],
        [InlineKeyboardButton(text="Раз в месяц", callback_data="reminder:30")],
    ]
)

EXPERIENCE_KB = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="Нет опыта", callback_data="exp:0"),
            InlineKeyboardButton(text="До 1 года", callback_data="exp:1"),
        ],
        [
            InlineKeyboardButton(text="1-3 года", callback_data="exp:2"),
            InlineKeyboardButton(text="3-5 лет", callback_data="exp:4"),
        ],
        [
            InlineKeyboardButton(text="5-10 лет", callback_data="exp:7"),
            InlineKeyboardButton(text="Более 10", callback_data="exp:11"),
        ],
    ]
)

LANGUAGES_KB = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="Только русский", callback_data="lang:Русский")],
        [
            InlineKeyboardButton(text="Русский + Английский", callback_data="lang:Русский, Английский"),
            InlineKeyboardButton(text="Другие", callback_data="lang:other"),
        ],
    ]
)


def _period_label(period: str) -> str:
    return "в час" if period == "hour" else "в месяц"


def _reminder_label(days: int) -> str:
    return {
        0: "не напоминать",
        3: "раз в 3 дня",
        7: "раз в неделю",
        14: "раз в 2 недели",
        30: "раз в месяц",
    }.get(days, f"раз в {days} дн.")


async def _ask_age(message: Message, state: FSMContext) -> None:
    await state.set_state(RegistrationStates.AGE)
    await message.answer("🎂 Сколько вам <b>лет</b>?", parse_mode="HTML")


async def _ask_salary_amount(message: Message, state: FSMContext) -> None:
    await state.set_state(RegistrationStates.SALARY_AMOUNT)
    await message.answer(
        "💶 Какую <b>ставку</b> вы хотите?\n\n"
        "Введите только число, без валюты.\n"
        "<i>Например: 12 или 2500</i>",
        parse_mode="HTML",
    )


async def _ask_reminder_frequency(message: Message, state: FSMContext, candidate_id: int) -> None:
    await state.update_data(candidate_id=candidate_id)
    await state.set_state(RegistrationStates.REMINDER_FREQUENCY)
    await message.answer(
        "🔔 Хотите, чтобы бот напоминал о вашей анкете и статусе?\n\n"
        "Выберите удобную частоту:",
        reply_markup=REMINDER_KB,
    )


@router.message(RegistrationStates.FULL_NAME, F.text)
async def reg_full_name(message: Message, state: FSMContext) -> None:
    name = message.text.strip()
    if len(name) < 3:
        await message.answer("⚠️ Введите ФИО полностью, минимум 3 символа.")
        return

    await state.update_data(full_name=name)
    await state.set_state(RegistrationStates.PHONE)
    await message.answer(
        "📱 Нажмите кнопку ниже, чтобы поделиться <b>номером телефона</b>.\n\n"
        "<i>Бот получит только номер, ничего лишнего.</i>",
        parse_mode="HTML",
        reply_markup=SHARE_PHONE_KB,
    )


@router.message(RegistrationStates.PHONE, F.contact)
async def reg_phone_contact(message: Message, state: FSMContext) -> None:
    phone = message.contact.phone_number
    if not phone.startswith("+"):
        phone = f"+{phone}"

    await state.update_data(phone=phone)
    await state.set_state(RegistrationStates.EMAIL)
    await message.answer(
        f"✅ Номер <b>{phone}</b> сохранён.\n\n"
        "📧 Укажите вашу <b>электронную почту</b>:",
        parse_mode="HTML",
        reply_markup=ReplyKeyboardRemove(),
    )


@router.message(RegistrationStates.PHONE, F.text)
async def reg_phone_text(message: Message, state: FSMContext) -> None:
    phone = message.text.strip()
    if not PHONE_RE.match(phone):
        await message.answer(
            "⚠️ Нажмите кнопку <b>«📱 Поделиться номером»</b> ниже\n"
            "или введите номер в формате +79001234567.",
            parse_mode="HTML",
            reply_markup=SHARE_PHONE_KB,
        )
        return

    await state.update_data(phone=phone)
    await state.set_state(RegistrationStates.EMAIL)
    await message.answer(
        "📧 Укажите вашу <b>электронную почту</b>:",
        parse_mode="HTML",
        reply_markup=ReplyKeyboardRemove(),
    )


@router.message(RegistrationStates.EMAIL, F.text)
async def reg_email(message: Message, state: FSMContext) -> None:
    email = message.text.strip()
    if not EMAIL_RE.match(email):
        await message.answer("⚠️ Введите корректный email, например <code>name@example.com</code>.", parse_mode="HTML")
        return

    await state.update_data(email=email)
    await state.set_state(RegistrationStates.CITY)
    await message.answer("🏙 Из какого вы <b>города</b> сейчас?", parse_mode="HTML")


@router.message(RegistrationStates.CITY, F.text)
async def reg_city(message: Message, state: FSMContext) -> None:
    city = message.text.strip()
    if len(city) < 2:
        await message.answer("⚠️ Введите название города.")
        return

    await state.update_data(city=city, current_city=city)
    await state.set_state(RegistrationStates.RELOCATION)
    await message.answer(
        "🚚 Готовы ли вы к <b>переезду</b> ради работы?",
        parse_mode="HTML",
        reply_markup=RELOCATION_KB,
    )


@router.callback_query(F.data.startswith("reloc:"), RegistrationStates.RELOCATION)
async def reg_relocation(callback: CallbackQuery, state: FSMContext) -> None:
    value = callback.data.split(":", 1)[1]
    await callback.message.edit_reply_markup()
    await callback.answer()

    if value == "specific":
        await state.update_data(relocation_preference="specific", relocation_locations="")
        await state.set_state(RegistrationStates.RELOCATION_DETAILS)
        await callback.message.answer(
            "✏️ Напишите, в какой город или страну вы готовы переехать."
        )
        return

    relocation_preference = "any" if value == "any" else "none"
    relocation_locations = "любой город" if value == "any" else ""
    await state.update_data(
        relocation_preference=relocation_preference,
        relocation_locations=relocation_locations,
    )
    await _ask_salary_amount(callback.message, state)


@router.message(RegistrationStates.RELOCATION, F.text)
async def reg_relocation_text(message: Message) -> None:
    await message.answer("Выберите один из вариантов кнопками ниже.", reply_markup=RELOCATION_KB)


@router.message(RegistrationStates.RELOCATION_DETAILS, F.text)
async def reg_relocation_details(message: Message, state: FSMContext) -> None:
    text = message.text.strip()
    if len(text) < 2:
        await message.answer("⚠️ Укажите город или страну для переезда.")
        return

    await state.update_data(relocation_locations=text)
    await _ask_salary_amount(message, state)


@router.message(RegistrationStates.SALARY_AMOUNT, F.text)
async def reg_salary_amount(message: Message, state: FSMContext) -> None:
    raw = message.text.strip().replace(",", ".").replace(" ", "")
    try:
        amount = float(raw)
    except ValueError:
        await message.answer("⚠️ Введите только число, например <code>12</code> или <code>2500</code>.", parse_mode="HTML")
        return

    if amount <= 0:
        await message.answer("⚠️ Ставка должна быть больше нуля.")
        return

    await state.update_data(desired_salary_amount=round(amount, 2))
    await state.set_state(RegistrationStates.SALARY_CURRENCY)
    await message.answer(
        "💱 Выберите <b>валюту</b> желаемой ставки:",
        parse_mode="HTML",
        reply_markup=SALARY_CURRENCY_KB,
    )


@router.callback_query(F.data.startswith("salary_currency:"), RegistrationStates.SALARY_CURRENCY)
async def reg_salary_currency(callback: CallbackQuery, state: FSMContext) -> None:
    currency = callback.data.split(":", 1)[1]
    await callback.message.edit_reply_markup()
    await callback.answer()
    await state.update_data(desired_salary_currency=currency)
    await state.set_state(RegistrationStates.SALARY_PERIOD)
    await callback.message.answer(
        "🧾 Эта ставка указана <b>в час</b> или <b>в месяц</b>?",
        parse_mode="HTML",
        reply_markup=SALARY_PERIOD_KB,
    )


@router.message(RegistrationStates.SALARY_CURRENCY, F.text)
async def reg_salary_currency_text(message: Message) -> None:
    await message.answer("Выберите валюту кнопками ниже.", reply_markup=SALARY_CURRENCY_KB)


@router.callback_query(F.data.startswith("salary_period:"), RegistrationStates.SALARY_PERIOD)
async def reg_salary_period(callback: CallbackQuery, state: FSMContext) -> None:
    period = callback.data.split(":", 1)[1]
    await callback.message.edit_reply_markup()
    await callback.answer()

    data = await state.get_data()
    amount = float(data.get("desired_salary_amount", 0))
    currency = data.get("desired_salary_currency", "EUR")
    vacancy = None
    vacancy_id = data.get("vacancy_id", 0)
    if vacancy_id:
        vacancy = await noco.get_vacancy(vacancy_id)

    evaluation = evaluate_salary_expectation(
        amount=amount,
        currency=currency,
        period=period,
        vacancy_title=data.get("vacancy_title", ""),
        vacancy=vacancy,
    )

    await state.update_data(
        desired_salary_period=period,
        desired_salary_warning=evaluation.warning_text or "",
        salary_warning_acknowledged=not evaluation.is_high,
    )

    salary_text = format_salary_expectation(amount, currency, period)
    if evaluation.is_high:
        await state.set_state(RegistrationStates.SALARY_CONFIRM)
        await callback.message.answer(
            "⚠️ <b>Проверьте ожидания по ставке</b>\n\n"
            f"Вы указали: <b>{salary_text}</b>\n\n"
            f"{evaluation.warning_text}\n\n"
            "Если оставить такую ставку, резюме может не попасть в подбор для потенциальных компаний по этой вакансии.",
            parse_mode="HTML",
            reply_markup=SALARY_CONFIRM_KB,
        )
        return

    await callback.message.answer(
        f"✅ Желаемая ставка сохранена: <b>{salary_text}</b>.",
        parse_mode="HTML",
    )
    await _ask_age(callback.message, state)


@router.message(RegistrationStates.SALARY_PERIOD, F.text)
async def reg_salary_period_text(message: Message) -> None:
    await message.answer("Выберите период кнопками ниже.", reply_markup=SALARY_PERIOD_KB)


@router.callback_query(F.data.startswith("salary_confirm:"), RegistrationStates.SALARY_CONFIRM)
async def reg_salary_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    decision = callback.data.split(":", 1)[1]
    await callback.message.edit_reply_markup()
    await callback.answer()

    if decision == "change":
        await state.update_data(
            desired_salary_amount=None,
            desired_salary_currency=None,
            desired_salary_period=None,
            desired_salary_warning="",
            salary_warning_acknowledged=False,
        )
        await _ask_salary_amount(callback.message, state)
        return

    await state.update_data(salary_warning_acknowledged=True)
    await callback.message.answer("✅ Ок, сохраняю вашу ставку как есть.")
    await _ask_age(callback.message, state)


@router.message(RegistrationStates.AGE, F.text)
async def reg_age(message: Message, state: FSMContext) -> None:
    text = message.text.strip()
    if not text.isdigit() or not (14 <= int(text) <= 80):
        await message.answer("⚠️ Введите корректный возраст: от 14 до 80.")
        return

    await state.update_data(age=int(text))
    await state.set_state(RegistrationStates.PHOTO)
    await message.answer(
        "📸 Отправьте <b>фото</b> как фотографию, не файлом.\n"
        "Фото автоматически сжимается перед сохранением в базу.",
        parse_mode="HTML",
    )


@router.message(RegistrationStates.PHOTO, F.photo)
async def reg_photo(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    telegram_id = message.from_user.id
    photo_path = await save_photo_from_message(message)
    now_iso = datetime.now(timezone.utc).isoformat()

    candidate_data = {
        "telegram_id": telegram_id,
        "username": message.from_user.username or "",
        "full_name": data.get("full_name", message.from_user.full_name),
        "phone": data.get("phone", ""),
        "email": data.get("email", ""),
        "city": data.get("city", ""),
        "current_city": data.get("current_city", data.get("city", "")),
        "age": data.get("age", 0),
        "vacancy_id": data.get("vacancy_id", 0),
        "vacancy_title": data.get("vacancy_title", ""),
        "relocation_preference": data.get("relocation_preference", "none"),
        "relocation_locations": data.get("relocation_locations", ""),
        "desired_salary_amount": data.get("desired_salary_amount"),
        "desired_salary_currency": data.get("desired_salary_currency", ""),
        "desired_salary_period": data.get("desired_salary_period", ""),
        "desired_salary_text": format_salary_expectation(
            data.get("desired_salary_amount"),
            data.get("desired_salary_currency"),
            data.get("desired_salary_period"),
        ),
        "desired_salary_warning": data.get("desired_salary_warning", ""),
        "salary_warning_acknowledged": data.get("salary_warning_acknowledged", False),
        "status": "new",
        "photo_path": photo_path or "",
        "is_blocked": False,
        "created_at": now_iso,
    }

    candidate = await noco.create_candidate(candidate_data)
    candidate_id = candidate.get("Id")
    await state.update_data(candidate_id=candidate_id)
    logger.info(f"Candidate created: id={candidate_id} telegram_id={telegram_id}")

    await state.set_state(RegistrationStates.RESUME)
    await message.answer(
        "📄 Прикрепите ваше <b>резюме</b> в формате PDF, DOC, DOCX или TXT.\n\n"
        "Это поможет нам точнее оценить вашу кандидатуру.\n"
        "Если резюме нет, можно пропустить и заполнить короткую анкету.",
        parse_mode="HTML",
        reply_markup=SKIP_RESUME_KB,
    )


@router.message(RegistrationStates.PHOTO)
async def reg_photo_wrong(message: Message) -> None:
    await message.answer("⚠️ Пожалуйста, отправьте именно фотографию, не файл.", parse_mode="HTML")


@router.message(RegistrationStates.RESUME, F.document)
async def reg_resume(message: Message, state: FSMContext) -> None:
    doc = message.document
    from pathlib import Path

    ext = Path(doc.file_name or "").suffix.lower()
    if ext not in {".pdf", ".doc", ".docx", ".txt"}:
        await message.answer(
            "⚠️ Поддерживаются форматы: PDF, DOC, DOCX и TXT.\n"
            "Попробуйте ещё раз или нажмите «Пропустить»."
        )
        return

    processing = await message.answer("⏳ Обрабатываю резюме...")
    data = await state.get_data()
    candidate_id = data["candidate_id"]

    try:
        from app.services.resume_service import (
            download_document,
            extract_text_from_bytes,
            parse_resume_with_ai,
            save_resume_file,
        )

        file_data = await download_document(message.bot, doc.file_id)
        resume_path = await save_resume_file(file_data, doc.file_name or "resume.pdf", candidate_id)
        resume_text = await extract_text_from_bytes(file_data, doc.file_name or "resume.pdf")
        ai_profile = await parse_resume_with_ai(resume_text)

        update: dict = {"resume_path": resume_path}
        if ai_profile.get("skills"):
            update["resume_skills"] = ", ".join(ai_profile["skills"][:20])
        if ai_profile.get("experience_years"):
            update["experience_years"] = ai_profile["experience_years"]
        if ai_profile.get("experience_details"):
            update["experience_details"] = ai_profile["experience_details"]
        if ai_profile.get("summary"):
            update["resume_summary"] = ai_profile["summary"]
        if ai_profile.get("education"):
            update["education"] = ai_profile["education"]
        if ai_profile.get("languages"):
            update["languages"] = ", ".join(ai_profile["languages"])

        await noco.update_candidate(candidate_id, update)

        skills_text = ""
        if ai_profile.get("skills"):
            skills_text = "\n\n🔧 <b>Навыки:</b> " + ", ".join(ai_profile["skills"][:12])

        await processing.edit_text(
            f"✅ Резюме загружено и проанализировано.{skills_text}",
            parse_mode="HTML",
        )
        logger.info(f"[Resume] Parsed id={candidate_id}: {ai_profile.get('skills', [])[:5]}")
    except Exception as exc:
        logger.error(f"[Resume] error: {exc}")
        await processing.edit_text("⚠️ Не удалось обработать файл. Продолжаем дальше.")

    await _proceed_to_quiz(message, state, candidate_id)


@router.callback_query(F.data == "skip_resume", RegistrationStates.RESUME)
async def skip_resume(callback: CallbackQuery, state: FSMContext) -> None:
    await callback.message.edit_reply_markup()
    await callback.answer()
    await state.set_state(RegistrationStates.RESUME_SPECIALTY)
    await callback.message.answer(
        "📋 <b>Составим резюме вместе</b>\n\n"
        "Я задам 6 коротких вопросов. Это займёт 2-3 минуты.\n\n"
        "<b>1/6 · Специальность</b>\n"
        "Кем вы работаете или кем хотите работать? "
        "<i>Например: сварщик, электрик, водитель, повар</i>",
        parse_mode="HTML",
    )


@router.message(RegistrationStates.RESUME)
async def reg_resume_wrong(message: Message) -> None:
    await message.answer(
        "⚠️ Пожалуйста, отправьте документ с резюме или нажмите «Пропустить»."
    )


@router.message(RegistrationStates.RESUME_SPECIALTY, F.text)
async def rq_specialty(message: Message, state: FSMContext) -> None:
    text = message.text.strip()
    if len(text) < 2:
        await message.answer("⚠️ Введите название специальности.")
        return

    await state.update_data(rq_specialty=text)
    await state.set_state(RegistrationStates.RESUME_EXPERIENCE_YEARS)
    await message.answer(
        "<b>2/6 · Опыт работы</b>\n\nСколько лет опыта у вас по этой специальности?",
        parse_mode="HTML",
        reply_markup=EXPERIENCE_KB,
    )


@router.callback_query(F.data.startswith("exp:"), RegistrationStates.RESUME_EXPERIENCE_YEARS)
async def rq_exp_years_cb(callback: CallbackQuery, state: FSMContext) -> None:
    years = int(callback.data.split(":")[1])
    await state.update_data(rq_experience_years=years)
    await callback.message.edit_reply_markup()
    await callback.answer()
    await state.set_state(RegistrationStates.RESUME_EXPERIENCE_DETAILS)
    await callback.message.answer(
        "<b>3/6 · Опыт работы подробнее</b>\n\n"
        "Опишите, где и кем вы работали, какие были обязанности.\n"
        "<i>Если опыта нет, напишите «нет опыта» или расскажите об учебе/стажировке.</i>",
        parse_mode="HTML",
    )


@router.message(RegistrationStates.RESUME_EXPERIENCE_YEARS, F.text)
async def rq_exp_years_text(message: Message, state: FSMContext) -> None:
    text = message.text.strip()
    years = int(text) if text.isdigit() else 0
    await state.update_data(rq_experience_years=years)
    await state.set_state(RegistrationStates.RESUME_EXPERIENCE_DETAILS)
    await message.answer(
        "<b>3/6 · Опыт работы подробнее</b>\n\n"
        "Опишите, где и кем вы работали, какие были обязанности.\n"
        "<i>Если опыта нет, напишите «нет опыта».</i>",
        parse_mode="HTML",
    )


@router.message(RegistrationStates.RESUME_EXPERIENCE_DETAILS, F.text)
async def rq_exp_details(message: Message, state: FSMContext) -> None:
    text = message.text.strip()
    if len(text) < 3:
        await message.answer("⚠️ Напишите хотя бы пару слов.")
        return

    await state.update_data(rq_experience_details=text)
    await state.set_state(RegistrationStates.RESUME_SKILLS)
    await message.answer(
        "<b>4/6 · Навыки</b>\n\n"
        "Перечислите ваши профессиональные навыки, инструменты и программы.\n"
        "<i>Например: MIG/MAG, AutoCAD, Excel, права категории C/CE</i>",
        parse_mode="HTML",
    )


@router.message(RegistrationStates.RESUME_SKILLS, F.text)
async def rq_skills(message: Message, state: FSMContext) -> None:
    text = message.text.strip()
    if len(text) < 3:
        await message.answer("⚠️ Укажите хотя бы один навык.")
        return

    await state.update_data(rq_skills=text)
    await state.set_state(RegistrationStates.RESUME_EDUCATION)
    await message.answer(
        "<b>5/6 · Образование</b>\n\n"
        "Укажите учебное заведение, специальность и год окончания.\n"
        "<i>Если обучение не окончено, тоже напишите.</i>",
        parse_mode="HTML",
    )


@router.message(RegistrationStates.RESUME_EDUCATION, F.text)
async def rq_education(message: Message, state: FSMContext) -> None:
    text = message.text.strip()
    if len(text) < 2:
        await message.answer("⚠️ Введите данные об образовании.")
        return

    await state.update_data(rq_education=text)
    await state.set_state(RegistrationStates.RESUME_LANGUAGES)
    await message.answer(
        "<b>6/6 · Языки</b>\n\nКакими языками вы владеете?",
        parse_mode="HTML",
        reply_markup=LANGUAGES_KB,
    )


@router.callback_query(F.data.startswith("lang:"), RegistrationStates.RESUME_LANGUAGES)
async def rq_languages_cb(callback: CallbackQuery, state: FSMContext) -> None:
    value = callback.data.split(":", 1)[1]
    await callback.message.edit_reply_markup()
    await callback.answer()
    if value == "other":
        await callback.message.answer(
            "✏️ Напишите языки вручную. Например: Русский, Польский, Английский."
        )
        return

    await _save_resume_questionnaire(callback.message, state, value)


@router.message(RegistrationStates.RESUME_LANGUAGES, F.text)
async def rq_languages_text(message: Message, state: FSMContext) -> None:
    await _save_resume_questionnaire(message, state, message.text.strip())


async def _save_resume_questionnaire(message: Message, state: FSMContext, languages: str) -> None:
    data = await state.get_data()
    candidate_id = data["candidate_id"]

    specialty = data.get("rq_specialty", "")
    exp_years = data.get("rq_experience_years", 0)
    exp_details = data.get("rq_experience_details", "")
    skills = data.get("rq_skills", "")
    education = data.get("rq_education", "")

    await noco.update_candidate(
        candidate_id,
        {
            "resume_specialty": specialty,
            "experience_years": exp_years,
            "experience_details": exp_details,
            "resume_skills": skills,
            "education": education,
            "languages": languages,
            "resume_source": "questionnaire",
        },
    )

    logger.info(f"[ResumeQ] Saved questionnaire for candidate {candidate_id}")

    exp_label = {
        0: "нет опыта",
        1: "до 1 года",
        2: "1-3 года",
        4: "3-5 лет",
        7: "5-10 лет",
        11: "более 10 лет",
    }.get(exp_years, f"{exp_years} лет")

    await message.answer(
        "✅ <b>Отлично, мини-резюме готово.</b>\n\n"
        f"👔 Специальность: <b>{specialty}</b>\n"
        f"📅 Опыт: <b>{exp_label}</b>\n"
        f"🔧 Навыки: {skills[:80]}{'...' if len(skills) > 80 else ''}\n"
        f"🎓 Образование: {education[:60]}{'...' if len(education) > 60 else ''}\n"
        f"🌍 Языки: {languages}",
        parse_mode="HTML",
    )

    await _proceed_to_quiz(message, state, candidate_id)


async def _proceed_to_quiz(message: Message, state: FSMContext, candidate_id: int) -> None:
    data = await state.get_data()
    vacancy_id = data.get("vacancy_id", 0)
    questions = await noco.list_questions(vacancy_id if vacancy_id else None)

    if not questions:
        await _ask_reminder_frequency(message, state, candidate_id)
        return

    await state.update_data(
        quiz_questions=[q["Id"] for q in questions],
        quiz_question_texts={q["Id"]: q["question_text"] for q in questions},
        quiz_min_lengths={q["Id"]: q.get("min_answer_length", 10) for q in questions},
        quiz_question_index=0,
    )
    await state.set_state(QuizStates.ANSWERING)

    first_q = questions[0]
    await message.answer(
        "✅ Анкета заполнена. Теперь пройдите короткий тест.\n\n"
        f"<b>Вопрос 1 из {len(questions)}:</b>\n\n"
        f"{first_q['question_text']}",
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("reminder:"), RegistrationStates.REMINDER_FREQUENCY)
async def reg_reminder_frequency(callback: CallbackQuery, state: FSMContext) -> None:
    days = int(callback.data.split(":", 1)[1])
    await callback.message.edit_reply_markup()
    await callback.answer()

    data = await state.get_data()
    candidate_id = data["candidate_id"]
    now = datetime.now(timezone.utc)
    next_at = (now + timedelta(days=days)).isoformat() if days > 0 else None

    await noco.update_candidate(
        candidate_id,
        {
            "reminder_frequency_days": days,
            "reminder_next_at": next_at,
            "last_reminder_at": None,
        },
    )

    await _complete_registration(callback.message, state, candidate_id, days)


@router.message(RegistrationStates.REMINDER_FREQUENCY, F.text)
async def reg_reminder_frequency_text(message: Message) -> None:
    await message.answer("Выберите частоту напоминаний кнопками ниже.", reply_markup=REMINDER_KB)


async def complete_after_quiz(message: Message, state: FSMContext, candidate_id: int) -> None:
    await state.update_data(managers_notified=True)
    await _ask_reminder_frequency(message, state, candidate_id)


async def _complete_registration(message: Message, state: FSMContext, candidate_id: int, reminder_days: int | None = None) -> None:
    now_iso = datetime.now(timezone.utc).isoformat()
    reminder_text = ""
    data = await state.get_data()

    if reminder_days is None:
        reminder_days = int(data.get("reminder_frequency_days", 0) or 0)

    if reminder_days is not None:
        reminder_text = f"\n🔔 Напоминания: <b>{_reminder_label(reminder_days)}</b>"

    await noco.update_candidate(
        candidate_id,
        {
            "status": "new",
            "registration_completed_at": now_iso,
        },
    )

    if not data.get("managers_notified"):
        try:
            from app.config import settings
            from app.services.notification_service import notify_managers_new_candidate

            candidate = await noco.get_record(settings.noco_table_candidates, candidate_id)
            answers = await noco.list_answers(candidate_id)
            await notify_managers_new_candidate(
                candidate_id,
                candidate or {},
                answers,
                (candidate or {}).get("summary_text", ""),
                int((candidate or {}).get("summary_score", 0) or 0),
            )
        except Exception as exc:
            logger.error(f"Manager notification failed after completion: {exc}")

    await state.clear()
    await message.answer(
        "🎉 <b>Анкета успешно отправлена.</b>\n\n"
        "Наш менеджер рассмотрит её в ближайшее время.\n"
        "Вы получите уведомление при изменении статуса."
        f"{reminder_text}",
        parse_mode="HTML",
    )
