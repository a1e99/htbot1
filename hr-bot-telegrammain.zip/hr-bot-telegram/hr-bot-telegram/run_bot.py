"""Run Telegram bot."""
import asyncio
from loguru import logger
from app.logger import setup_logger

setup_logger()

async def main():
    from aiogram import Bot, Dispatcher
    from aiogram.client.default import DefaultBotProperties
    from aiogram.fsm.storage.memory import MemoryStorage
    from app.config import settings
    from app.bot.handlers import start, registration, quiz, manager, groups, vacancy_ingestion
    from app.bot.middlewares.anti_spam import AntiSpamMiddleware
    from app.nocodb.client import noco
    from app.services.reminder_service import run_candidate_reminder_worker, stop_background_task

    # Verify NocoDB connection
    if not await noco.ping():
        logger.error("NocoDB not reachable at %s — start Docker first: docker compose up -d", settings.nocodb_url)
        return

    logger.info("NocoDB connected OK")

    bot = Bot(token=settings.bot_token, default=DefaultBotProperties(parse_mode="HTML"))
    dp = Dispatcher(storage=MemoryStorage())
    dp.message.middleware(AntiSpamMiddleware())

    dp.include_router(start.router)
    dp.include_router(registration.router)
    dp.include_router(quiz.router)
    dp.include_router(manager.router)
    dp.include_router(groups.router)
    dp.include_router(vacancy_ingestion.router)

    # Store bot instance for notifications
    import app.bot.main as bot_module
    bot_module.bot = bot

    logger.info("Bot starting...")
    reminder_task = asyncio.create_task(run_candidate_reminder_worker(bot))
    try:
        await dp.start_polling(bot, allowed_updates=["message", "callback_query", "channel_post"])
    finally:
        await stop_background_task(reminder_task)
        await noco.close()
        await bot.session.close()

if __name__ == "__main__":
    asyncio.run(main())
