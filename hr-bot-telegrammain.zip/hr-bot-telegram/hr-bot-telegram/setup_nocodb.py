"""
setup_nocodb.py — one-time script to create all NocoDB tables.
Run after starting Docker: docker compose run --rm setup
Compatible with NocoDB v2+ (workspace-based API).
"""
import asyncio
import httpx
from app.config import settings

BASE = settings.nocodb_url.rstrip("/")
EMAIL = settings.nocodb_email
PASSWORD = settings.nocodb_password
API_TOKEN = settings.nocodb_api_token  # preferred over email/password if set


TABLES = [
    {
        "title": "Managers",
        "columns": [
            {"title": "telegram_id", "uidt": "Number"},
            {"title": "full_name", "uidt": "SingleLineText"},
            {"title": "username", "uidt": "SingleLineText"},
            {"title": "phone", "uidt": "SingleLineText"},
            {"title": "is_active", "uidt": "Checkbox"},
            {"title": "created_at", "uidt": "DateTime"},
        ],
    },
    {
        "title": "Vacancies",
        "columns": [
            {"title": "title", "uidt": "SingleLineText"},
            {"title": "description", "uidt": "LongText"},
            {"title": "requirements", "uidt": "LongText"},
            {"title": "salary_from", "uidt": "Number"},
            {"title": "salary_to", "uidt": "Number"},
            {"title": "currency", "uidt": "SingleLineText"},
            {"title": "country", "uidt": "SingleLineText"},
            {"title": "city", "uidt": "SingleLineText"},
            {"title": "location", "uidt": "SingleLineText"},
            {"title": "employment_type", "uidt": "SingleLineText"},
            {"title": "experience_from", "uidt": "Number"},
            # Ingestion fields
            {"title": "source_channel_id", "uidt": "SingleLineText"},
            {"title": "source_message_id", "uidt": "Number"},
            {"title": "source_hash", "uidt": "SingleLineText"},
            {"title": "is_active", "uidt": "Checkbox"},
            {"title": "created_at", "uidt": "DateTime"},
        ],
    },
    {
        "title": "Candidates",
        "columns": [
            {"title": "telegram_id", "uidt": "Number"},
            {"title": "username", "uidt": "SingleLineText"},
            {"title": "full_name", "uidt": "SingleLineText"},
            {"title": "phone", "uidt": "SingleLineText"},
            {"title": "email", "uidt": "Email"},
            {"title": "city", "uidt": "SingleLineText"},
            {"title": "current_city", "uidt": "SingleLineText"},
            {"title": "age", "uidt": "Number"},
            {"title": "vacancy_id", "uidt": "Number"},
            {"title": "vacancy_title", "uidt": "SingleLineText"},
            {"title": "relocation_preference", "uidt": "SingleLineText"},
            {"title": "relocation_locations", "uidt": "LongText"},
            {"title": "desired_salary_amount", "uidt": "Number"},
            {"title": "desired_salary_currency", "uidt": "SingleLineText"},
            {"title": "desired_salary_period", "uidt": "SingleLineText"},
            {"title": "desired_salary_text", "uidt": "SingleLineText"},
            {"title": "desired_salary_warning", "uidt": "LongText"},
            {"title": "salary_warning_acknowledged", "uidt": "Checkbox"},
            {"title": "status", "uidt": "SingleLineText"},
            {"title": "photo_path", "uidt": "SingleLineText"},
            {"title": "resume_path", "uidt": "SingleLineText"},
            {"title": "resume_specialty", "uidt": "SingleLineText"},
            {"title": "resume_skills", "uidt": "LongText"},
            {"title": "resume_summary", "uidt": "LongText"},
            {"title": "resume_source", "uidt": "SingleLineText"},
            {"title": "experience_years", "uidt": "Number"},
            {"title": "experience_details", "uidt": "LongText"},
            {"title": "education", "uidt": "LongText"},
            {"title": "languages", "uidt": "LongText"},
            {"title": "summary_text", "uidt": "LongText"},
            {"title": "summary_score", "uidt": "Number"},
            {"title": "ai_recommendation", "uidt": "SingleLineText"},
            {"title": "assigned_manager_id", "uidt": "Number"},
            {"title": "is_blocked", "uidt": "Checkbox"},
            {"title": "reminder_frequency_days", "uidt": "Number"},
            {"title": "reminder_next_at", "uidt": "DateTime"},
            {"title": "last_reminder_at", "uidt": "DateTime"},
            {"title": "registration_completed_at", "uidt": "DateTime"},
            {"title": "created_at", "uidt": "DateTime"},
        ],
    },
    {
        "title": "QuizQuestions",
        "columns": [
            {"title": "vacancy_id", "uidt": "Number"},
            {"title": "question_text", "uidt": "LongText"},
            {"title": "question_type", "uidt": "SingleLineText"},
            {"title": "choices", "uidt": "LongText"},
            {"title": "min_answer_length", "uidt": "Number"},
            {"title": "order_num", "uidt": "Number"},
            {"title": "is_active", "uidt": "Checkbox"},
        ],
    },
    {
        "title": "QuizAnswers",
        "columns": [
            {"title": "candidate_id", "uidt": "Number"},
            {"title": "question_id", "uidt": "Number"},
            {"title": "question_text", "uidt": "LongText"},
            {"title": "answer_text", "uidt": "LongText"},
            {"title": "ai_score", "uidt": "Number"},
            {"title": "ai_comment", "uidt": "LongText"},
            {"title": "created_at", "uidt": "DateTime"},
        ],
    },
    {
        "title": "KnowledgeDocs",
        "columns": [
            {"title": "title", "uidt": "SingleLineText"},
            {"title": "doc_type", "uidt": "SingleLineText"},
            {"title": "source_path", "uidt": "SingleLineText"},
            {"title": "source_url", "uidt": "SingleLineText"},
            {"title": "content_text", "uidt": "LongText"},
            {"title": "vacancy_id", "uidt": "Number"},
            {"title": "chunk_count", "uidt": "Number"},
            {"title": "is_indexed", "uidt": "Checkbox"},
            {"title": "uploaded_by", "uidt": "Number"},
            {"title": "created_at", "uidt": "DateTime"},
        ],
    },
    {
        "title": "CompanyPartners",
        "columns": [
            {"title": "name", "uidt": "SingleLineText"},
            {"title": "contact_name", "uidt": "SingleLineText"},
            {"title": "telegram_chat_id", "uidt": "Number"},
            {"title": "telegram_username", "uidt": "SingleLineText"},
            {"title": "email", "uidt": "Email"},
            {"title": "specializations", "uidt": "LongText"},
            {"title": "is_active", "uidt": "Checkbox"},
            {"title": "created_at", "uidt": "DateTime"},
        ],
    },
    {
        "title": "PublishChannels",
        "columns": [
            {"title": "title", "uidt": "SingleLineText"},
            {"title": "telegram_chat_id", "uidt": "Number"},
            {"title": "username", "uidt": "SingleLineText"},
            {"title": "description", "uidt": "LongText"},
            {"title": "is_active", "uidt": "Checkbox"},
            {"title": "created_at", "uidt": "DateTime"},
            {"title": "last_post_at", "uidt": "DateTime"},
        ],
    },
    {
        "title": "CandidateBroadcasts",
        "columns": [
            {"title": "candidate_id", "uidt": "Number"},
            {"title": "partner_id", "uidt": "Number"},
            {"title": "sent_by", "uidt": "Number"},
            {"title": "message_text", "uidt": "LongText"},
            {"title": "status", "uidt": "SingleLineText"},
            {"title": "sent_at", "uidt": "DateTime"},
        ],
    },
    {
        "title": "VacancyPublications",
        "columns": [
            {"title": "vacancy_id", "uidt": "Number"},
            {"title": "channel_id", "uidt": "Number"},
            {"title": "telegram_message_id", "uidt": "Number"},
            {"title": "posted_by", "uidt": "Number"},
            {"title": "published_at", "uidt": "DateTime"},
        ],
    },
]


async def setup():
    async with httpx.AsyncClient(timeout=30) as client:
        # 1. Auth — prefer static API token, fall back to email/password
        if API_TOKEN:
            headers = {"xc-token": API_TOKEN}
            print(f"Using API token auth (xc-token)")
        else:
            print("Authenticating with email/password...")
            r = await client.post(
                f"{BASE}/api/v1/auth/user/signin",
                json={"email": EMAIL, "password": PASSWORD},
            )
            if r.status_code != 200:
                print(f"Auth failed: {r.text}")
                return
            token = r.json()["token"]
            headers = {"xc-auth": token}
            print("Authenticated OK")

        # 2. Get workspace and find/use base
        print("Getting workspace...")
        r = await client.get(f"{BASE}/api/v1/workspaces", headers=headers)
        workspaces = r.json().get("list", [])
        if not workspaces:
            print("No workspaces found!")
            return
        workspace_id = workspaces[0]["id"]
        print(f"Workspace: {workspace_id}")

        # 3. List bases in workspace, find or use first
        r = await client.get(f"{BASE}/api/v1/workspaces/{workspace_id}/bases", headers=headers)
        bases = r.json().get("list", [])

        base_id = None
        for b in bases:
            if b.get("title") == "HR Bot":
                base_id = b["id"]
                print(f"Found existing HR Bot base: {base_id}")
                break

        if not base_id:
            # Use first available base
            if bases:
                base_id = bases[0]["id"]
                print(f"Using base '{bases[0]['title']}': {base_id}")
            else:
                print("No bases found!")
                return

        # 4. Get existing tables
        r = await client.get(
            f"{BASE}/api/v1/db/meta/projects/{base_id}/tables",
            headers=headers,
        )
        existing_list = r.json().get("list", [])
        existing = {t["title"] for t in existing_list}
        existing_with_ids = {t["title"]: t["id"] for t in existing_list}
        print(f"Existing tables: {existing}")

        # 5. Create missing tables
        table_ids = dict(existing_with_ids)
        for table_def in TABLES:
            title = table_def["title"]
            if title in existing:
                print(f"  [skip] {title} already exists (id={existing_with_ids[title]})")
                continue

            print(f"  [create] {title}...")
            r = await client.post(
                f"{BASE}/api/v1/db/meta/projects/{base_id}/tables",
                headers=headers,
                json=table_def,
            )
            if r.status_code in (200, 201):
                table_id = r.json()["id"]
                table_ids[title] = table_id
                print(f"    -> created: {table_id}")
            else:
                print(f"    -> ERROR: {r.status_code} {r.text}")

        # 5b. Add missing columns to existing tables
        print("\nChecking for missing columns...")
        for table_def in TABLES:
            title = table_def["title"]
            table_id = table_ids.get(title)
            if not table_id:
                continue

            try:
                r = await client.get(
                    f"{BASE}/api/v1/db/meta/tables/{table_id}",
                    headers=headers,
                )
                if r.status_code != 200:
                    print(f"  [warn] Cannot inspect columns for {title}: {r.status_code} {r.text}")
                    continue

                table_meta = r.json()
                existing_columns = {
                    col.get("title")
                    for col in table_meta.get("columns", [])
                    if col.get("title")
                }

                for column_def in table_def["columns"]:
                    column_title = column_def["title"]
                    if column_title in existing_columns:
                        continue

                    print(f"  [column] {title}.{column_title} ...")
                    cr = await client.post(
                        f"{BASE}/api/v1/db/meta/tables/{table_id}/columns",
                        headers=headers,
                        json=column_def,
                    )
                    if cr.status_code in (200, 201):
                        print("    -> added")
                    else:
                        print(f"    -> ERROR: {cr.status_code} {cr.text}")
            except Exception as exc:
                print(f"  [warn] Failed to update columns for {title}: {exc}")

        # 6. Print .env values
        print("\n" + "=" * 60)
        print("Add these to your .env file:")
        print("=" * 60)
        print(f"NOCODB_PROJECT_ID={base_id}")
        env_key_map = {
            "Managers": "NOCO_TABLE_MANAGERS",
            "Vacancies": "NOCO_TABLE_VACANCIES",
            "Candidates": "NOCO_TABLE_CANDIDATES",
            "QuizQuestions": "NOCO_TABLE_QUIZQUESTIONS",
            "QuizAnswers": "NOCO_TABLE_QUIZANSWERS",
            "KnowledgeDocs": "NOCO_TABLE_KNOWLEDGEDOCS",
            "CompanyPartners": "NOCO_TABLE_COMPANYPARTNERS",
            "PublishChannels": "NOCO_TABLE_PUBLISHCHANNELS",
            "CandidateBroadcasts": "NOCO_TABLE_CANDIDATEBROADCASTS",
        }
        for title, env_key in env_key_map.items():
            tid = table_ids.get(title, "")
            print(f"{env_key}={tid}")
        print("=" * 60)

        # Save to file
        with open("nocodb_table_ids.txt", "w") as f:
            f.write(f"NOCODB_PROJECT_ID={base_id}\n")
            for title, env_key in env_key_map.items():
                tid = table_ids.get(title, "")
                f.write(f"{env_key}={tid}\n")
        print("\nAlso saved to: nocodb_table_ids.txt")


if __name__ == "__main__":
    asyncio.run(setup())
